import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Home, Search, ArrowLeft } from 'lucide-react';

export function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        className="text-center max-w-2xl"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: 'spring' }}
      >
        <motion.div
          className="text-9xl font-bold mb-6 bg-gradient-to-br from-[#FF8C42] via-[#F4C430] to-[#FFB380] bg-clip-text text-transparent"
          animate={{ scale: [1, 1.05, 1], rotate: [0, 2, -2, 0] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          404
        </motion.div>
        
        <h1 className="text-4xl font-bold text-[#F5E6D3] mb-4">Page Not Found</h1>
        <p className="text-[#8A7F6F] mb-8 text-lg">
          The page you're looking for doesn't exist or has been moved.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <motion.button
            onClick={() => navigate('/dashboard')}
            className="px-6 py-3 bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] rounded-xl font-medium flex items-center justify-center gap-2 shadow-lg shadow-[#FF8C42]/30"
            whileHover={{ scale: 1.05, boxShadow: '0 8px 32px rgba(255, 140, 66, 0.4)' }}
            whileTap={{ scale: 0.95 }}
          >
            <Home size={20} />
            Go Home
          </motion.button>

          <motion.button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-[#243947] border border-[#F4C430]/20 text-[#F5E6D3] rounded-xl font-medium flex items-center justify-center gap-2"
            whileHover={{ scale: 1.05, borderColor: 'rgba(244, 196, 48, 0.4)' }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft size={20} />
            Go Back
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
