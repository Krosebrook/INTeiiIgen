import React from 'react';
import { motion } from 'framer-motion';
import { Settings, User, Bell, Lock, Palette, Shield } from 'lucide-react';

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.4, staggerChildren: 0.1 } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
};

export function SettingsPage() {
  const sections = [
    { id: 'profile', label: 'Profile', icon: <User />, color: 'from-[#FF8C42] to-[#F4C430]' },
    { id: 'notifications', label: 'Notifications', icon: <Bell />, color: 'from-[#F4C430] to-[#FFB380]' },
    { id: 'security', label: 'Security', icon: <Lock />, color: 'from-[#FFB380] to-[#FF8C42]' },
    { id: 'appearance', label: 'Appearance', icon: <Palette />, color: 'from-[#2C5F6F] to-[#4A8A9F]' },
    { id: 'privacy', label: 'Privacy', icon: <Shield />, color: 'from-[#4A8A9F] to-[#7BC67E]' }
  ];

  return (
    <motion.div className="p-6 space-y-6" variants={pageVariants} initial="initial" animate="animate" exit="exit">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center shadow-xl">
          <Settings className="text-[#1A2F38]" size={28} />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-[#F5E6D3]">Settings</h1>
          <p className="text-[#8A7F6F]">Manage your account preferences</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {sections.map((section, index) => (
          <motion.div
            key={section.id}
            className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-6 hover:border-[#F4C430]/30 transition-all cursor-pointer group"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -8, boxShadow: '0 12px 40px rgba(255, 140, 66, 0.2)' }}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                <div className="text-[#1A2F38]">{section.icon}</div>
              </div>
              <h3 className="text-xl font-bold text-[#F5E6D3]">{section.label}</h3>
            </div>
            <p className="text-[#8A7F6F]">Configure your {section.label.toLowerCase()} settings</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
