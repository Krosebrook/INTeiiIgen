/**
 * Dashboard Utility Formatters
 * 
 * Helper functions for formatting numbers, currencies, and percentages
 * with proper error handling and locale support
 */

/**
 * Format a metric value with K/M/B suffixes
 * @param {number} value - The numeric value to format
 * @param {number} decimals - Number of decimal places (default: 1)
 * @returns {string} Formatted metric (e.g., "1.2K", "3.5M")
 * 
 * @example
 * formatMetric(1234) // "1.2K"
 * formatMetric(1234567) // "1.2M"
 * formatMetric(1234567890) // "1.2B"
 */
export function formatMetric(value, decimals = 1) {
  // Input validation
  if (value === null || value === undefined) return '—';
  if (typeof value !== 'number' || isNaN(value)) return '—';
  
  const absValue = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  
  if (absValue >= 1_000_000_000) {
    return `${sign}${(absValue / 1_000_000_000).toFixed(decimals)}B`;
  }
  if (absValue >= 1_000_000) {
    return `${sign}${(absValue / 1_000_000).toFixed(decimals)}M`;
  }
  if (absValue >= 1_000) {
    return `${sign}${(absValue / 1_000).toFixed(decimals)}K`;
  }
  
  return `${sign}${absValue.toFixed(decimals)}`;
}

/**
 * Format a percentage value
 * @param {number} value - The numeric value (0-100 or 0-1)
 * @param {number} decimals - Number of decimal places (default: 1)
 * @param {boolean} isDecimal - Whether input is 0-1 scale (default: false)
 * @returns {string} Formatted percentage (e.g., "12.5%", "-3.2%")
 * 
 * @example
 * formatPercent(12.5) // "12.5%"
 * formatPercent(0.125, 1, true) // "12.5%"
 * formatPercent(-3.2) // "-3.2%"
 */
export function formatPercent(value, decimals = 1, isDecimal = false) {
  // Input validation
  if (value === null || value === undefined) return '—';
  if (typeof value !== 'number' || isNaN(value)) return '—';
  
  const actualValue = isDecimal ? value * 100 : value;
  const sign = actualValue < 0 ? '' : '+'; // Show + for positive, - auto-shown
  
  return `${actualValue >= 0 ? sign : ''}${actualValue.toFixed(decimals)}%`;
}

/**
 * Format a currency value
 * @param {number} value - The numeric value
 * @param {string} currency - Currency code (default: 'USD')
 * @param {number} decimals - Number of decimal places (default: 2)
 * @returns {string} Formatted currency (e.g., "$1,234.56", "€1.234,56")
 * 
 * @example
 * formatCurrency(1234.56) // "$1,234.56"
 * formatCurrency(1234.56, 'EUR') // "€1,234.56"
 * formatCurrency(1234567) // "$1.23M"
 */
export function formatCurrency(value, currency = 'USD', decimals = 2) {
  // Input validation
  if (value === null || value === undefined) return '—';
  if (typeof value !== 'number' || isNaN(value)) return '—';
  
  const absValue = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  
  // Format large numbers with suffixes
  if (absValue >= 1_000_000) {
    const formatted = (absValue / 1_000_000).toFixed(decimals);
    return `${sign}$${formatted}M`;
  }
  if (absValue >= 1_000) {
    const formatted = (absValue / 1_000).toFixed(decimals);
    return `${sign}$${formatted}K`;
  }
  
  // Use Intl.NumberFormat for proper locale formatting
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(value);
  } catch (error) {
    // Fallback if Intl.NumberFormat fails
    console.error('Currency formatting error:', error);
    return `${sign}$${absValue.toFixed(decimals)}`;
  }
}

/**
 * Format a date for dashboard display
 * @param {Date|string|number} date - The date to format
 * @param {string} format - Format type: 'short', 'medium', 'long' (default: 'medium')
 * @returns {string} Formatted date
 * 
 * @example
 * formatDate(new Date(), 'short') // "1/21/26"
 * formatDate(new Date(), 'medium') // "Jan 21, 2026"
 * formatDate(new Date(), 'long') // "January 21, 2026"
 */
export function formatDate(date, format = 'medium') {
  // Input validation
  if (!date) return '—';
  
  try {
    const dateObj = date instanceof Date ? date : new Date(date);
    
    if (isNaN(dateObj.getTime())) return '—';
    
    const options = {
      short: { month: 'numeric', day: 'numeric', year: '2-digit' },
      medium: { month: 'short', day: 'numeric', year: 'numeric' },
      long: { month: 'long', day: 'numeric', year: 'numeric' }
    };
    
    return new Intl.DateTimeFormat('en-US', options[format] || options.medium).format(dateObj);
  } catch (error) {
    console.error('Date formatting error:', error);
    return '—';
  }
}

/**
 * Calculate percentage change between two values
 * @param {number} current - Current value
 * @param {number} previous - Previous value
 * @returns {{value: number, direction: string}} Change object with value and direction
 * 
 * @example
 * calculateChange(120, 100) // { value: 20, direction: 'up' }
 * calculateChange(80, 100) // { value: -20, direction: 'down' }
 */
export function calculateChange(current, previous) {
  // Input validation
  if (
    current === null || current === undefined ||
    previous === null || previous === undefined ||
    typeof current !== 'number' || typeof previous !== 'number' ||
    isNaN(current) || isNaN(previous)
  ) {
    return { value: 0, direction: 'neutral' };
  }
  
  // Avoid division by zero
  if (previous === 0) {
    if (current > 0) return { value: 100, direction: 'up' };
    if (current < 0) return { value: -100, direction: 'down' };
    return { value: 0, direction: 'neutral' };
  }
  
  const change = ((current - previous) / previous) * 100;
  
  return {
    value: change,
    direction: change > 0 ? 'up' : change < 0 ? 'down' : 'neutral'
  };
}

/**
 * Truncate text with ellipsis
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length before truncation
 * @returns {string} Truncated text
 * 
 * @example
 * truncateText("This is a long text", 10) // "This is a..."
 */
export function truncateText(text, maxLength) {
  if (!text || typeof text !== 'string') return '';
  if (text.length <= maxLength) return text;
  
  return `${text.slice(0, maxLength)}...`;
}
