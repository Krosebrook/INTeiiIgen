/**
 * Example Analytics Dashboard
 * 
 * Complete dashboard implementation demonstrating all library components
 */

import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  Settings,
  Home,
  FileText,
  PieChart
} from 'lucide-react';

// Dashboard components
import { StatsCard } from '../primitives/StatsCard';
import { MetricDisplay } from '../primitives/MetricDisplay';
import { KPICard, TrendIndicator, BadgeChip } from '../primitives/Additional';
import {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsivePieChart,
  ResponsiveAreaChart
} from '../charts/ResponsiveCharts';
import {
  DashboardShell,
  DashboardHeader,
  DashboardSidebar,
  DashboardContent,
  DashboardSection,
  DashboardGrid
} from '../layouts/Layouts';
import {
  DataTable,
  DataList,
  DataListItem
} from '../data/DataComponents';

// Mock data generators
const generateRevenueData = () => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  return months.map(month => ({
    date: month,
    revenue: Math.floor(Math.random() * 50000) + 30000,
    expenses: Math.floor(Math.random() * 30000) + 20000
  }));
};

const generateUserData = () => {
  const categories = ['New', 'Active', 'Churned', 'Dormant'];
  return categories.map(category => ({
    name: category,
    value: Math.floor(Math.random() * 500) + 100
  }));
};

const generateTransactionData = () => {
  return Array.from({ length: 10 }, (_, i) => ({
    id: `txn-${i + 1}`,
    customer: `Customer ${i + 1}`,
    amount: `$${(Math.random() * 1000).toFixed(2)}`,
    status: ['Completed', 'Pending', 'Failed'][Math.floor(Math.random() * 3)],
    date: new Date(2026, 0, Math.floor(Math.random() * 21) + 1).toLocaleDateString()
  }));
};

export function AnalyticsDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [revenueData] = useState(generateRevenueData);
  const [userData] = useState(generateUserData);
  const [transactions] = useState(generateTransactionData);
  
  // Sidebar navigation
  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home />, active: true },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 />, active: false },
    { id: 'users', label: 'Users', icon: <Users />, badge: '12', active: false },
    { id: 'reports', label: 'Reports', icon: <FileText />, active: false },
    { id: 'settings', label: 'Settings', icon: <Settings />, active: false }
  ];
  
  // Header actions
  const headerActions = (
    <>
      <BadgeChip variant="info" size="sm" icon={<Activity className="w-3 h-3" />}>
        Live
      </BadgeChip>
      <button className="px-3 py-1.5 bg-[#00bfff] text-black font-mono text-sm font-bold hover:bg-[#00bfff]/80 transition-colors">
        Export Data
      </button>
    </>
  );
  
  // Table columns
  const columns = [
    { key: 'customer', label: 'Customer' },
    {
      key: 'amount',
      label: 'Amount',
      align: 'right'
    },
    {
      key: 'status',
      label: 'Status',
      render: (value) => (
        <BadgeChip
          variant={
            value === 'Completed' ? 'success' :
            value === 'Pending' ? 'warning' :
            'error'
          }
          size="sm"
        >
          {value}
        </BadgeChip>
      )
    },
    { key: 'date', label: 'Date', align: 'right' }
  ];
  
  return (
    <DashboardShell
      sidebarOpen={sidebarOpen}
      onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
      header={
        <DashboardHeader
          title="Analytics Dashboard"
          subtitle="Real-time business metrics"
          actions={headerActions}
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          breadcrumbs={[
            { label: 'Home', href: '#' },
            { label: 'Analytics', href: '#' },
            { label: 'Dashboard' }
          ]}
        />
      }
      sidebar={
        <DashboardSidebar
          logo={
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#00bfff] flex items-center justify-center">
                <PieChart className="w-5 h-5 text-black" />
              </div>
              <span className="font-mono font-bold text-white">BASE44</span>
            </div>
          }
          navigation={navigation}
          collapsed={!sidebarOpen}
          onCollapse={() => setSidebarOpen(!sidebarOpen)}
          footer={
            <div className="text-xs text-neutral-500 font-mono">
              v1.0.0 • {new Date().getFullYear()}
            </div>
          }
        />
      }
    >
      <DashboardContent maxWidth="7xl">
        {/* Hero Metrics */}
        <DashboardSection>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <MetricDisplay
              value="99.8%"
              label="Uptime"
              sublabel="Last 30 days"
              size="md"
              color="success"
            />
          </div>
        </DashboardSection>
        
        {/* Stats Cards */}
        <DashboardSection
          title="Key Performance Indicators"
          subtitle="Overview of critical business metrics"
        >
          <DashboardGrid columns={4} gap="md">
            <StatsCard
              title="Total Revenue"
              value="$245.2K"
              change={12.5}
              changeLabel="vs last month"
              icon={<DollarSign className="w-5 h-5" />}
            />
            
            <StatsCard
              title="Active Users"
              value="1,842"
              change={-3.2}
              changeLabel="vs last month"
              icon={<Users className="w-5 h-5" />}
            />
            
            <StatsCard
              title="Conversion Rate"
              value="3.47%"
              change={0.8}
              changeLabel="vs last month"
              icon={<TrendingUp className="w-5 h-5" />}
            />
            
            <StatsCard
              title="Avg. Order Value"
              value="$132.41"
              change={5.3}
              changeLabel="vs last month"
              icon={<BarChart3 className="w-5 h-5" />}
            />
          </DashboardGrid>
        </DashboardSection>
        
        {/* KPI Progress Cards */}
        <DashboardSection
          title="Monthly Goals"
          subtitle="Track progress toward monthly targets"
        >
          <DashboardGrid columns={3} gap="md">
            <KPICard
              title="Revenue Target"
              current={245200}
              target={300000}
              unit=""
              status="warning"
            />
            
            <KPICard
              title="User Acquisition"
              current={1842}
              target={2000}
              unit=""
              status="success"
            />
            
            <KPICard
              title="Customer Satisfaction"
              current={4.2}
              target={4.5}
              unit=" / 5"
              status="warning"
            />
          </DashboardGrid>
        </DashboardSection>
        
        {/* Charts */}
        <DashboardSection
          title="Revenue & Expenses"
          subtitle="6-month trend analysis"
        >
          <DashboardGrid columns={2} gap="md">
            <ResponsiveLineChart
              data={revenueData}
              lines={[
                { dataKey: 'revenue', name: 'Revenue', color: '#39ff14' },
                { dataKey: 'expenses', name: 'Expenses', color: '#ff6b35' }
              ]}
              xAxisKey="date"
              height={300}
              tooltipFormatter={(value) => `$${value.toLocaleString()}`}
            />
            
            <ResponsivePieChart
              data={userData}
              dataKey="value"
              nameKey="name"
              height={300}
              tooltipFormatter={(value) => `${value} users`}
            />
          </DashboardGrid>
        </DashboardSection>
        
        {/* Bar and Area Charts */}
        <DashboardSection
          title="Detailed Analytics"
          subtitle="Additional metrics and insights"
        >
          <DashboardGrid columns={2} gap="md">
            <ResponsiveBarChart
              data={revenueData}
              bars={[
                { dataKey: 'revenue', name: 'Revenue', color: '#00bfff' }
              ]}
              xAxisKey="date"
              height={300}
              tooltipFormatter={(value) => `$${value.toLocaleString()}`}
            />
            
            <ResponsiveAreaChart
              data={revenueData}
              areas={[
                { dataKey: 'revenue', name: 'Revenue', color: '#39ff14' }
              ]}
              xAxisKey="date"
              height={300}
              tooltipFormatter={(value) => `$${value.toLocaleString()}`}
            />
          </DashboardGrid>
        </DashboardSection>
        
        {/* Recent Transactions Table */}
        <DashboardSection
          title="Recent Transactions"
          subtitle="Latest customer transactions"
          actions={
            <button className="px-3 py-1.5 border border-neutral-700 text-neutral-300 font-mono text-sm hover:border-[#00bfff] hover:text-[#00bfff] transition-colors">
              View All
            </button>
          }
        >
          <DataTable
            data={transactions}
            columns={columns}
            sortable
            searchable
            onRowClick={(row) => console.log('Clicked row:', row)}
          />
        </DashboardSection>
        
        {/* Activity List */}
        <DashboardSection
          title="Recent Activity"
          subtitle="System events and updates"
        >
          <DataList
            data={[
              {
                id: 1,
                title: 'New user registration',
                subtitle: 'john.doe@example.com',
                meta: '2 min ago',
                avatar: <div className="w-10 h-10 bg-[#39ff14] flex items-center justify-center text-black font-mono font-bold">JD</div>
              },
              {
                id: 2,
                title: 'Payment received',
                subtitle: '$1,234.56 from Customer Inc.',
                meta: '15 min ago',
                avatar: <div className="w-10 h-10 bg-[#00bfff] flex items-center justify-center text-black font-mono font-bold"><DollarSign /></div>
              },
              {
                id: 3,
                title: 'Report generated',
                subtitle: 'Monthly analytics report',
                meta: '1 hour ago',
                avatar: <div className="w-10 h-10 bg-[#ff6b35] flex items-center justify-center text-black font-mono font-bold"><FileText /></div>
              }
            ]}
            renderItem={(item) => (
              <DataListItem
                title={item.title}
                subtitle={item.subtitle}
                meta={item.meta}
                avatar={item.avatar}
              />
            )}
          />
        </DashboardSection>
      </DashboardContent>
    </DashboardShell>
  );
}

export default AnalyticsDashboard;
