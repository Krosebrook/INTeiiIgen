/**
 * Additional Dashboard Primitives
 * 
 * KPICard, TrendIndicator, and BadgeChip components
 */

import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatPercent } from '../lib/utils/formatters';

// ========================================
// KPICard - Compact metric card with progress
// ========================================

export function KPICard({
  title,
  current,
  target,
  unit = '',
  progress = null,
  status = 'neutral', // 'success' | 'warning' | 'error' | 'neutral'
  className = '',
  loading = false
}) {
  // Calculate progress if not provided
  const actualProgress = progress !== null ? progress : target > 0 ? (current / target) * 100 : 0;
  const isOnTrack = actualProgress >= 100;
  const isAtRisk = actualProgress < 75 && actualProgress >= 50;
  const isOffTrack = actualProgress < 50;
  
  // Status colors
  const statusColor = status === 'success' || isOnTrack
    ? '#39ff14'
    : status === 'warning' || isAtRisk
    ? '#ff6b35'
    : status === 'error' || isOffTrack
    ? '#ff4444'
    : '#00bfff';
  
  return (
    <div className={cn(
      'relative bg-[#1a1a1a] border-2 border-neutral-800 p-4',
      loading && 'animate-pulse',
      className
    )}>
      {/* Status indicator */}
      <div
        className="absolute top-0 left-0 w-full h-1"
        style={{ backgroundColor: statusColor }}
      />
      
      {/* Title */}
      <div className="text-xs font-mono uppercase tracking-wider text-neutral-400 mb-3">
        {title}
      </div>
      
      {/* Values */}
      <div className="flex items-baseline gap-2 mb-3">
        <span className="text-2xl font-mono font-bold text-white">
          {loading ? '—' : current}
        </span>
        <span className="text-xs text-neutral-500 font-mono">
          {unit}
        </span>
        <span className="text-xs text-neutral-500 font-mono">
          / {target}{unit}
        </span>
      </div>
      
      {/* Progress bar */}
      <div className="relative w-full h-1 bg-neutral-800 overflow-hidden">
        <motion.div
          className="absolute top-0 left-0 h-full"
          style={{ backgroundColor: statusColor }}
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(actualProgress, 100)}%` }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        />
      </div>
      
      {/* Progress percentage */}
      <div className="mt-2 text-xs font-mono text-neutral-500">
        {formatPercent(actualProgress, 0)} complete
      </div>
    </div>
  );
}

// ========================================
// TrendIndicator - Compact trend display
// ========================================

export function TrendIndicator({
  value,
  direction = null, // 'up' | 'down' | 'neutral' | auto-detect from value
  size = 'md', // 'sm' | 'md' | 'lg'
  showIcon = true,
  showValue = true,
  className = '',
  'aria-label': ariaLabel
}) {
  // Auto-detect direction from value if not provided
  const actualDirection = direction || (value > 0 ? 'up' : value < 0 ? 'down' : 'neutral');
  const isPositive = actualDirection === 'up';
  const isNegative = actualDirection === 'down';
  const isNeutral = actualDirection === 'neutral';
  
  // Size classes
  const sizeClasses = {
    sm: 'text-xs gap-1 px-1.5 py-0.5',
    md: 'text-sm gap-1.5 px-2 py-1',
    lg: 'text-base gap-2 px-3 py-1.5'
  };
  
  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };
  
  // Colors
  const bgColor = isPositive
    ? 'bg-[#39ff14]/10'
    : isNegative
    ? 'bg-[#ff6b35]/10'
    : 'bg-neutral-800/50';
  
  const textColor = isPositive
    ? 'text-[#39ff14]'
    : isNegative
    ? 'text-[#ff6b35]'
    : 'text-neutral-400';
  
  const Icon = isPositive ? TrendingUp : isNegative ? TrendingDown : Minus;
  
  return (
    <div
      className={cn(
        'inline-flex items-center font-mono font-bold',
        sizeClasses[size],
        bgColor,
        textColor,
        className
      )}
      role="status"
      aria-label={ariaLabel || `Trend: ${value > 0 ? '+' : ''}${value}%`}
    >
      {showIcon && <Icon className={iconSizes[size]} />}
      {showValue && (
        <span>
          {formatPercent(Math.abs(value), 1)}
        </span>
      )}
    </div>
  );
}

// ========================================
// BadgeChip - Status and category badges
// ========================================

export function BadgeChip({
  children,
  variant = 'default', // 'default' | 'success' | 'warning' | 'error' | 'info'
  size = 'md', // 'sm' | 'md' | 'lg'
  icon = null,
  onRemove = null,
  className = '',
  'aria-label': ariaLabel
}) {
  // Size classes
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-sm px-3 py-1 gap-1.5',
    lg: 'text-base px-4 py-1.5 gap-2'
  };
  
  const iconSizes = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };
  
  // Variant colors
  const variantClasses = {
    default: 'bg-neutral-800 text-neutral-300 border-neutral-700',
    success: 'bg-[#39ff14]/10 text-[#39ff14] border-[#39ff14]/30',
    warning: 'bg-[#ff6b35]/10 text-[#ff6b35] border-[#ff6b35]/30',
    error: 'bg-red-500/10 text-red-500 border-red-500/30',
    info: 'bg-[#00bfff]/10 text-[#00bfff] border-[#00bfff]/30'
  };
  
  return (
    <div
      className={cn(
        'inline-flex items-center font-mono font-medium border',
        sizeClasses[size],
        variantClasses[variant],
        className
      )}
      role="status"
      aria-label={ariaLabel}
    >
      {icon && (
        <span className={iconSizes[size]}>
          {icon}
        </span>
      )}
      
      <span>{children}</span>
      
      {onRemove && (
        <button
          onClick={onRemove}
          className="ml-1 hover:opacity-70 transition-opacity"
          aria-label="Remove badge"
        >
          ×
        </button>
      )}
    </div>
  );
}

// Badge group container
export function BadgeGroup({
  badges,
  className = ''
}) {
  return (
    <div className={cn('flex flex-wrap gap-2', className)}>
      {badges.map((badge, index) => (
        <BadgeChip
          key={badge.id || index}
          {...badge}
        />
      ))}
    </div>
  );
}

export default { KPICard, TrendIndicator, BadgeChip, BadgeGroup };
