/**
 * Dashboard Custom Hooks
 * 
 * Reusable hooks for data fetching, filtering, and state management
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { DataLoadingState } from '../types';

/**
 * Hook for fetching and managing dashboard data
 * @param {Function} fetchFn - Async function that fetches data
 * @param {Object} options - Configuration options
 * @param {number} options.refreshInterval - Auto-refresh interval in ms (optional)
 * @param {boolean} options.fetchOnMount - Whether to fetch on component mount (default: true)
 * @returns {Object} Data state and control functions
 * 
 * @example
 * const { data, loading, error, refetch } = useDashboardData(
 *   async () => fetch('/api/stats').then(r => r.json()),
 *   { refreshInterval: 30000 }
 * );
 */
export function useDashboardData(fetchFn, options = {}) {
  const {
    refreshInterval = null,
    fetchOnMount = true
  } = options;
  
  const [data, setData] = useState(null);
  const [state, setState] = useState(DataLoadingState.IDLE);
  const [error, setError] = useState(null);
  
  const isMountedRef = useRef(true);
  const intervalRef = useRef(null);
  
  // Fetch function with error handling
  const fetchData = useCallback(async () => {
    if (!fetchFn) return;
    
    setState(DataLoadingState.LOADING);
    setError(null);
    
    try {
      const result = await fetchFn();
      
      if (isMountedRef.current) {
        setData(result);
        setState(DataLoadingState.SUCCESS);
      }
    } catch (err) {
      if (isMountedRef.current) {
        console.error('Dashboard data fetch error:', err);
        setError(err);
        setState(DataLoadingState.ERROR);
      }
    }
  }, [fetchFn]);
  
  // Setup auto-refresh if interval is provided
  useEffect(() => {
    if (refreshInterval && refreshInterval > 0) {
      intervalRef.current = setInterval(fetchData, refreshInterval);
      
      return () => {
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    }
  }, [refreshInterval, fetchData]);
  
  // Fetch on mount if enabled
  useEffect(() => {
    if (fetchOnMount) {
      fetchData();
    }
  }, [fetchOnMount, fetchData]);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  return {
    data,
    loading: state === DataLoadingState.LOADING,
    error,
    state,
    refetch: fetchData,
    isIdle: state === DataLoadingState.IDLE,
    isLoading: state === DataLoadingState.LOADING,
    isSuccess: state === DataLoadingState.SUCCESS,
    isError: state === DataLoadingState.ERROR
  };
}

/**
 * Hook for managing dashboard filters
 * @param {Object} initialFilters - Initial filter state
 * @param {Function} onFilterChange - Optional callback when filters change
 * @returns {Object} Filter state and control functions
 * 
 * @example
 * const { filters, updateFilter, resetFilters, hasActiveFilters } = useDashboardFilters({
 *   dateRange: 'last7days',
 *   status: 'all'
 * });
 */
export function useDashboardFilters(initialFilters = {}, onFilterChange = null) {
  const [filters, setFilters] = useState(initialFilters);
  const initialFiltersRef = useRef(initialFilters);
  
  // Update a single filter
  const updateFilter = useCallback((key, value) => {
    setFilters(prev => {
      const newFilters = { ...prev, [key]: value };
      
      // Call onChange callback if provided
      if (onFilterChange) {
        onFilterChange(newFilters);
      }
      
      return newFilters;
    });
  }, [onFilterChange]);
  
  // Update multiple filters at once
  const updateFilters = useCallback((updates) => {
    setFilters(prev => {
      const newFilters = { ...prev, ...updates };
      
      if (onFilterChange) {
        onFilterChange(newFilters);
      }
      
      return newFilters;
    });
  }, [onFilterChange]);
  
  // Reset filters to initial state
  const resetFilters = useCallback(() => {
    setFilters(initialFiltersRef.current);
    
    if (onFilterChange) {
      onFilterChange(initialFiltersRef.current);
    }
  }, [onFilterChange]);
  
  // Check if any filters are active (different from initial)
  const hasActiveFilters = useCallback(() => {
    return Object.keys(filters).some(
      key => filters[key] !== initialFiltersRef.current[key]
    );
  }, [filters]);
  
  // Get active filter count
  const activeFilterCount = Object.keys(filters).filter(
    key => filters[key] !== initialFiltersRef.current[key]
  ).length;
  
  return {
    filters,
    updateFilter,
    updateFilters,
    resetFilters,
    hasActiveFilters: hasActiveFilters(),
    activeFilterCount
  };
}

/**
 * Hook for managing pagination state
 * @param {number} initialPage - Initial page number (default: 1)
 * @param {number} initialPageSize - Initial page size (default: 10)
 * @returns {Object} Pagination state and control functions
 * 
 * @example
 * const { page, pageSize, setPage, setPageSize, reset } = usePagination(1, 20);
 */
export function usePagination(initialPage = 1, initialPageSize = 10) {
  const [page, setPage] = useState(initialPage);
  const [pageSize, setPageSize] = useState(initialPageSize);
  
  const reset = useCallback(() => {
    setPage(initialPage);
    setPageSize(initialPageSize);
  }, [initialPage, initialPageSize]);
  
  const goToNextPage = useCallback(() => {
    setPage(prev => prev + 1);
  }, []);
  
  const goToPrevPage = useCallback(() => {
    setPage(prev => Math.max(1, prev - 1));
  }, []);
  
  const goToPage = useCallback((newPage) => {
    setPage(Math.max(1, newPage));
  }, []);
  
  return {
    page,
    pageSize,
    setPage: goToPage,
    setPageSize,
    nextPage: goToNextPage,
    prevPage: goToPrevPage,
    reset,
    offset: (page - 1) * pageSize,
    limit: pageSize
  };
}

/**
 * Hook for managing sort state
 * @param {string} initialSortBy - Initial sort field
 * @param {string} initialDirection - Initial sort direction ('asc' or 'desc')
 * @returns {Object} Sort state and control functions
 * 
 * @example
 * const { sortBy, direction, updateSort, toggleDirection } = useSort('createdAt', 'desc');
 */
export function useSort(initialSortBy = null, initialDirection = 'asc') {
  const [sortBy, setSortBy] = useState(initialSortBy);
  const [direction, setDirection] = useState(initialDirection);
  
  const updateSort = useCallback((field) => {
    if (field === sortBy) {
      // Toggle direction if same field
      setDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      // New field, default to asc
      setSortBy(field);
      setDirection('asc');
    }
  }, [sortBy]);
  
  const toggleDirection = useCallback(() => {
    setDirection(prev => prev === 'asc' ? 'desc' : 'asc');
  }, []);
  
  const reset = useCallback(() => {
    setSortBy(initialSortBy);
    setDirection(initialDirection);
  }, [initialSortBy, initialDirection]);
  
  return {
    sortBy,
    direction,
    updateSort,
    toggleDirection,
    reset,
    isAscending: direction === 'asc',
    isDescending: direction === 'desc'
  };
}
