/**
 * AnalyticsPage.jsx - Detailed Analytics Dashboard
 * 
 * Deep-dive analytics with comparison charts and trend analysis
 */

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Calendar,
  Users,
  Eye,
  Clock,
  MousePointer,
  Target,
  Filter
} from 'lucide-react';
import {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsiveAreaChart
} from '../components/dashboard/charts/ResponsiveCharts';

const pageVariants = {
  initial: { opacity: 0, x: 20 },
  animate: { 
    opacity: 1, 
    x: 0,
    transition: {
      duration: 0.4,
      staggerChildren: 0.08
    }
  },
  exit: { opacity: 0, x: -20, transition: { duration: 0.3 } }
};

const itemVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 }
};

export function AnalyticsPage() {
  const [comparisonMode, setComparisonMode] = useState('previous');
  const [selectedMetric, setSelectedMetric] = useState('all');

  // Enhanced data with comparison
  const monthlyComparison = [
    { month: 'Jan', current: 45000, previous: 38000, target: 50000 },
    { month: 'Feb', current: 52000, previous: 42000, target: 52000 },
    { month: 'Mar', current: 48000, previous: 45000, target: 54000 },
    { month: 'Apr', current: 61000, previous: 48000, target: 56000 },
    { month: 'May', current: 55000, previous: 52000, target: 58000 },
    { month: 'Jun', current: 67000, previous: 55000, target: 60000 }
  ];

  const hourlyData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    visitors: Math.floor(Math.random() * 500) + 100,
    conversions: Math.floor(Math.random() * 50) + 10
  }));

  const deviceData = [
    { device: 'Desktop', sessions: 4520, bounceRate: 42 },
    { device: 'Mobile', sessions: 3840, bounceRate: 38 },
    { device: 'Tablet', sessions: 1260, bounceRate: 45 }
  ];

  const behaviorMetrics = [
    { 
      id: 'pageviews', 
      label: 'Page Views',
      value: '145.2K',
      change: 12.5,
      icon: <Eye />,
      color: 'from-[#FF8C42] to-[#F4C430]'
    },
    {
      id: 'sessions',
      label: 'Sessions',
      value: '9.6K',
      change: 8.2,
      icon: <MousePointer />,
      color: 'from-[#F4C430] to-[#FFB380]'
    },
    {
      id: 'duration',
      label: 'Avg. Duration',
      value: '4:32',
      change: -3.1,
      icon: <Clock />,
      color: 'from-[#FFB380] to-[#FF8C42]'
    },
    {
      id: 'goals',
      label: 'Goal Completions',
      value: '2.1K',
      change: 18.7,
      icon: <Target />,
      color: 'from-[#2C5F6F] to-[#4A8A9F]'
    }
  ];

  return (
    <motion.div
      className="p-6 space-y-6"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* Header */}
      <motion.div variants={itemVariants}>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-[#F5E6D3] mb-2">Analytics</h1>
            <p className="text-[#8A7F6F]">Detailed performance insights and trends</p>
          </div>

          <div className="flex items-center gap-3">
            <motion.button
              className="p-2 rounded-lg bg-[#243947] border border-[#F4C430]/10 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Filter size={20} />
            </motion.button>
            
            <motion.button
              className="p-2 rounded-lg bg-[#243947] border border-[#F4C430]/10 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Calendar size={20} />
            </motion.button>
          </div>
        </div>

        {/* Comparison Mode Toggle */}
        <div className="flex items-center gap-2 bg-[#243947] rounded-lg p-1 border border-[#F4C430]/10 w-fit">
          {['previous', 'target', 'year'].map((mode) => (
            <motion.button
              key={mode}
              onClick={() => setComparisonMode(mode)}
              className={`
                px-4 py-2 rounded-md text-sm font-medium transition-colors capitalize
                ${comparisonMode === mode
                  ? 'bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38]'
                  : 'text-[#C4B5A0] hover:text-[#F5E6D3]'
                }
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              vs {mode}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Behavior Metrics */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        variants={itemVariants}
      >
        {behaviorMetrics.map((metric, index) => (
          <motion.div
            key={metric.id}
            className="relative bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6 overflow-hidden group cursor-pointer"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ delay: index * 0.1, type: 'spring' }}
            whileHover={{ 
              y: -8,
              boxShadow: '0 20px 50px rgba(255, 140, 66, 0.3)',
              borderColor: 'rgba(244, 196, 48, 0.4)'
            }}
            onClick={() => setSelectedMetric(metric.id)}
          >
            <motion.div
              className={`absolute inset-0 bg-gradient-to-br ${metric.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
            />

            <div className="relative z-10">
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${metric.color} flex items-center justify-center shadow-xl mb-4 transform group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300`}>
                <div className="text-[#1A2F38] transform group-hover:scale-110 transition-transform">
                  {metric.icon}
                </div>
              </div>

              <p className="text-sm text-[#C4B5A0] font-medium mb-1">{metric.label}</p>
              <p className="text-3xl font-bold text-[#F5E6D3] mb-3">{metric.value}</p>

              <div className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                metric.change > 0 
                  ? 'bg-[#7BC67E]/15 text-[#7BC67E]'
                  : 'bg-[#FF6B6B]/15 text-[#FF6B6B]'
              }`}>
                <TrendingUp size={12} className={metric.change < 0 ? 'rotate-180' : ''} />
                {Math.abs(metric.change)}%
              </div>
            </div>

            {/* Selection indicator */}
            {selectedMetric === metric.id && (
              <motion.div
                className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#FF8C42] to-[#F4C430]"
                layoutId="selected-metric"
              />
            )}
          </motion.div>
        ))}
      </motion.div>

      {/* Main Comparison Chart */}
      <motion.div
        className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
        variants={itemVariants}
        whileHover={{ boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)' }}
      >
        <div className="mb-6">
          <h3 className="text-xl font-bold text-[#F5E6D3] mb-1">Performance Comparison</h3>
          <p className="text-sm text-[#8A7F6F]">Current vs {comparisonMode} period</p>
        </div>

        <ResponsiveLineChart
          data={monthlyComparison}
          lines={[
            { dataKey: 'current', name: 'Current Period', color: '#FF8C42' },
            { dataKey: comparisonMode, name: `${comparisonMode} Period`, color: '#2C5F6F' }
          ]}
          xAxisKey="month"
          height={400}
          showGrid={true}
          showLegend={true}
          tooltipFormatter={(value) => `$${(value / 1000).toFixed(1)}K`}
          className="border-0 bg-transparent p-0"
        />
      </motion.div>

      {/* Secondary Charts */}
      <motion.div 
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
        variants={itemVariants}
      >
        {/* Hourly Traffic */}
        <motion.div
          className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ 
            boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)',
            borderColor: 'rgba(244, 196, 48, 0.2)'
          }}
        >
          <div className="mb-6">
            <h3 className="text-lg font-bold text-[#F5E6D3]">24-Hour Traffic Pattern</h3>
            <p className="text-sm text-[#8A7F6F]">Visitor activity throughout the day</p>
          </div>

          <ResponsiveAreaChart
            data={hourlyData}
            areas={[
              { dataKey: 'visitors', name: 'Visitors', color: '#FFB380' }
            ]}
            xAxisKey="hour"
            height={300}
            showGrid={true}
            showLegend={false}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>

        {/* Device Breakdown */}
        <motion.div
          className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ 
            boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)',
            borderColor: 'rgba(244, 196, 48, 0.2)'
          }}
        >
          <div className="mb-6">
            <h3 className="text-lg font-bold text-[#F5E6D3]">Device Distribution</h3>
            <p className="text-sm text-[#8A7F6F]">Sessions by device type</p>
          </div>

          <ResponsiveBarChart
            data={deviceData}
            bars={[
              { dataKey: 'sessions', name: 'Sessions', color: '#F4C430' }
            ]}
            xAxisKey="device"
            height={300}
            showGrid={false}
            showLegend={false}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>
      </motion.div>

      {/* Detailed Stats Table */}
      <motion.div
        className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
        variants={itemVariants}
        whileHover={{ boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)' }}
      >
        <div className="mb-6">
          <h3 className="text-lg font-bold text-[#F5E6D3]">Device Performance Details</h3>
          <p className="text-sm text-[#8A7F6F]">Comprehensive metrics by device</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#F4C430]/10">
                <th className="text-left py-3 px-4 text-sm font-semibold text-[#C4B5A0]">Device</th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-[#C4B5A0]">Sessions</th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-[#C4B5A0]">Bounce Rate</th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-[#C4B5A0]">Performance</th>
              </tr>
            </thead>
            <tbody>
              {deviceData.map((row, index) => (
                <motion.tr
                  key={row.device}
                  className="border-b border-[#F4C430]/10 hover:bg-[#1A2F38] transition-colors"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ x: 4 }}
                >
                  <td className="py-4 px-4">
                    <span className="text-[#F5E6D3] font-medium">{row.device}</span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <span className="text-[#F5E6D3]">{row.sessions.toLocaleString()}</span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <span className="text-[#F5E6D3]">{row.bounceRate}%</span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-32 h-2 bg-[#1A2F38] rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-[#FF8C42] to-[#F4C430]"
                          initial={{ width: 0 }}
                          animate={{ width: `${100 - row.bounceRate}%` }}
                          transition={{ duration: 1, delay: index * 0.2 }}
                        />
                      </div>
                      <span className="text-sm text-[#C4B5A0] w-12">{100 - row.bounceRate}%</span>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}
