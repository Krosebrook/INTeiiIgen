/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        'sunset-primary': '#FF8C42',
        'sunset-secondary': '#F4C430',
        'sunset-tertiary': '#FFB380',
        'sky-deep': '#2C5F6F',
        'sky-mid': '#4A8A9F',
      },
    },
  },
  plugins: [],
}
