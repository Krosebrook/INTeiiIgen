/**
 * UsersPage.jsx - User Management with Animated Table
 * 
 * Searchable, filterable user table with modal details and micro-interactions
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Filter,
  Download,
  Plus,
  MoreVertical,
  Edit,
  Trash2,
  Mail,
  Phone,
  MapPin,
  Calendar,
  X,
  Check,
  Clock,
  AlertCircle
} from 'lucide-react';

const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.4, staggerChildren: 0.05 }
  },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
};

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: 20 },
  visible: { 
    opacity: 1, 
    scale: 1, 
    y: 0,
    transition: { type: 'spring', stiffness: 300, damping: 25 }
  },
  exit: { 
    opacity: 0, 
    scale: 0.9, 
    y: 20,
    transition: { duration: 0.2 }
  }
};

export function UsersPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedUser, setSelectedUser] = useState(null);
  const [sortField, setSortField] = useState('name');
  const [sortDirection, setSortDirection] = useState('asc');

  const users = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah.j@example.com',
      role: 'Admin',
      status: 'active',
      avatar: 'SJ',
      joined: '2024-01-15',
      lastActive: '2 hours ago',
      phone: '+1 (555) 123-4567',
      location: 'San Francisco, CA',
      orders: 45,
      spent: 12450
    },
    {
      id: 2,
      name: 'Mike Chen',
      email: 'mike.c@example.com',
      role: 'User',
      status: 'active',
      avatar: 'MC',
      joined: '2024-02-20',
      lastActive: '1 day ago',
      phone: '+1 (555) 234-5678',
      location: 'New York, NY',
      orders: 23,
      spent: 5620
    },
    {
      id: 3,
      name: 'Emma Wilson',
      email: 'emma.w@example.com',
      role: 'User',
      status: 'inactive',
      avatar: 'EW',
      joined: '2023-11-10',
      lastActive: '2 weeks ago',
      phone: '+1 (555) 345-6789',
      location: 'Los Angeles, CA',
      orders: 67,
      spent: 18900
    },
    {
      id: 4,
      name: 'James Brown',
      email: 'james.b@example.com',
      role: 'Manager',
      status: 'active',
      avatar: 'JB',
      joined: '2024-03-05',
      lastActive: '5 hours ago',
      phone: '+1 (555) 456-7890',
      location: 'Chicago, IL',
      orders: 34,
      spent: 8760
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      email: 'lisa.a@example.com',
      role: 'User',
      status: 'pending',
      avatar: 'LA',
      joined: '2024-06-18',
      lastActive: 'Never',
      phone: '+1 (555) 567-8901',
      location: 'Seattle, WA',
      orders: 0,
      spent: 0
    }
  ];

  const statusColors = {
    active: { bg: 'bg-[#7BC67E]/15', text: 'text-[#7BC67E]', icon: <Check size={12} /> },
    inactive: { bg: 'bg-[#8A7F6F]/15', text: 'text-[#8A7F6F]', icon: <Clock size={12} /> },
    pending: { bg: 'bg-[#FFB347]/15', text: 'text-[#FFB347]', icon: <AlertCircle size={12} /> }
  };

  const roleColors = {
    Admin: 'from-[#FF8C42] to-[#F4C430]',
    Manager: 'from-[#FFB380] to-[#F4C430]',
    User: 'from-[#2C5F6F] to-[#4A8A9F]'
  };

  const filteredUsers = users
    .filter(user => {
      const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           user.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = selectedStatus === 'all' || user.status === selectedStatus;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const comparison = aValue > bValue ? 1 : aValue < bValue ? -1 : 0;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  return (
    <motion.div
      className="p-6 space-y-6"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* Header */}
      <motion.div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#F5E6D3] mb-2">Users</h1>
          <p className="text-[#8A7F6F]">Manage and monitor user accounts</p>
        </div>

        <div className="flex items-center gap-3">
          <motion.button
            className="px-4 py-2 bg-[#243947] border border-[#F4C430]/10 text-[#C4B5A0] hover:text-[#F5E6D3] rounded-lg flex items-center gap-2 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Download size={16} />
            Export
          </motion.button>

          <motion.button
            className="px-4 py-2 bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] rounded-lg font-medium flex items-center gap-2 shadow-lg shadow-[#FF8C42]/20"
            whileHover={{ scale: 1.05, boxShadow: '0 8px 30px rgba(255, 140, 66, 0.4)' }}
            whileTap={{ scale: 0.95 }}
          >
            <Plus size={16} />
            Add User
          </motion.button>
        </div>
      </motion.div>

      {/* Filters */}
      <motion.div 
        className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8A7F6F]" size={18} />
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#1A2F38] border border-[#F4C430]/10 rounded-lg text-[#F5E6D3] placeholder-[#8A7F6F] focus:outline-none focus:border-[#FF8C42] transition-colors"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            {['all', 'active', 'inactive', 'pending'].map((status) => (
              <motion.button
                key={status}
                onClick={() => setSelectedStatus(status)}
                className={`
                  px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors
                  ${selectedStatus === status
                    ? 'bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38]'
                    : 'bg-[#1A2F38] text-[#C4B5A0] hover:text-[#F5E6D3]'
                  }
                `}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {status}
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Users Table */}
      <motion.div
        className="bg-[#243947] rounded-xl border border-[#F4C430]/10 overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1A2F38] border-b border-[#F4C430]/10">
              <tr>
                <th 
                  className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0] cursor-pointer hover:text-[#F5E6D3] transition-colors"
                  onClick={() => handleSort('name')}
                >
                  User
                </th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Role</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Status</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Last Active</th>
                <th className="text-right py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Orders</th>
                <th className="text-right py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Spent</th>
                <th className="text-center py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Actions</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {filteredUsers.map((user, index) => (
                  <motion.tr
                    key={user.id}
                    className="border-b border-[#F4C430]/10 hover:bg-[#1A2F38] transition-colors cursor-pointer"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => setSelectedUser(user)}
                    whileHover={{ x: 4 }}
                  >
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <motion.div 
                          className={`w-10 h-10 rounded-full bg-gradient-to-br ${roleColors[user.role]} flex items-center justify-center shadow-lg text-[#1A2F38] font-bold text-sm`}
                          whileHover={{ scale: 1.1, rotate: 5 }}
                        >
                          {user.avatar}
                        </motion.div>
                        <div>
                          <p className="text-[#F5E6D3] font-medium">{user.name}</p>
                          <p className="text-xs text-[#8A7F6F]">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${roleColors[user.role]} text-[#1A2F38]`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[user.status].bg} ${statusColors[user.status].text}`}>
                        {statusColors[user.status].icon}
                        {user.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-[#C4B5A0] text-sm">{user.lastActive}</td>
                    <td className="py-4 px-6 text-right text-[#F5E6D3] font-medium">{user.orders}</td>
                    <td className="py-4 px-6 text-right text-[#F5E6D3] font-medium">${user.spent.toLocaleString()}</td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center gap-2">
                        <motion.button
                          className="p-1.5 rounded-lg hover:bg-[#2C4753] text-[#8A7F6F] hover:text-[#F5E6D3] transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            console.log('Edit', user.id);
                          }}
                        >
                          <Edit size={14} />
                        </motion.button>
                        <motion.button
                          className="p-1.5 rounded-lg hover:bg-[#FF6B6B]/10 text-[#8A7F6F] hover:text-[#FF6B6B] transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            console.log('Delete', user.id);
                          }}
                        >
                          <Trash2 size={14} />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* User Detail Modal */}
      <AnimatePresence>
        {selectedUser && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/60 z-50 backdrop-blur-sm flex items-center justify-center p-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedUser(null)}
            >
              {/* Modal */}
              <motion.div
                className="bg-[#243947] rounded-2xl border border-[#F4C430]/20 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
                variants={modalVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Modal Header */}
                <div className="sticky top-0 bg-[#243947] border-b border-[#F4C430]/10 p-6 flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <motion.div 
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${roleColors[selectedUser.role]} flex items-center justify-center shadow-xl text-[#1A2F38] font-bold text-xl`}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                      transition={{ type: 'spring', stiffness: 200 }}
                    >
                      {selectedUser.avatar}
                    </motion.div>
                    <div>
                      <h2 className="text-2xl font-bold text-[#F5E6D3]">{selectedUser.name}</h2>
                      <p className="text-sm text-[#8A7F6F]">{selectedUser.email}</p>
                    </div>
                  </div>
                  
                  <motion.button
                    onClick={() => setSelectedUser(null)}
                    className="p-2 rounded-lg hover:bg-[#1A2F38] text-[#8A7F6F] hover:text-[#F5E6D3] transition-colors"
                    whileHover={{ scale: 1.1, rotate: 90 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <X size={20} />
                  </motion.button>
                </div>

                {/* Modal Content */}
                <div className="p-6 space-y-6">
                  {/* Contact Info */}
                  <motion.div
                    className="grid grid-cols-1 md:grid-cols-2 gap-4"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                  >
                    <div className="flex items-center gap-3 p-4 bg-[#1A2F38] rounded-lg">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center">
                        <Mail size={18} className="text-[#1A2F38]" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8A7F6F]">Email</p>
                        <p className="text-sm text-[#F5E6D3] font-medium">{selectedUser.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-[#1A2F38] rounded-lg">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FFB380] to-[#F4C430] flex items-center justify-center">
                        <Phone size={18} className="text-[#1A2F38]" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8A7F6F]">Phone</p>
                        <p className="text-sm text-[#F5E6D3] font-medium">{selectedUser.phone}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-[#1A2F38] rounded-lg">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#2C5F6F] to-[#4A8A9F] flex items-center justify-center">
                        <MapPin size={18} className="text-[#1A2F38]" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8A7F6F]">Location</p>
                        <p className="text-sm text-[#F5E6D3] font-medium">{selectedUser.location}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-[#1A2F38] rounded-lg">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#F4C430] to-[#FFB380] flex items-center justify-center">
                        <Calendar size={18} className="text-[#1A2F38]" />
                      </div>
                      <div>
                        <p className="text-xs text-[#8A7F6F]">Joined</p>
                        <p className="text-sm text-[#F5E6D3] font-medium">{selectedUser.joined}</p>
                      </div>
                    </div>
                  </motion.div>

                  {/* Stats */}
                  <motion.div
                    className="grid grid-cols-3 gap-4"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="text-center p-4 bg-[#1A2F38] rounded-lg">
                      <p className="text-2xl font-bold text-[#F5E6D3]">{selectedUser.orders}</p>
                      <p className="text-xs text-[#8A7F6F]">Total Orders</p>
                    </div>
                    <div className="text-center p-4 bg-[#1A2F38] rounded-lg">
                      <p className="text-2xl font-bold text-[#F5E6D3]">${selectedUser.spent.toLocaleString()}</p>
                      <p className="text-xs text-[#8A7F6F]">Total Spent</p>
                    </div>
                    <div className="text-center p-4 bg-[#1A2F38] rounded-lg">
                      <p className="text-2xl font-bold text-[#F5E6D3]">${Math.round(selectedUser.spent / (selectedUser.orders || 1))}</p>
                      <p className="text-xs text-[#8A7F6F]">Avg. Order</p>
                    </div>
                  </motion.div>

                  {/* Actions */}
                  <motion.div
                    className="flex gap-3"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <motion.button
                      className="flex-1 px-4 py-3 bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] rounded-lg font-medium shadow-lg shadow-[#FF8C42]/20"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Edit User
                    </motion.button>
                    <motion.button
                      className="px-4 py-3 bg-[#1A2F38] border border-[#FF6B6B]/30 text-[#FF6B6B] rounded-lg font-medium hover:bg-[#FF6B6B]/10 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Delete
                    </motion.button>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
