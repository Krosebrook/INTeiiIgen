/**
 * Dashboard Layout Components
 * 
 * Composable layout primitives for building dashboard pages
 */

import React from 'react';
import { motion } from 'framer-motion';
import { Menu, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

// ========================================
// DashboardGrid - Responsive grid layout
// ========================================

export function DashboardGrid({
  children,
  columns = 3, // 1 | 2 | 3 | 4 | 6 | 12
  gap = 'md', // 'sm' | 'md' | 'lg'
  className = ''
}) {
  const gapClasses = {
    sm: 'gap-2',
    md: 'gap-4',
    lg: 'gap-6'
  };
  
  // Responsive column classes
  const gridClasses = cn(
    'grid',
    gapClasses[gap],
    // Mobile: always single column
    'grid-cols-1',
    // Tablet: half of desktop columns (min 1, max 2)
    columns >= 3 ? 'md:grid-cols-2' : `md:grid-cols-${columns}`,
    // Desktop: full column count
    `lg:grid-cols-${columns}`,
    className
  );
  
  return (
    <div className={gridClasses}>
      {children}
    </div>
  );
}

// Grid item with custom span
export function DashboardGridItem({
  children,
  colSpan = 1,
  rowSpan = 1,
  className = ''
}) {
  const spanClasses = cn(
    colSpan > 1 && `lg:col-span-${colSpan}`,
    rowSpan > 1 && `lg:row-span-${rowSpan}`,
    className
  );
  
  return <div className={spanClasses}>{children}</div>;
}

// ========================================
// DashboardShell - Full page layout with sidebar
// ========================================

export function DashboardShell({
  children,
  sidebar = null,
  header = null,
  sidebarOpen = true,
  onSidebarToggle = null,
  className = ''
}) {
  return (
    <div className={cn('min-h-screen bg-black', className)}>
      {/* Header */}
      {header && (
        <div className="sticky top-0 z-40 border-b-2 border-neutral-800">
          {header}
        </div>
      )}
      
      {/* Main layout */}
      <div className="flex">
        {/* Sidebar */}
        {sidebar && (
          <>
            {/* Mobile backdrop */}
            {sidebarOpen && (
              <motion.div
                className="fixed inset-0 bg-black/80 z-30 lg:hidden"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onSidebarToggle}
              />
            )}
            
            {/* Sidebar content */}
            <motion.aside
              className={cn(
                'fixed lg:sticky top-0 h-screen z-40',
                'bg-[#1a1a1a] border-r-2 border-neutral-800',
                'overflow-y-auto',
                'transition-all duration-200',
                sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
                sidebarOpen ? 'w-64' : 'lg:w-16'
              )}
              initial={false}
              animate={{
                width: sidebarOpen ? 256 : 64
              }}
            >
              {sidebar}
            </motion.aside>
          </>
        )}
        
        {/* Main content */}
        <main className="flex-1 min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
}

// ========================================
// DashboardHeader - Top navigation bar
// ========================================

export function DashboardHeader({
  title,
  subtitle = null,
  actions = null,
  showSidebarToggle = true,
  onSidebarToggle = null,
  breadcrumbs = null,
  className = ''
}) {
  return (
    <header className={cn(
      'bg-[#1a1a1a] px-4 py-4 flex items-center justify-between gap-4',
      className
    )}>
      {/* Left section */}
      <div className="flex items-center gap-4 flex-1 min-w-0">
        {/* Sidebar toggle */}
        {showSidebarToggle && onSidebarToggle && (
          <button
            onClick={onSidebarToggle}
            className="p-2 hover:bg-neutral-800 transition-colors lg:hidden"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-5 h-5 text-neutral-400" />
          </button>
        )}
        
        {/* Title section */}
        <div className="flex-1 min-w-0">
          {breadcrumbs && (
            <div className="flex items-center gap-2 mb-1 text-xs text-neutral-500 font-mono">
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={index}>
                  {index > 0 && <ChevronRight className="w-3 h-3" />}
                  {crumb.href ? (
                    <a
                      href={crumb.href}
                      className="hover:text-[#00bfff] transition-colors"
                    >
                      {crumb.label}
                    </a>
                  ) : (
                    <span>{crumb.label}</span>
                  )}
                </React.Fragment>
              ))}
            </div>
          )}
          
          <div className="flex items-baseline gap-3">
            <h1 className="text-xl font-mono font-bold text-white truncate">
              {title}
            </h1>
            {subtitle && (
              <span className="text-sm text-neutral-500 font-mono hidden sm:inline">
                {subtitle}
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Right section - actions */}
      {actions && (
        <div className="flex items-center gap-2 flex-shrink-0">
          {actions}
        </div>
      )}
    </header>
  );
}

// ========================================
// DashboardSidebar - Navigation sidebar
// ========================================

export function DashboardSidebar({
  logo = null,
  navigation = [],
  footer = null,
  collapsed = false,
  onCollapse = null,
  className = ''
}) {
  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Logo section */}
      {logo && (
        <div className="p-4 border-b-2 border-neutral-800">
          <div className="flex items-center justify-between">
            <div className={cn(
              'transition-all duration-200',
              collapsed && 'opacity-0 w-0'
            )}>
              {logo}
            </div>
            
            {onCollapse && (
              <button
                onClick={onCollapse}
                className="hidden lg:block p-1 hover:bg-neutral-800 transition-colors"
                aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              >
                {collapsed ? (
                  <ChevronRight className="w-5 h-5 text-neutral-400" />
                ) : (
                  <ChevronLeft className="w-5 h-5 text-neutral-400" />
                )}
              </button>
            )}
          </div>
        </div>
      )}
      
      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-2">
        {navigation.map((item, index) => (
          <SidebarNavItem
            key={item.id || index}
            {...item}
            collapsed={collapsed}
          />
        ))}
      </nav>
      
      {/* Footer section */}
      {footer && (
        <div className="p-4 border-t-2 border-neutral-800">
          {footer}
        </div>
      )}
    </div>
  );
}

// Sidebar navigation item
function SidebarNavItem({
  label,
  icon = null,
  href = '#',
  active = false,
  badge = null,
  collapsed = false,
  onClick = null
}) {
  const itemClasses = cn(
    'flex items-center gap-3 px-3 py-2 mb-1 font-mono text-sm transition-colors',
    'hover:bg-neutral-800',
    active ? 'bg-neutral-800 text-[#00bfff] border-l-2 border-[#00bfff]' : 'text-neutral-400',
    collapsed && 'justify-center'
  );
  
  const content = (
    <>
      {icon && (
        <span className="flex-shrink-0 w-5 h-5">
          {icon}
        </span>
      )}
      
      {!collapsed && (
        <>
          <span className="flex-1 truncate">{label}</span>
          
          {badge && (
            <span className="flex-shrink-0 px-1.5 py-0.5 bg-[#00bfff] text-black text-xs font-bold">
              {badge}
            </span>
          )}
        </>
      )}
    </>
  );
  
  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={cn(itemClasses, 'w-full')}
        aria-label={label}
      >
        {content}
      </button>
    );
  }
  
  return (
    <a
      href={href}
      className={itemClasses}
      aria-label={label}
    >
      {content}
    </a>
  );
}

// Container for dashboard content with padding
export function DashboardContent({
  children,
  maxWidth = '7xl', // 'none' | '2xl' | '4xl' | '7xl' | 'full'
  className = ''
}) {
  const widthClasses = {
    none: '',
    '2xl': 'max-w-2xl',
    '4xl': 'max-w-4xl',
    '7xl': 'max-w-7xl',
    full: 'max-w-full'
  };
  
  return (
    <div className={cn(
      'p-4 md:p-6 lg:p-8',
      maxWidth !== 'none' && 'mx-auto',
      widthClasses[maxWidth],
      className
    )}>
      {children}
    </div>
  );
}

// Section within dashboard content
export function DashboardSection({
  title = null,
  subtitle = null,
  actions = null,
  children,
  className = ''
}) {
  return (
    <section className={cn('mb-8', className)}>
      {(title || subtitle || actions) && (
        <div className="flex items-start justify-between mb-4">
          <div>
            {title && (
              <h2 className="text-lg font-mono font-bold text-white mb-1">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="text-sm text-neutral-500 font-mono">
                {subtitle}
              </p>
            )}
          </div>
          
          {actions && (
            <div className="flex items-center gap-2">
              {actions}
            </div>
          )}
        </div>
      )}
      
      {children}
    </section>
  );
}

export default {
  DashboardGrid,
  DashboardGridItem,
  DashboardShell,
  DashboardHeader,
  DashboardSidebar,
  DashboardContent,
  DashboardSection
};
