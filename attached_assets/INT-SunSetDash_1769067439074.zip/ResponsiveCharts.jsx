/**
 * Responsive Chart Components - Sunset Brand
 * 
 * Recharts-based chart wrappers with warm sunset styling
 * Fully responsive and accessible
 */

import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { cn } from '@/lib/utils';

// Sunset color palette
const COLORS = {
  primary: '#FF8C42',      // Sunset orange
  secondary: '#F4C430',    // Golden yellow
  tertiary: '#2C5F6F',     // Deep teal
  quaternary: '#7BC67E',   // Soft green
  quinary: '#FFB380',      // Peachy salmon
  success: '#7BC67E',
  warning: '#FFB347',
  error: '#FF6B6B',
  info: '#4A8A9F'
};

const CHART_COLORS = [
  COLORS.primary,
  COLORS.secondary,
  COLORS.tertiary,
  COLORS.quaternary,
  COLORS.quinary
];

// Custom tooltip component with sunset styling
function CustomTooltip({ active, payload, label, formatter }) {
  if (!active || !payload || !payload.length) return null;
  
  return (
    <div className="bg-[#2C4753] border border-[#F4C430]/20 rounded-lg p-3 shadow-xl">
      <div className="text-xs text-[#C4B5A0] mb-2 uppercase tracking-wide font-medium">
        {label}
      </div>
      {payload.map((entry, index) => (
        <div key={index} className="flex items-center gap-2 text-sm mb-1 last:mb-0">
          <div
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-[#F5E6D3]">{entry.name}:</span>
          <span className="text-[#F5E6D3] font-semibold ml-auto">
            {formatter ? formatter(entry.value) : entry.value}
          </span>
        </div>
      ))}
    </div>
  );
}

// ========================================
// ResponsiveLineChart
// ========================================

export function ResponsiveLineChart({
  data,
  lines,
  xAxisKey = 'date',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-[#8A7F6F] text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 transition-all duration-300 hover:border-[#F4C430]/30', className)}
      role="img"
      aria-label={ariaLabel || 'Line chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(244, 196, 48, 0.1)"
              vertical={false}
            />
          )}
          
          <XAxis
            dataKey={xAxisKey}
            stroke="#8A7F6F"
            style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
            tick={{ fill: '#C4B5A0' }}
          />
          
          <YAxis
            stroke="#8A7F6F"
            style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
            tick={{ fill: '#C4B5A0' }}
          />
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ stroke: '#FF8C42', strokeWidth: 2 }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '12px',
                paddingTop: '20px',
                color: '#F5E6D3'
              }}
            />
          )}
          
          {lines.map((line, index) => (
            <Line
              key={line.dataKey}
              type="monotone"
              dataKey={line.dataKey}
              name={line.name || line.dataKey}
              stroke={line.color || CHART_COLORS[index % CHART_COLORS.length]}
              strokeWidth={3}
              dot={{ fill: line.color || CHART_COLORS[index % CHART_COLORS.length], r: 4, strokeWidth: 2, stroke: '#243947' }}
              activeDot={{ r: 6, strokeWidth: 2, stroke: '#243947' }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsiveBarChart
// ========================================

export function ResponsiveBarChart({
  data,
  bars,
  xAxisKey = 'category',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  stacked = false,
  horizontal = false,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-[#8A7F6F] text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  const layout = horizontal ? 'horizontal' : 'vertical';
  
  return (
    <div
      className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 transition-all duration-300 hover:border-[#F4C430]/30', className)}
      role="img"
      aria-label={ariaLabel || 'Bar chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} layout={layout}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(244, 196, 48, 0.1)"
              horizontal={!horizontal}
              vertical={horizontal}
            />
          )}
          
          {horizontal ? (
            <>
              <XAxis
                type="number"
                stroke="#8A7F6F"
                style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
                tick={{ fill: '#C4B5A0' }}
              />
              <YAxis
                dataKey={xAxisKey}
                type="category"
                stroke="#8A7F6F"
                style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
                tick={{ fill: '#C4B5A0' }}
              />
            </>
          ) : (
            <>
              <XAxis
                dataKey={xAxisKey}
                stroke="#8A7F6F"
                style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
                tick={{ fill: '#C4B5A0' }}
              />
              <YAxis
                stroke="#8A7F6F"
                style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
                tick={{ fill: '#C4B5A0' }}
              />
            </>
          )}
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ fill: 'rgba(255, 140, 66, 0.1)' }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
          
          {bars.map((bar, index) => (
            <Bar
              key={bar.dataKey}
              dataKey={bar.dataKey}
              name={bar.name || bar.dataKey}
              fill={bar.color || CHART_COLORS[index % CHART_COLORS.length]}
              stackId={stacked ? 'stack' : undefined}
              radius={[4, 4, 0, 0]}
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsiveAreaChart
// ========================================

export function ResponsiveAreaChart({
  data,
  areas,
  xAxisKey = 'date',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  stacked = false,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-[#8A7F6F] text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 transition-all duration-300 hover:border-[#F4C430]/30', className)}
      role="img"
      aria-label={ariaLabel || 'Area chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={data}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(244, 196, 48, 0.1)"
              vertical={false}
            />
          )}
          
          <XAxis
            dataKey={xAxisKey}
            stroke="#8A7F6F"
            style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
            tick={{ fill: '#C4B5A0' }}
          />
          
          <YAxis
            stroke="#8A7F6F"
            style={{ fontFamily: 'Inter, sans-serif', fontSize: '12px' }}
            tick={{ fill: '#C4B5A0' }}
          />
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ stroke: '#FF8C42', strokeWidth: 2 }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
          
          {areas.map((area, index) => {
            const color = area.color || CHART_COLORS[index % CHART_COLORS.length];
            return (
              <Area
                key={area.dataKey}
                type="monotone"
                dataKey={area.dataKey}
                name={area.name || area.dataKey}
                stroke={color}
                fill={color}
                fillOpacity={0.3}
                strokeWidth={3}
                stackId={stacked ? 'stack' : undefined}
              />
            );
          })}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsivePieChart
// ========================================

export function ResponsivePieChart({
  data,
  dataKey = 'value',
  nameKey = 'name',
  height = 300,
  showLegend = true,
  showTooltip = true,
  showLabels = true,
  tooltipFormatter = null,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-[#8A7F6F] text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  const renderLabel = (entry) => {
    if (!showLabels) return null;
    return entry[nameKey];
  };
  
  return (
    <div
      className={cn('bg-[#243947] border border-[#F4C430]/10 rounded-lg p-6 transition-all duration-300 hover:border-[#F4C430]/30', className)}
      role="img"
      aria-label={ariaLabel || 'Pie chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie
            data={data}
            dataKey={dataKey}
            nameKey={nameKey}
            cx="50%"
            cy="50%"
            outerRadius={80}
            label={renderLabel}
            labelLine={showLabels}
            labelStyle={{
              fontSize: '12px',
              fontFamily: 'Inter, sans-serif',
              fill: '#F5E6D3'
            }}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={CHART_COLORS[index % CHART_COLORS.length]}
                stroke="#243947"
                strokeWidth={2}
              />
            ))}
          </Pie>
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'Inter, sans-serif',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// MiniSparkline - Compact trend line
// ========================================

export function MiniSparkline({
  data,
  dataKey = 'value',
  color = COLORS.primary,
  height = 40,
  className = '',
  'aria-label': ariaLabel
}) {
  if (!data || data.length === 0) return null;
  
  return (
    <div
      className={cn('inline-block', className)}
      role="img"
      aria-label={ariaLabel || 'Trend sparkline'}
    >
      <ResponsiveContainer width={100} height={height}>
        <LineChart data={data}>
          <Line
            type="monotone"
            dataKey={dataKey}
            stroke={color}
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsiveAreaChart,
  ResponsivePieChart,
  MiniSparkline
};
