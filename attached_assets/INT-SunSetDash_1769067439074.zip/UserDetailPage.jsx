import React from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, MapPin, Calendar, DollarSign, ShoppingCart } from 'lucide-react';
import { ResponsiveLineChart } from '../components/dashboard/charts/ResponsiveCharts';

export function UserDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const activityData = [
    { month: 'Jan', orders: 5, spent: 1200 },
    { month: 'Feb', orders: 8, spent: 1800 },
    { month: 'Mar', orders: 6, spent: 1500 },
    { month: 'Apr', orders: 10, spent: 2400 },
    { month: 'May', orders: 7, spent: 1900 },
    { month: 'Jun', orders: 12, spent: 2800 }
  ];

  return (
    <motion.div
      className="p-6 space-y-6"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.4 }}
    >
      <button
        onClick={() => navigate('/users')}
        className="flex items-center gap-2 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors mb-4"
      >
        <ArrowLeft size={20} />
        Back to Users
      </button>

      <div className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-8">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center shadow-xl text-[#1A2F38] font-bold text-2xl">
            U{id}
          </div>
          <div>
            <h1 className="text-3xl font-bold text-[#F5E6D3] mb-2">User #{id}</h1>
            <p className="text-[#8A7F6F]">Detailed user profile and activity</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: <Mail />, label: 'Email', value: 'user@example.com', color: 'from-[#FF8C42] to-[#F4C430]' },
            { icon: <Phone />, label: 'Phone', value: '+1 (555) 123-4567', color: 'from-[#F4C430] to-[#FFB380]' },
            { icon: <MapPin />, label: 'Location', value: 'San Francisco, CA', color: 'from-[#FFB380] to-[#FF8C42]' },
            { icon: <Calendar />, label: 'Joined', value: 'Jan 15, 2024', color: 'from-[#2C5F6F] to-[#4A8A9F]' }
          ].map((item, i) => (
            <motion.div
              key={i}
              className="bg-[#1A2F38] rounded-xl p-4 flex items-center gap-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center shadow-lg`}>
                <div className="text-[#1A2F38]">{item.icon}</div>
              </div>
              <div>
                <p className="text-xs text-[#8A7F6F]">{item.label}</p>
                <p className="text-sm font-medium text-[#F5E6D3]">{item.value}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Total Orders', value: '48', icon: <ShoppingCart />, color: 'from-[#FF8C42] to-[#F4C430]' },
            { label: 'Total Spent', value: '$11.6K', icon: <DollarSign />, color: 'from-[#F4C430] to-[#FFB380]' },
            { label: 'Avg Order', value: '$242', icon: <DollarSign />, color: 'from-[#2C5F6F] to-[#4A8A9F]' }
          ].map((stat, i) => (
            <motion.div
              key={i}
              className="bg-[#1A2F38] rounded-xl p-6"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + i * 0.1 }}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#8A7F6F]">{stat.label}</span>
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <div className="text-[#1A2F38]">{React.cloneElement(stat.icon, { size: 16 })}</div>
                </div>
              </div>
              <p className="text-3xl font-bold text-[#F5E6D3]">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h3 className="text-xl font-bold text-[#F5E6D3] mb-4">Activity Overview</h3>
          <ResponsiveLineChart
            data={activityData}
            lines={[
              { dataKey: 'spent', name: 'Spent ($)', color: '#FF8C42' },
              { dataKey: 'orders', name: 'Orders', color: '#2C5F6F' }
            ]}
            xAxisKey="month"
            height={300}
            className="border-0 bg-[#1A2F38] p-4 rounded-xl"
          />
        </motion.div>
      </div>
    </motion.div>
  );
}
