/**
 * Dashboard Component Library
 * 
 * Production-grade dashboard components for Base44 app
 * Built with React 18 + Tailwind CSS + shadcn/ui
 * 
 * @version 1.0.0
 * @design Geometric Brutalist
 */

// Primitives
export { StatsCard } from './primitives/StatsCard';
export { MetricDisplay } from './primitives/MetricDisplay';
export { KPICard } from './primitives/KPICard';
export { TrendIndicator } from './primitives/TrendIndicator';
export { BadgeChip } from './primitives/BadgeChip';

// Charts
export { ResponsiveLineChart } from './charts/ResponsiveLineChart';
export { ResponsiveBarChart } from './charts/ResponsiveBarChart';
export { ResponsivePieChart } from './charts/ResponsivePieChart';
export { ResponsiveAreaChart } from './charts/ResponsiveAreaChart';
export { MiniSparkline } from './charts/MiniSparkline';

// Layouts
export { DashboardGrid } from './layouts/DashboardGrid';
export { DashboardShell } from './layouts/DashboardShell';
export { DashboardHeader } from './layouts/DashboardHeader';
export { DashboardSidebar } from './layouts/DashboardSidebar';

// Data Display
export { DataTable } from './data/DataTable';
export { DataList } from './data/DataList';
export { EmptyState } from './data/EmptyState';
export { LoadingState } from './data/LoadingState';
export { ErrorState } from './data/ErrorState';

// Utilities
export { useDashboardData } from './lib/hooks/useDashboardData';
export { useDashboardFilters } from './lib/hooks/useDashboardFilters';
export { formatMetric, formatPercent, formatCurrency } from './lib/utils/formatters';

// Types
export * from './lib/types';
