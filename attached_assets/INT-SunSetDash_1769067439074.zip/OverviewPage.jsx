/**
 * OverviewPage.jsx - Main Dashboard Overview
 * 
 * High-fidelity dashboard with animated metrics, charts, and micro-interactions
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  ShoppingCart,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  MoreVertical,
  Download
} from 'lucide-react';
import {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsivePieChart,
  ResponsiveAreaChart
} from '../components/dashboard/charts/ResponsiveCharts';

// Page transition animations
const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { 
    opacity: 1, 
    y: 0,
    transition: {
      duration: 0.4,
      staggerChildren: 0.1
    }
  },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
};

const cardVariants = {
  initial: { opacity: 0, y: 20, scale: 0.95 },
  animate: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: { type: 'spring', stiffness: 100, damping: 15 }
  }
};

export function OverviewPage() {
  const [selectedPeriod, setSelectedPeriod] = useState('7d');
  const [animatedValues, setAnimatedValues] = useState({
    revenue: 0,
    users: 0,
    orders: 0,
    conversion: 0
  });

  // Animate counter values on mount
  useEffect(() => {
    const targets = {
      revenue: 84253,
      users: 2847,
      orders: 1432,
      conversion: 3.47
    };

    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;

    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep++;
      const progress = currentStep / steps;
      const easeOut = 1 - Math.pow(1 - progress, 3); // Cubic ease-out

      setAnimatedValues({
        revenue: Math.floor(targets.revenue * easeOut),
        users: Math.floor(targets.users * easeOut),
        orders: Math.floor(targets.orders * easeOut),
        conversion: (targets.conversion * easeOut).toFixed(2)
      });

      if (currentStep >= steps) {
        clearInterval(timer);
        setAnimatedValues(targets);
      }
    }, interval);

    return () => clearInterval(timer);
  }, []);

  // Mock data
  const revenueData = [
    { date: 'Mon', revenue: 45000, target: 40000 },
    { date: 'Tue', revenue: 52000, target: 45000 },
    { date: 'Wed', revenue: 48000, target: 47000 },
    { date: 'Thu', revenue: 61000, target: 50000 },
    { date: 'Fri', revenue: 55000, target: 52000 },
    { date: 'Sat', revenue: 67000, target: 55000 },
    { date: 'Sun', revenue: 70000, target: 60000 }
  ];

  const categoryData = [
    { name: 'Electronics', value: 4500 },
    { name: 'Clothing', value: 3200 },
    { name: 'Home & Garden', value: 2800 },
    { name: 'Books', value: 1900 },
    { name: 'Sports', value: 1600 }
  ];

  const trafficData = [
    { source: 'Organic', value: 42 },
    { source: 'Direct', value: 28 },
    { source: 'Social', value: 18 },
    { source: 'Email', value: 12 }
  ];

  const stats = [
    {
      id: 'revenue',
      label: 'Total Revenue',
      value: `$${(animatedValues.revenue / 1000).toFixed(1)}K`,
      change: 23.5,
      icon: <DollarSign />,
      color: 'from-[#FF8C42] to-[#F4C430]'
    },
    {
      id: 'users',
      label: 'Active Users',
      value: animatedValues.users.toLocaleString(),
      change: 12.3,
      icon: <Users />,
      color: 'from-[#F4C430] to-[#FFB380]'
    },
    {
      id: 'orders',
      label: 'Total Orders',
      value: animatedValues.orders.toLocaleString(),
      change: -2.4,
      icon: <ShoppingCart />,
      color: 'from-[#FFB380] to-[#FF8C42]'
    },
    {
      id: 'conversion',
      label: 'Conversion Rate',
      value: `${animatedValues.conversion}%`,
      change: 5.1,
      icon: <Activity />,
      color: 'from-[#2C5F6F] to-[#4A8A9F]'
    }
  ];

  const recentActivity = [
    { id: 1, type: 'sale', user: 'Sarah Johnson', amount: '$1,234', time: '2 min ago', status: 'completed' },
    { id: 2, type: 'user', user: 'Mike Chen', amount: 'New signup', time: '5 min ago', status: 'new' },
    { id: 3, type: 'sale', user: 'Emma Wilson', amount: '$892', time: '12 min ago', status: 'completed' },
    { id: 4, type: 'sale', user: 'James Brown', amount: '$2,456', time: '24 min ago', status: 'pending' },
    { id: 5, type: 'user', user: 'Lisa Anderson', amount: 'New signup', time: '1 hour ago', status: 'new' }
  ];

  return (
    <motion.div
      className="p-6 space-y-6"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* Header */}
      <motion.div variants={cardVariants} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#F5E6D3] mb-2">Dashboard Overview</h1>
          <p className="text-[#8A7F6F]">Welcome back! Here's what's happening today.</p>
        </div>
        
        <div className="flex items-center gap-3">
          {/* Period Selector */}
          <div className="flex items-center gap-2 bg-[#243947] rounded-lg p-1 border border-[#F4C430]/10">
            {['24h', '7d', '30d', '90d'].map((period) => (
              <motion.button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`
                  px-4 py-2 rounded-md text-sm font-medium transition-colors
                  ${selectedPeriod === period
                    ? 'bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38]'
                    : 'text-[#C4B5A0] hover:text-[#F5E6D3]'
                  }
                `}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {period}
              </motion.button>
            ))}
          </div>

          <motion.button
            className="px-4 py-2 bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] rounded-lg font-medium flex items-center gap-2 shadow-lg shadow-[#FF8C42]/20"
            whileHover={{ scale: 1.05, boxShadow: '0 8px 30px rgba(255, 140, 66, 0.4)' }}
            whileTap={{ scale: 0.95 }}
          >
            <Download size={16} />
            Export
          </motion.button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        variants={cardVariants}
      >
        {stats.map((stat, index) => (
          <motion.div
            key={stat.id}
            className="relative bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6 overflow-hidden group"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, type: 'spring' }}
            whileHover={{ 
              y: -8, 
              boxShadow: '0 12px 40px rgba(255, 140, 66, 0.2)',
              borderColor: 'rgba(244, 196, 48, 0.3)'
            }}
          >
            {/* Gradient accent */}
            <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${stat.color}`} />
            
            {/* Glow effect on hover */}
            <motion.div
              className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
            />

            <div className="relative z-10">
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <div className="text-[#1A2F38]">
                    {stat.icon}
                  </div>
                </div>
                
                <motion.button
                  className="p-1 rounded-lg hover:bg-[#1A2F38] text-[#8A7F6F] transition-colors"
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <MoreVertical size={16} />
                </motion.button>
              </div>

              <div className="space-y-1 mb-3">
                <p className="text-sm text-[#C4B5A0] font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-[#F5E6D3]">{stat.value}</p>
              </div>

              <div className="flex items-center gap-2">
                {stat.change > 0 ? (
                  <div className="flex items-center gap-1 px-2 py-1 bg-[#7BC67E]/15 text-[#7BC67E] rounded-full text-xs font-semibold">
                    <ArrowUpRight size={12} />
                    {stat.change}%
                  </div>
                ) : (
                  <div className="flex items-center gap-1 px-2 py-1 bg-[#FF6B6B]/15 text-[#FF6B6B] rounded-full text-xs font-semibold">
                    <ArrowDownRight size={12} />
                    {Math.abs(stat.change)}%
                  </div>
                )}
                <span className="text-xs text-[#8A7F6F]">vs last period</span>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Charts Row */}
      <motion.div 
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
        variants={cardVariants}
      >
        {/* Revenue Chart */}
        <motion.div
          className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ boxShadow: '0 8px 30px rgba(0, 0, 0, 0.2)' }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-[#F5E6D3]">Revenue Overview</h3>
              <p className="text-sm text-[#8A7F6F]">Last 7 days performance</p>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#FF8C42]" />
                <span className="text-[#C4B5A0]">Actual</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#2C5F6F]" />
                <span className="text-[#C4B5A0]">Target</span>
              </div>
            </div>
          </div>
          
          <ResponsiveAreaChart
            data={revenueData}
            areas={[
              { dataKey: 'revenue', name: 'Revenue', color: '#FF8C42' },
              { dataKey: 'target', name: 'Target', color: '#2C5F6F' }
            ]}
            xAxisKey="date"
            height={300}
            showGrid={true}
            showLegend={false}
            tooltipFormatter={(value) => `$${(value / 1000).toFixed(1)}K`}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>

        {/* Category Distribution */}
        <motion.div
          className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ boxShadow: '0 8px 30px rgba(0, 0, 0, 0.2)' }}
        >
          <div className="mb-6">
            <h3 className="text-lg font-bold text-[#F5E6D3]">Sales by Category</h3>
            <p className="text-sm text-[#8A7F6F]">Product category breakdown</p>
          </div>
          
          <ResponsivePieChart
            data={categoryData}
            dataKey="value"
            nameKey="name"
            height={300}
            showLabels={true}
            tooltipFormatter={(value) => `$${value.toLocaleString()}`}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>
      </motion.div>

      {/* Bottom Row */}
      <motion.div 
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        variants={cardVariants}
      >
        {/* Traffic Sources */}
        <motion.div
          className="bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ boxShadow: '0 8px 30px rgba(0, 0, 0, 0.2)' }}
        >
          <div className="mb-6">
            <h3 className="text-lg font-bold text-[#F5E6D3]">Traffic Sources</h3>
            <p className="text-sm text-[#8A7F6F]">Where visitors come from</p>
          </div>
          
          <ResponsiveBarChart
            data={trafficData}
            bars={[{ dataKey: 'value', name: 'Visitors', color: '#F4C430' }]}
            xAxisKey="source"
            height={250}
            showGrid={false}
            showLegend={false}
            tooltipFormatter={(value) => `${value}%`}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          className="lg:col-span-2 bg-[#243947] rounded-xl border border-[#F4C430]/10 p-6"
          whileHover={{ boxShadow: '0 8px 30px rgba(0, 0, 0, 0.2)' }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-[#F5E6D3]">Recent Activity</h3>
              <p className="text-sm text-[#8A7F6F]">Latest transactions and signups</p>
            </div>
            <button className="text-sm text-[#FF8C42] hover:text-[#F4C430] transition-colors font-medium">
              View All →
            </button>
          </div>

          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={activity.id}
                className="flex items-center gap-4 p-3 rounded-lg hover:bg-[#1A2F38] transition-colors cursor-pointer"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ x: 4 }}
              >
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${
                  activity.type === 'sale' 
                    ? 'from-[#FF8C42] to-[#F4C430]' 
                    : 'from-[#2C5F6F] to-[#4A8A9F]'
                } flex items-center justify-center shadow-lg`}>
                  {activity.type === 'sale' ? (
                    <DollarSign size={16} className="text-[#1A2F38]" />
                  ) : (
                    <Users size={16} className="text-[#1A2F38]" />
                  )}
                </div>
                
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#F5E6D3]">{activity.user}</p>
                  <p className="text-xs text-[#8A7F6F]">{activity.time}</p>
                </div>
                
                <div className="text-right">
                  <p className="text-sm font-semibold text-[#F5E6D3]">{activity.amount}</p>
                  <div className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                    activity.status === 'completed' 
                      ? 'bg-[#7BC67E]/15 text-[#7BC67E]'
                      : activity.status === 'pending'
                      ? 'bg-[#FFB347]/15 text-[#FFB347]'
                      : 'bg-[#4A8A9F]/15 text-[#4A8A9F]'
                  }`}>
                    {activity.status}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
