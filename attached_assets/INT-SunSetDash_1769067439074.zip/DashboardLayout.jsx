/**
 * DashboardLayout.jsx - Main Layout with Sidebar & Header
 * 
 * Animated layout with sunset branding
 * Smooth transitions and micro-interactions
 */

import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  BarChart3,
  Users,
  DollarSign,
  Settings,
  Menu,
  X,
  Bell,
  Search,
  User as UserIcon,
  ChevronDown,
  LogOut,
  Sun,
  Moon
} from 'lucide-react';

export function DashboardLayout({ children, sidebarOpen, onSidebarToggle }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  // Close dropdowns on route change
  useEffect(() => {
    setSearchOpen(false);
    setNotificationsOpen(false);
    setProfileOpen(false);
  }, [location.pathname]);

  const navigation = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard size={20} />,
      path: '/dashboard',
      badge: null
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: <BarChart3 size={20} />,
      path: '/analytics',
      badge: null
    },
    {
      id: 'users',
      label: 'Users',
      icon: <Users size={20} />,
      path: '/users',
      badge: '2.4K'
    },
    {
      id: 'revenue',
      label: 'Revenue',
      icon: <DollarSign size={20} />,
      path: '/revenue',
      badge: null
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings size={20} />,
      path: '/settings',
      badge: null
    }
  ];

  const notifications = [
    { id: 1, text: 'New user registered', time: '2m ago', unread: true },
    { id: 2, text: 'Payment received: $1,234', time: '15m ago', unread: true },
    { id: 3, text: 'Report generated', time: '1h ago', unread: false }
  ];

  return (
    <div className="min-h-screen bg-[#0F1A1F]">
      {/* Mobile Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onSidebarToggle}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        className={`
          fixed top-0 left-0 z-50 h-screen
          bg-gradient-to-b from-[#1A2F38] to-[#0F1A1F]
          border-r border-[#F4C430]/10
          overflow-y-auto
          transition-transform duration-300 ease-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          lg:translate-x-0
        `}
        style={{ width: sidebarOpen ? '280px' : '80px' }}
      >
        {/* Logo */}
        <div className="h-20 flex items-center px-6 border-b border-[#F4C430]/10">
          <motion.div
            className="flex items-center gap-3"
            initial={false}
            animate={{ opacity: sidebarOpen ? 1 : 0 }}
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center shadow-lg shadow-[#FF8C42]/20">
              <Sun className="w-6 h-6 text-[#1A2F38]" />
            </div>
            {sidebarOpen && (
              <motion.span
                className="text-xl font-bold text-[#F5E6D3]"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
              >
                BASE44
              </motion.span>
            )}
          </motion.div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {navigation.map((item, index) => {
            const isActive = location.pathname === item.path || 
                           location.pathname.startsWith(item.path + '/');
            
            return (
              <motion.button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg
                  transition-all duration-300
                  ${isActive 
                    ? 'bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] shadow-lg shadow-[#FF8C42]/20' 
                    : 'text-[#C4B5A0] hover:bg-[#243947] hover:text-[#F5E6D3]'
                  }
                `}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <span className="flex-shrink-0">{item.icon}</span>
                {sidebarOpen && (
                  <>
                    <span className="flex-1 text-left font-medium">{item.label}</span>
                    {item.badge && (
                      <span className="px-2 py-0.5 bg-[#1A2F38]/30 text-xs rounded-full font-semibold">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </motion.button>
            );
          })}
        </nav>

        {/* Footer */}
        {sidebarOpen && (
          <motion.div
            className="absolute bottom-0 left-0 right-0 p-4 border-t border-[#F4C430]/10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="text-xs text-[#8A7F6F] text-center">
              v1.0.0 • Sunset Edition
            </div>
          </motion.div>
        )}
      </motion.aside>

      {/* Main Content */}
      <div
        className="transition-all duration-300"
        style={{ marginLeft: sidebarOpen ? '280px' : '80px' }}
      >
        {/* Header */}
        <header className="h-20 bg-[#1A2F38]/80 backdrop-blur-xl border-b border-[#F4C430]/10 sticky top-0 z-30">
          <div className="h-full px-6 flex items-center justify-between gap-4">
            {/* Left */}
            <div className="flex items-center gap-4">
              <motion.button
                onClick={onSidebarToggle}
                className="p-2 rounded-lg hover:bg-[#243947] text-[#C4B5A0] transition-colors lg:hidden"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
              </motion.button>

              {/* Search */}
              <div className="relative">
                <motion.button
                  onClick={() => setSearchOpen(!searchOpen)}
                  className="p-2 rounded-lg hover:bg-[#243947] text-[#C4B5A0] transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Search size={20} />
                </motion.button>

                <AnimatePresence>
                  {searchOpen && (
                    <motion.div
                      className="absolute top-full left-0 mt-2 w-80 bg-[#243947] rounded-lg border border-[#F4C430]/20 shadow-xl p-3"
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                    >
                      <input
                        type="text"
                        placeholder="Search..."
                        className="w-full px-4 py-2 bg-[#1A2F38] border border-[#F4C430]/10 rounded-lg text-[#F5E6D3] placeholder-[#8A7F6F] focus:outline-none focus:border-[#FF8C42] transition-colors"
                        autoFocus
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Right */}
            <div className="flex items-center gap-3">
              {/* Notifications */}
              <div className="relative">
                <motion.button
                  onClick={() => setNotificationsOpen(!notificationsOpen)}
                  className="relative p-2 rounded-lg hover:bg-[#243947] text-[#C4B5A0] transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Bell size={20} />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-[#FF6B6B] rounded-full animate-pulse" />
                </motion.button>

                <AnimatePresence>
                  {notificationsOpen && (
                    <motion.div
                      className="absolute top-full right-0 mt-2 w-80 bg-[#243947] rounded-lg border border-[#F4C430]/20 shadow-xl overflow-hidden"
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="p-4 border-b border-[#F4C430]/10">
                        <h3 className="font-semibold text-[#F5E6D3]">Notifications</h3>
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {notifications.map((notif) => (
                          <motion.div
                            key={notif.id}
                            className="p-4 border-b border-[#F4C430]/10 hover:bg-[#1A2F38] transition-colors cursor-pointer"
                            whileHover={{ x: 4 }}
                          >
                            <div className="flex items-start gap-3">
                              {notif.unread && (
                                <span className="w-2 h-2 mt-1.5 bg-[#FF8C42] rounded-full" />
                              )}
                              <div className="flex-1">
                                <p className="text-sm text-[#F5E6D3]">{notif.text}</p>
                                <p className="text-xs text-[#8A7F6F] mt-1">{notif.time}</p>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Profile */}
              <div className="relative">
                <motion.button
                  onClick={() => setProfileOpen(!profileOpen)}
                  className="flex items-center gap-2 p-2 pl-3 rounded-lg hover:bg-[#243947] transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center">
                    <UserIcon size={16} className="text-[#1A2F38]" />
                  </div>
                  <ChevronDown size={16} className="text-[#C4B5A0]" />
                </motion.button>

                <AnimatePresence>
                  {profileOpen && (
                    <motion.div
                      className="absolute top-full right-0 mt-2 w-56 bg-[#243947] rounded-lg border border-[#F4C430]/20 shadow-xl overflow-hidden"
                      initial={{ opacity: 0, y: -10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div className="p-4 border-b border-[#F4C430]/10">
                        <p className="font-semibold text-[#F5E6D3]">John Doe</p>
                        <p className="text-sm text-[#8A7F6F]">john@base44.com</p>
                      </div>
                      <div className="p-2">
                        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#1A2F38] text-[#C4B5A0] transition-colors text-left">
                          <UserIcon size={16} />
                          <span className="text-sm">Profile</span>
                        </button>
                        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#1A2F38] text-[#C4B5A0] transition-colors text-left">
                          <Settings size={16} />
                          <span className="text-sm">Settings</span>
                        </button>
                        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#1A2F38] text-[#FF6B6B] transition-colors text-left">
                          <LogOut size={16} />
                          <span className="text-sm">Logout</span>
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="min-h-[calc(100vh-5rem)]">
          {children}
        </main>
      </div>
    </div>
  );
}
