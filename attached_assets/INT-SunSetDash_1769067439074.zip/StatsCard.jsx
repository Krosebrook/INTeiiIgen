/**
 * StatsCard Component - Sunset Brand
 * 
 * Displays a key metric with optional trend indicator
 * Warm, organic design with sunset colors
 * 
 * @example
 * <StatsCard
 *   title="Total Revenue"
 *   value="$45.2K"
 *   change={12.5}
 *   changeLabel="vs last month"
 *   icon={<DollarSign />}
 * />
 */

import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatPercent } from '../lib/utils/formatters';

export function StatsCard({
  title,
  value,
  change = null,
  changeLabel = '',
  icon = null,
  trend = null,
  subtitle = null,
  className = '',
  loading = false,
  onClick = null,
  'aria-label': ariaLabel
}) {
  // Determine trend direction
  const trendDirection = trend || (change > 0 ? 'up' : change < 0 ? 'down' : 'neutral');
  const isPositive = trendDirection === 'up';
  const isNegative = trendDirection === 'down';
  const isNeutral = trendDirection === 'neutral';
  
  // Sunset palette trend colors
  const trendColor = isPositive
    ? 'text-[#7BC67E]' // Soft green
    : isNegative
    ? 'text-[#FF6B6B]' // Coral red
    : 'text-[#C4B5A0]'; // Muted cream
  
  const trendBg = isPositive
    ? 'bg-[#7BC67E]/15'
    : isNegative
    ? 'bg-[#FF6B6B]/15'
    : 'bg-[#2C4753]/50';
  
  // Icon to display
  const TrendIcon = isPositive ? TrendingUp : isNegative ? TrendingDown : Minus;
  
  // Base card classes with sunset styling
  const cardClasses = cn(
    'relative overflow-hidden rounded-lg',
    'bg-[#243947] border border-[#F4C430]/10',
    'hover:border-[#F4C430]/30 hover:shadow-lg',
    'transition-all duration-300',
    'p-6',
    onClick && 'cursor-pointer hover:-translate-y-1 active:scale-[0.98]',
    loading && 'animate-pulse',
    className
  );
  
  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: 'spring',
        stiffness: 100,
        damping: 15
      }
    }
  };
  
  const shimmer = {
    hidden: { x: '-100%', opacity: 0 },
    visible: {
      x: '100%',
      opacity: [0, 0.3, 0],
      transition: {
        duration: 2,
        ease: 'easeInOut',
        repeat: Infinity,
        repeatDelay: 1
      }
    }
  };
  
  return (
    <motion.div
      className={cardClasses}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      onClick={onClick}
      role={onClick ? 'button' : 'article'}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
      aria-label={ariaLabel || title}
    >
      {/* Sunset gradient accent line */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#FF8C42] via-[#F4C430] to-transparent rounded-t-lg" />
      
      {/* Loading shimmer effect */}
      {loading && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#FF8C42]/20 to-transparent"
          variants={shimmer}
          initial="hidden"
          animate="visible"
        />
      )}
      
      {/* Header with icon and title */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-sm font-medium uppercase tracking-wide text-[#C4B5A0] mb-1">
            {title}
          </h3>
          {subtitle && (
            <p className="text-xs text-[#8A7F6F]">
              {subtitle}
            </p>
          )}
        </div>
        
        {icon && (
          <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-gradient-to-br from-[#FF8C42] to-[#F4C430] rounded-lg shadow-lg">
            <div className="text-[#1A2F38]">
              {icon}
            </div>
          </div>
        )}
      </div>
      
      {/* Value display */}
      <div className="mb-3">
        <div className="text-3xl font-bold text-[#F5E6D3] tracking-tight">
          {loading ? '—' : value}
        </div>
      </div>
      
      {/* Trend indicator */}
      {change !== null && (
        <div className="flex items-center gap-2">
          <div className={cn(
            'flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium',
            trendBg,
            trendColor
          )}>
            <TrendIcon className="w-3 h-3" />
            <span className="font-semibold">
              {formatPercent(Math.abs(change), 1)}
            </span>
          </div>
          
          {changeLabel && (
            <span className="text-xs text-[#8A7F6F]">
              {changeLabel}
            </span>
          )}
        </div>
      )}
      
      {/* Subtle corner glow */}
      <div 
        className="absolute bottom-0 right-0 w-24 h-24 opacity-10 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at bottom right, #FF8C42, transparent 70%)'
        }}
      />
    </motion.div>
  );
}

// Loading skeleton variant
export function StatsCardSkeleton({ className = '' }) {
  return (
    <div className={cn(
      'relative overflow-hidden rounded-lg',
      'bg-[#243947] border border-[#F4C430]/10',
      'p-6',
      'animate-pulse',
      className
    )}>
      <div className="absolute top-0 left-0 w-full h-1 bg-[#2C4753]" />
      
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="h-3 w-24 bg-[#2C4753] rounded mb-2" />
        </div>
        <div className="w-12 h-12 bg-[#2C4753] rounded-lg" />
      </div>
      
      <div className="mb-3">
        <div className="h-8 w-32 bg-[#2C4753] rounded" />
      </div>
      
      <div className="flex items-center gap-2">
        <div className="h-6 w-16 bg-[#2C4753] rounded-full" />
        <div className="h-3 w-20 bg-[#2C4753] rounded" />
      </div>
    </div>
  );
}

export default StatsCard;
