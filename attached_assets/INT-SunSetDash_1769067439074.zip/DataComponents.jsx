/**
 * Data Display Components
 * 
 * Components for displaying tabular and list data with loading, empty, and error states
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Search,
  AlertCircle,
  Inbox,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ========================================
// DataTable - Sortable, searchable table
// ========================================

export function DataTable({
  data,
  columns,
  sortable = true,
  searchable = true,
  onRowClick = null,
  emptyMessage = 'No data available',
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  const [sortColumn, setSortColumn] = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Handle column sort
  const handleSort = (columnKey) => {
    if (!sortable) return;
    
    if (sortColumn === columnKey) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(columnKey);
      setSortDirection('asc');
    }
  };
  
  // Filter data by search term
  const filteredData = searchTerm
    ? data.filter(row =>
        columns.some(col => {
          const value = row[col.key];
          return value && value.toString().toLowerCase().includes(searchTerm.toLowerCase());
        })
      )
    : data;
  
  // Sort data
  const sortedData = sortColumn
    ? [...filteredData].sort((a, b) => {
        const aValue = a[sortColumn];
        const bValue = b[sortColumn];
        
        const comparison = aValue > bValue ? 1 : aValue < bValue ? -1 : 0;
        return sortDirection === 'asc' ? comparison : -comparison;
      })
    : filteredData;
  
  if (loading) {
    return <LoadingState message="Loading table data..." />;
  }
  
  return (
    <div className={cn('bg-[#1a1a1a] border-2 border-neutral-800', className)}>
      {/* Search bar */}
      {searchable && (
        <div className="p-4 border-b-2 border-neutral-800">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-neutral-900 border border-neutral-700 text-white font-mono text-sm focus:outline-none focus:border-[#00bfff] transition-colors"
              aria-label="Search table"
            />
          </div>
        </div>
      )}
      
      {/* Table */}
      <div className="overflow-x-auto">
        <table
          className="w-full"
          role="table"
          aria-label={ariaLabel || 'Data table'}
        >
          <thead className="bg-neutral-900 border-b-2 border-neutral-800">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className={cn(
                    'px-4 py-3 text-left text-xs font-mono uppercase tracking-wider text-neutral-400',
                    sortable && 'cursor-pointer select-none hover:text-[#00bfff] transition-colors',
                    column.align === 'right' && 'text-right',
                    column.align === 'center' && 'text-center'
                  )}
                  onClick={() => sortable && handleSort(column.key)}
                  role="columnheader"
                >
                  <div className="flex items-center gap-2">
                    <span>{column.label}</span>
                    {sortable && (
                      <span className="text-neutral-600">
                        {sortColumn === column.key ? (
                          sortDirection === 'asc' ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )
                        ) : (
                          <ChevronsUpDown className="w-4 h-4" />
                        )}
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          
          <tbody>
            <AnimatePresence mode="wait">
              {sortedData.length === 0 ? (
                <tr>
                  <td colSpan={columns.length}>
                    <EmptyState
                      icon={<Inbox />}
                      message={emptyMessage}
                    />
                  </td>
                </tr>
              ) : (
                sortedData.map((row, rowIndex) => (
                  <motion.tr
                    key={row.id || rowIndex}
                    className={cn(
                      'border-b border-neutral-800',
                      onRowClick && 'cursor-pointer hover:bg-neutral-900 transition-colors'
                    )}
                    onClick={() => onRowClick?.(row)}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    {columns.map((column) => (
                      <td
                        key={column.key}
                        className={cn(
                          'px-4 py-3 text-sm font-mono text-neutral-300',
                          column.align === 'right' && 'text-right',
                          column.align === 'center' && 'text-center'
                        )}
                      >
                        {column.render ? column.render(row[column.key], row) : row[column.key]}
                      </td>
                    ))}
                  </motion.tr>
                ))
              )}
            </AnimatePresence>
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ========================================
// DataList - Vertical list of items
// ========================================

export function DataList({
  data,
  renderItem,
  keyExtractor = (item, index) => item.id || index,
  emptyMessage = 'No items to display',
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading) {
    return <LoadingState message="Loading list..." />;
  }
  
  if (data.length === 0) {
    return (
      <EmptyState
        icon={<Inbox />}
        message={emptyMessage}
      />
    );
  }
  
  return (
    <div
      className={cn('bg-[#1a1a1a] border-2 border-neutral-800', className)}
      role="list"
      aria-label={ariaLabel || 'Data list'}
    >
      <AnimatePresence mode="popLayout">
        {data.map((item, index) => (
          <motion.div
            key={keyExtractor(item, index)}
            className="border-b border-neutral-800 last:border-b-0"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
            role="listitem"
          >
            {renderItem(item, index)}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// Simple list item component
export function DataListItem({
  title,
  subtitle = null,
  meta = null,
  avatar = null,
  actions = null,
  onClick = null,
  className = ''
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-4 p-4',
        onClick && 'cursor-pointer hover:bg-neutral-900 transition-colors',
        className
      )}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
    >
      {/* Avatar */}
      {avatar && (
        <div className="flex-shrink-0">
          {avatar}
        </div>
      )}
      
      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="text-sm font-mono font-medium text-white truncate">
          {title}
        </div>
        {subtitle && (
          <div className="text-xs text-neutral-500 font-mono truncate mt-0.5">
            {subtitle}
          </div>
        )}
      </div>
      
      {/* Meta */}
      {meta && (
        <div className="flex-shrink-0 text-xs text-neutral-500 font-mono">
          {meta}
        </div>
      )}
      
      {/* Actions */}
      {actions && (
        <div className="flex-shrink-0 flex items-center gap-2">
          {actions}
        </div>
      )}
    </div>
  );
}

// ========================================
// EmptyState - No data placeholder
// ========================================

export function EmptyState({
  icon = null,
  message = 'No data available',
  action = null,
  className = ''
}) {
  return (
    <div className={cn(
      'flex flex-col items-center justify-center p-12 text-center',
      'bg-[#1a1a1a]',
      className
    )}>
      {icon && (
        <div className="w-16 h-16 flex items-center justify-center mb-4 text-neutral-600">
          {React.cloneElement(icon, { className: 'w-full h-full' })}
        </div>
      )}
      
      <p className="text-sm font-mono text-neutral-500 mb-4">
        {message}
      </p>
      
      {action && (
        <div>{action}</div>
      )}
    </div>
  );
}

// ========================================
// LoadingState - Data loading indicator
// ========================================

export function LoadingState({
  message = 'Loading...',
  className = ''
}) {
  return (
    <div className={cn(
      'flex flex-col items-center justify-center p-12',
      'bg-[#1a1a1a] border-2 border-neutral-800',
      className
    )}>
      <motion.div
        className="w-8 h-8 border-2 border-[#00bfff] border-t-transparent"
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
      />
      
      <p className="mt-4 text-sm font-mono text-neutral-500">
        {message}
      </p>
    </div>
  );
}

// ========================================
// ErrorState - Error display with retry
// ========================================

export function ErrorState({
  error,
  message = 'Something went wrong',
  onRetry = null,
  className = ''
}) {
  return (
    <div className={cn(
      'flex flex-col items-center justify-center p-12 text-center',
      'bg-[#1a1a1a] border-2 border-red-500/30',
      className
    )}>
      <div className="w-16 h-16 flex items-center justify-center mb-4 text-red-500">
        <AlertCircle className="w-full h-full" />
      </div>
      
      <h3 className="text-sm font-mono font-bold text-red-500 mb-2">
        Error
      </h3>
      
      <p className="text-sm font-mono text-neutral-400 mb-1">
        {message}
      </p>
      
      {error && (
        <p className="text-xs font-mono text-neutral-600 mb-4">
          {error.message || String(error)}
        </p>
      )}
      
      {onRetry && (
        <button
          onClick={onRetry}
          className="flex items-center gap-2 px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-mono text-sm transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Try Again</span>
        </button>
      )}
    </div>
  );
}

export default {
  DataTable,
  DataList,
  DataListItem,
  EmptyState,
  LoadingState,
  ErrorState
};
