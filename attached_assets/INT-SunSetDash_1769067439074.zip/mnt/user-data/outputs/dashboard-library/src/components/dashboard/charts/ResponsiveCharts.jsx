/**
 * Responsive Chart Components
 * 
 * Recharts-based chart wrappers with geometric brutalist styling
 * Fully responsive and accessible
 */

import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { cn } from '@/lib/utils';

// Brutalist color palette
const COLORS = {
  primary: '#00bfff',
  secondary: '#39ff14',
  tertiary: '#ff6b35',
  quaternary: '#ff4444',
  quinary: '#9b59b6'
};

const CHART_COLORS = [
  COLORS.primary,
  COLORS.secondary,
  COLORS.tertiary,
  COLORS.quaternary,
  COLORS.quinary
];

// Custom tooltip component
function CustomTooltip({ active, payload, label, formatter }) {
  if (!active || !payload || !payload.length) return null;
  
  return (
    <div className="bg-[#1a1a1a] border-2 border-neutral-700 p-3 font-mono">
      <div className="text-xs text-neutral-400 mb-2 uppercase tracking-wider">
        {label}
      </div>
      {payload.map((entry, index) => (
        <div key={index} className="flex items-center gap-2 text-sm">
          <div
            className="w-3 h-3 border border-neutral-600"
            style={{ backgroundColor: entry.color }}
          />
          <span className="text-neutral-300">{entry.name}:</span>
          <span className="text-white font-bold">
            {formatter ? formatter(entry.value) : entry.value}
          </span>
        </div>
      ))}
    </div>
  );
}

// ========================================
// ResponsiveLineChart
// ========================================

export function ResponsiveLineChart({
  data,
  lines,
  xAxisKey = 'date',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-neutral-600 font-mono text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6', className)}
      role="img"
      aria-label={ariaLabel || 'Line chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="#2a2a2a"
              vertical={false}
            />
          )}
          
          <XAxis
            dataKey={xAxisKey}
            stroke="#666"
            style={{ fontFamily: 'monospace', fontSize: '11px' }}
            tick={{ fill: '#999' }}
          />
          
          <YAxis
            stroke="#666"
            style={{ fontFamily: 'monospace', fontSize: '11px' }}
            tick={{ fill: '#999' }}
          />
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ stroke: '#00bfff', strokeWidth: 2 }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'monospace',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
          
          {lines.map((line, index) => (
            <Line
              key={line.dataKey}
              type="monotone"
              dataKey={line.dataKey}
              name={line.name || line.dataKey}
              stroke={line.color || CHART_COLORS[index % CHART_COLORS.length]}
              strokeWidth={2}
              dot={{ fill: line.color || CHART_COLORS[index % CHART_COLORS.length], r: 4 }}
              activeDot={{ r: 6 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsiveBarChart
// ========================================

export function ResponsiveBarChart({
  data,
  bars,
  xAxisKey = 'category',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  stacked = false,
  horizontal = false,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-neutral-600 font-mono text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  const ChartComponent = horizontal ? BarChart : BarChart;
  const layout = horizontal ? 'horizontal' : 'vertical';
  
  return (
    <div
      className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6', className)}
      role="img"
      aria-label={ariaLabel || 'Bar chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <ChartComponent data={data} layout={layout}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="#2a2a2a"
              horizontal={!horizontal}
              vertical={horizontal}
            />
          )}
          
          {horizontal ? (
            <>
              <XAxis
                type="number"
                stroke="#666"
                style={{ fontFamily: 'monospace', fontSize: '11px' }}
                tick={{ fill: '#999' }}
              />
              <YAxis
                dataKey={xAxisKey}
                type="category"
                stroke="#666"
                style={{ fontFamily: 'monospace', fontSize: '11px' }}
                tick={{ fill: '#999' }}
              />
            </>
          ) : (
            <>
              <XAxis
                dataKey={xAxisKey}
                stroke="#666"
                style={{ fontFamily: 'monospace', fontSize: '11px' }}
                tick={{ fill: '#999' }}
              />
              <YAxis
                stroke="#666"
                style={{ fontFamily: 'monospace', fontSize: '11px' }}
                tick={{ fill: '#999' }}
              />
            </>
          )}
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ fill: 'rgba(0, 191, 255, 0.1)' }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'monospace',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
          
          {bars.map((bar, index) => (
            <Bar
              key={bar.dataKey}
              dataKey={bar.dataKey}
              name={bar.name || bar.dataKey}
              fill={bar.color || CHART_COLORS[index % CHART_COLORS.length]}
              stackId={stacked ? 'stack' : undefined}
            />
          ))}
        </ChartComponent>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsiveAreaChart
// ========================================

export function ResponsiveAreaChart({
  data,
  areas,
  xAxisKey = 'date',
  height = 300,
  showGrid = true,
  showLegend = true,
  showTooltip = true,
  tooltipFormatter = null,
  stacked = false,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-neutral-600 font-mono text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6', className)}
      role="img"
      aria-label={ariaLabel || 'Area chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={data}>
          {showGrid && (
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="#2a2a2a"
              vertical={false}
            />
          )}
          
          <XAxis
            dataKey={xAxisKey}
            stroke="#666"
            style={{ fontFamily: 'monospace', fontSize: '11px' }}
            tick={{ fill: '#999' }}
          />
          
          <YAxis
            stroke="#666"
            style={{ fontFamily: 'monospace', fontSize: '11px' }}
            tick={{ fill: '#999' }}
          />
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
              cursor={{ stroke: '#00bfff', strokeWidth: 2 }}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'monospace',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
          
          {areas.map((area, index) => {
            const color = area.color || CHART_COLORS[index % CHART_COLORS.length];
            return (
              <Area
                key={area.dataKey}
                type="monotone"
                dataKey={area.dataKey}
                name={area.name || area.dataKey}
                stroke={color}
                fill={color}
                fillOpacity={0.2}
                strokeWidth={2}
                stackId={stacked ? 'stack' : undefined}
              />
            );
          })}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// ResponsivePieChart
// ========================================

export function ResponsivePieChart({
  data,
  dataKey = 'value',
  nameKey = 'name',
  height = 300,
  showLegend = true,
  showTooltip = true,
  showLabels = true,
  tooltipFormatter = null,
  className = '',
  loading = false,
  'aria-label': ariaLabel
}) {
  if (loading || !data || data.length === 0) {
    return (
      <div className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6 animate-pulse', className)}>
        <div className="h-[300px] flex items-center justify-center">
          <div className="text-neutral-600 font-mono text-sm">Loading chart data...</div>
        </div>
      </div>
    );
  }
  
  const renderLabel = (entry) => {
    if (!showLabels) return null;
    return entry[nameKey];
  };
  
  return (
    <div
      className={cn('bg-[#1a1a1a] border-2 border-neutral-800 p-6', className)}
      role="img"
      aria-label={ariaLabel || 'Pie chart'}
    >
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie
            data={data}
            dataKey={dataKey}
            nameKey={nameKey}
            cx="50%"
            cy="50%"
            outerRadius={80}
            label={renderLabel}
            labelLine={showLabels}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={CHART_COLORS[index % CHART_COLORS.length]}
                stroke="#1a1a1a"
                strokeWidth={2}
              />
            ))}
          </Pie>
          
          {showTooltip && (
            <Tooltip
              content={<CustomTooltip formatter={tooltipFormatter} />}
            />
          )}
          
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontFamily: 'monospace',
                fontSize: '12px',
                paddingTop: '20px'
              }}
            />
          )}
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

// ========================================
// MiniSparkline - Compact trend line
// ========================================

export function MiniSparkline({
  data,
  dataKey = 'value',
  color = COLORS.primary,
  height = 40,
  className = '',
  'aria-label': ariaLabel
}) {
  if (!data || data.length === 0) return null;
  
  return (
    <div
      className={cn('inline-block', className)}
      role="img"
      aria-label={ariaLabel || 'Trend sparkline'}
    >
      <ResponsiveContainer width={100} height={height}>
        <LineChart data={data}>
          <Line
            type="monotone"
            dataKey={dataKey}
            stroke={color}
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsiveAreaChart,
  ResponsivePieChart,
  MiniSparkline
};
