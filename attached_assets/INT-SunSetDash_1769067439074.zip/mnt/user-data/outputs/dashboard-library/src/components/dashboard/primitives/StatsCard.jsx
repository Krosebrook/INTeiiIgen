/**
 * StatsCard Component
 * 
 * Displays a key metric with optional trend indicator and subtitle
 * Geometric brutalist design with bold borders and sharp angles
 * 
 * @example
 * <StatsCard
 *   title="Total Revenue"
 *   value="$45.2K"
 *   change={12.5}
 *   changeLabel="vs last month"
 *   icon={<DollarSign />}
 * />
 */

import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatPercent } from '../lib/utils/formatters';

export function StatsCard({
  title,
  value,
  change = null,
  changeLabel = '',
  icon = null,
  trend = null,
  subtitle = null,
  className = '',
  loading = false,
  onClick = null,
  'aria-label': ariaLabel
}) {
  // Determine trend direction
  const trendDirection = trend || (change > 0 ? 'up' : change < 0 ? 'down' : 'neutral');
  const isPositive = trendDirection === 'up';
  const isNegative = trendDirection === 'down';
  const isNeutral = trendDirection === 'neutral';
  
  // Trend colors (brutalist palette)
  const trendColor = isPositive
    ? 'text-[#39ff14]' // Neon green
    : isNegative
    ? 'text-[#ff6b35]' // Signal orange
    : 'text-neutral-400';
  
  const trendBg = isPositive
    ? 'bg-[#39ff14]/10'
    : isNegative
    ? 'bg-[#ff6b35]/10'
    : 'bg-neutral-800/50';
  
  // Icon to display
  const TrendIcon = isPositive ? TrendingUp : isNegative ? TrendingDown : Minus;
  
  // Base card classes
  const cardClasses = cn(
    'relative overflow-hidden',
    'bg-[#1a1a1a] border-2 border-neutral-800',
    'hover:border-[#00bfff] transition-colors duration-150',
    'p-6',
    onClick && 'cursor-pointer active:scale-[0.98]',
    loading && 'animate-pulse',
    className
  );
  
  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        type: 'tween',
        duration: 0.2
      }
    }
  };
  
  const shimmer = {
    hidden: { x: '-100%' },
    visible: {
      x: '100%',
      transition: {
        duration: 1.5,
        ease: 'linear',
        repeat: Infinity,
        repeatDelay: 1
      }
    }
  };
  
  return (
    <motion.div
      className={cardClasses}
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      onClick={onClick}
      role={onClick ? 'button' : 'article'}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
      aria-label={ariaLabel || title}
    >
      {/* Geometric accent line */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#00bfff] via-[#39ff14] to-transparent" />
      
      {/* Loading shimmer effect */}
      {loading && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-neutral-700/20 to-transparent"
          variants={shimmer}
          initial="hidden"
          animate="visible"
        />
      )}
      
      {/* Header with icon and title */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-sm font-mono uppercase tracking-wider text-neutral-400 mb-1">
            {title}
          </h3>
          {subtitle && (
            <p className="text-xs text-neutral-500 font-mono">
              {subtitle}
            </p>
          )}
        </div>
        
        {icon && (
          <div className="flex-shrink-0 w-10 h-10 flex items-center justify-center bg-neutral-800 border border-neutral-700">
            <div className="text-[#00bfff]">
              {icon}
            </div>
          </div>
        )}
      </div>
      
      {/* Value display */}
      <div className="mb-3">
        <div className="text-3xl font-mono font-bold text-white tracking-tight">
          {loading ? '—' : value}
        </div>
      </div>
      
      {/* Trend indicator */}
      {change !== null && (
        <div className="flex items-center gap-2">
          <div className={cn(
            'flex items-center gap-1 px-2 py-1 font-mono text-xs',
            trendBg,
            trendColor
          )}>
            <TrendIcon className="w-3 h-3" />
            <span className="font-bold">
              {formatPercent(Math.abs(change), 1)}
            </span>
          </div>
          
          {changeLabel && (
            <span className="text-xs text-neutral-500 font-mono">
              {changeLabel}
            </span>
          )}
        </div>
      )}
      
      {/* Geometric corner accent */}
      <div className="absolute bottom-0 right-0 w-8 h-8 border-l-2 border-t-2 border-neutral-800" />
    </motion.div>
  );
}

// Loading skeleton variant
export function StatsCardSkeleton({ className = '' }) {
  return (
    <div className={cn(
      'relative overflow-hidden',
      'bg-[#1a1a1a] border-2 border-neutral-800',
      'p-6',
      'animate-pulse',
      className
    )}>
      <div className="absolute top-0 left-0 w-full h-1 bg-neutral-800" />
      
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="h-3 w-24 bg-neutral-800 mb-2" />
        </div>
        <div className="w-10 h-10 bg-neutral-800" />
      </div>
      
      <div className="mb-3">
        <div className="h-8 w-32 bg-neutral-800" />
      </div>
      
      <div className="flex items-center gap-2">
        <div className="h-6 w-16 bg-neutral-800" />
        <div className="h-3 w-20 bg-neutral-800" />
      </div>
      
      <div className="absolute bottom-0 right-0 w-8 h-8 border-l-2 border-t-2 border-neutral-800" />
    </div>
  );
}

export default StatsCard;
