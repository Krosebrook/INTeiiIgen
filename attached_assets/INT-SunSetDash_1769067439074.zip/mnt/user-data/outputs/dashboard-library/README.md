# Dashboard Component Library

**Production-grade dashboard components for React + Tailwind CSS + shadcn/ui**

A comprehensive library of 20+ composable dashboard components with geometric brutalist design. Built for Base44 app using React 18, Tailwind CSS, Recharts, and Framer Motion.

## 🎨 Design Philosophy

**Geometric Brutalist Aesthetic**
- Sharp edges, bold borders, unapologetic use of space
- IBM Plex Mono (monospace) + Inter Variable (body)
- Deep charcoal (#1a1a1a), electric blue (#00bfff), neon green (#39ff14), signal orange (#ff6b35)
- Avoids generic "AI slop" patterns

## 📦 Installation

### Prerequisites

The dashboard library requires these dependencies (already in your Base44 app):

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "recharts": "^2.15.1",
  "framer-motion": "^12.4.7",
  "lucide-react": "^0.475.0",
  "tailwindcss": "^3.4.17",
  "class-variance-authority": "^0.7.1",
  "clsx": "^2.1.1",
  "tailwind-merge": "^3.0.2"
}
```

### Setup

1. **Copy the library to your project:**

```bash
# Copy dashboard library to your src/components directory
cp -r dashboard-library/src/components/dashboard /path/to/your/project/src/components/
```

2. **Install missing dependencies (if any):**

```bash
npm install recharts framer-motion
```

3. **Import components:**

```jsx
import { StatsCard, ResponsiveLineChart, DashboardGrid } from '@/components/dashboard';
```

## 🚀 Quick Start

### Basic Dashboard

```jsx
import React from 'react';
import {
  DashboardShell,
  DashboardHeader,
  DashboardContent,
  DashboardGrid,
  StatsCard,
  ResponsiveLineChart
} from '@/components/dashboard';
import { DollarSign, Users, TrendingUp } from 'lucide-react';

export function SimpleDashboard() {
  const data = [
    { date: 'Jan', revenue: 45000 },
    { date: 'Feb', revenue: 52000 },
    { date: 'Mar', revenue: 48000 },
    { date: 'Apr', revenue: 61000 },
    { date: 'May', revenue: 55000 },
    { date: 'Jun', revenue: 67000 }
  ];
  
  return (
    <DashboardShell
      header={
        <DashboardHeader
          title="Dashboard"
          subtitle="Welcome back!"
        />
      }
    >
      <DashboardContent>
        {/* Stats Cards */}
        <DashboardGrid columns={3} gap="md">
          <StatsCard
            title="Total Revenue"
            value="$328K"
            change={23.5}
            changeLabel="vs last quarter"
            icon={<DollarSign />}
          />
          
          <StatsCard
            title="Active Users"
            value="1,842"
            change={12.3}
            changeLabel="vs last month"
            icon={<Users />}
          />
          
          <StatsCard
            title="Conversion Rate"
            value="3.47%"
            change={-2.1}
            changeLabel="vs last month"
            icon={<TrendingUp />}
          />
        </DashboardGrid>
        
        {/* Revenue Chart */}
        <div className="mt-8">
          <ResponsiveLineChart
            data={data}
            lines={[
              { dataKey: 'revenue', name: 'Revenue', color: '#39ff14' }
            ]}
            xAxisKey="date"
            height={300}
            tooltipFormatter={(value) => `$${value.toLocaleString()}`}
          />
        </div>
      </DashboardContent>
    </DashboardShell>
  );
}
```

## 📚 Component Library

### Primitives

#### StatsCard

Display key metrics with trend indicators.

```jsx
<StatsCard
  title="Total Revenue"
  value="$245.2K"
  change={12.5}
  changeLabel="vs last month"
  icon={<DollarSign />}
  trend="up"
  subtitle="All-time high"
  loading={false}
  onClick={() => console.log('Clicked')}
/>
```

**Props:**
- `title` (string): Card title
- `value` (string): Main metric value
- `change` (number): Percentage change (optional)
- `changeLabel` (string): Context for change
- `icon` (ReactNode): Icon component
- `trend` ('up' | 'down' | 'neutral'): Override auto-detection
- `subtitle` (string): Additional context
- `loading` (boolean): Show loading state
- `onClick` (function): Click handler
- `className` (string): Additional CSS classes

#### MetricDisplay

Large, prominent display for hero metrics.

```jsx
<MetricDisplay
  value="99.8%"
  label="Uptime"
  sublabel="Last 30 days"
  size="xl"
  color="success"
  animated={true}
/>
```

**Props:**
- `value` (string): Metric value
- `label` (string): Metric label
- `sublabel` (string): Additional context
- `size` ('sm' | 'md' | 'lg' | 'xl'): Display size
- `color` ('default' | 'success' | 'warning' | 'error' | 'info')
- `loading` (boolean): Show loading state
- `animated` (boolean): Enable entrance animation

#### KPICard

Track progress toward targets.

```jsx
<KPICard
  title="Revenue Target"
  current={245200}
  target={300000}
  unit="$"
  progress={81.7}
  status="warning"
/>
```

**Props:**
- `title` (string): KPI title
- `current` (number): Current value
- `target` (number): Target value
- `unit` (string): Unit of measurement
- `progress` (number): Override calculated progress
- `status` ('success' | 'warning' | 'error' | 'neutral')

#### TrendIndicator

Compact trend display.

```jsx
<TrendIndicator
  value={12.5}
  direction="up"
  size="md"
  showIcon={true}
  showValue={true}
/>
```

#### BadgeChip

Status and category badges.

```jsx
<BadgeChip
  variant="success"
  size="md"
  icon={<CheckCircle />}
  onRemove={() => console.log('Removed')}
>
  Completed
</BadgeChip>
```

### Charts

All chart components use Recharts with responsive containers and brutalist styling.

#### ResponsiveLineChart

```jsx
<ResponsiveLineChart
  data={revenueData}
  lines={[
    { dataKey: 'revenue', name: 'Revenue', color: '#39ff14' },
    { dataKey: 'expenses', name: 'Expenses', color: '#ff6b35' }
  ]}
  xAxisKey="date"
  height={300}
  showGrid={true}
  showLegend={true}
  showTooltip={true}
  tooltipFormatter={(value) => `$${value.toLocaleString()}`}
/>
```

**Props:**
- `data` (array): Chart data
- `lines` (array): Line configurations with `dataKey`, `name`, `color`
- `xAxisKey` (string): X-axis data key
- `height` (number): Chart height in pixels
- `showGrid` (boolean): Show grid lines
- `showLegend` (boolean): Show legend
- `showTooltip` (boolean): Show tooltip on hover
- `tooltipFormatter` (function): Format tooltip values
- `loading` (boolean): Show loading state

#### ResponsiveBarChart

```jsx
<ResponsiveBarChart
  data={salesData}
  bars={[
    { dataKey: 'sales', name: 'Sales', color: '#00bfff' }
  ]}
  xAxisKey="category"
  height={300}
  stacked={false}
  horizontal={false}
/>
```

#### ResponsiveAreaChart

```jsx
<ResponsiveAreaChart
  data={userGrowthData}
  areas={[
    { dataKey: 'users', name: 'Users', color: '#39ff14' }
  ]}
  xAxisKey="month"
  height={300}
  stacked={false}
/>
```

#### ResponsivePieChart

```jsx
<ResponsivePieChart
  data={distributionData}
  dataKey="value"
  nameKey="name"
  height={300}
  showLabels={true}
/>
```

#### MiniSparkline

Compact trend line for inline display.

```jsx
<MiniSparkline
  data={trendData}
  dataKey="value"
  color="#00bfff"
  height={40}
/>
```

### Layouts

#### DashboardShell

Full-page layout with sidebar and header.

```jsx
<DashboardShell
  header={<DashboardHeader title="Dashboard" />}
  sidebar={<DashboardSidebar navigation={navItems} />}
  sidebarOpen={true}
  onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
>
  {/* Page content */}
</DashboardShell>
```

#### DashboardGrid

Responsive grid layout.

```jsx
<DashboardGrid columns={3} gap="md">
  <StatsCard {...} />
  <StatsCard {...} />
  <StatsCard {...} />
</DashboardGrid>
```

**Props:**
- `columns` (1 | 2 | 3 | 4 | 6 | 12): Desktop column count
- `gap` ('sm' | 'md' | 'lg'): Grid gap size
- `className` (string): Additional CSS classes

#### DashboardHeader

Top navigation bar.

```jsx
<DashboardHeader
  title="Analytics Dashboard"
  subtitle="Real-time metrics"
  breadcrumbs={[
    { label: 'Home', href: '/' },
    { label: 'Analytics' }
  ]}
  actions={
    <button>Export Data</button>
  }
  showSidebarToggle={true}
  onSidebarToggle={() => {}}
/>
```

#### DashboardSidebar

Navigation sidebar with logo, nav items, and footer.

```jsx
<DashboardSidebar
  logo={<Logo />}
  navigation={[
    { id: 'home', label: 'Home', icon: <Home />, active: true },
    { id: 'analytics', label: 'Analytics', icon: <BarChart />, badge: '12' }
  ]}
  collapsed={false}
  onCollapse={() => {}}
  footer={<div>v1.0.0</div>}
/>
```

#### DashboardContent

Content wrapper with max-width and padding.

```jsx
<DashboardContent maxWidth="7xl">
  {/* Dashboard sections */}
</DashboardContent>
```

#### DashboardSection

Titled section within dashboard content.

```jsx
<DashboardSection
  title="Key Metrics"
  subtitle="Overview of performance"
  actions={<button>View All</button>}
>
  {/* Section content */}
</DashboardSection>
```

### Data Display

#### DataTable

Sortable, searchable table.

```jsx
<DataTable
  data={transactions}
  columns={[
    { key: 'customer', label: 'Customer' },
    { key: 'amount', label: 'Amount', align: 'right' },
    {
      key: 'status',
      label: 'Status',
      render: (value) => <BadgeChip>{value}</BadgeChip>
    }
  ]}
  sortable={true}
  searchable={true}
  onRowClick={(row) => console.log(row)}
  emptyMessage="No transactions found"
  loading={false}
/>
```

**Column Props:**
- `key` (string): Data key
- `label` (string): Column header
- `align` ('left' | 'center' | 'right'): Text alignment
- `render` (function): Custom cell renderer

#### DataList

Vertical list with custom item rendering.

```jsx
<DataList
  data={activities}
  renderItem={(item) => (
    <DataListItem
      title={item.title}
      subtitle={item.subtitle}
      meta={item.timestamp}
      avatar={<Avatar />}
      actions={<button>View</button>}
    />
  )}
  keyExtractor={(item) => item.id}
  emptyMessage="No activities"
  loading={false}
/>
```

#### EmptyState

No data placeholder.

```jsx
<EmptyState
  icon={<Inbox />}
  message="No data available"
  action={
    <button>Add Data</button>
  }
/>
```

#### LoadingState

Loading indicator.

```jsx
<LoadingState
  message="Loading dashboard data..."
/>
```

#### ErrorState

Error display with retry.

```jsx
<ErrorState
  error={error}
  message="Failed to load data"
  onRetry={() => refetch()}
/>
```

## 🎣 Custom Hooks

### useDashboardData

Fetch and manage dashboard data with auto-refresh.

```jsx
const { data, loading, error, refetch, isSuccess } = useDashboardData(
  async () => {
    const res = await fetch('/api/stats');
    return res.json();
  },
  {
    refreshInterval: 30000, // 30 seconds
    fetchOnMount: true
  }
);
```

**Returns:**
- `data`: Fetched data
- `loading`: Loading state
- `error`: Error object
- `state`: Current state ('idle' | 'loading' | 'success' | 'error')
- `refetch`: Manually trigger fetch
- `isIdle`, `isLoading`, `isSuccess`, `isError`: State booleans

### useDashboardFilters

Manage filter state.

```jsx
const {
  filters,
  updateFilter,
  updateFilters,
  resetFilters,
  hasActiveFilters,
  activeFilterCount
} = useDashboardFilters({
  dateRange: 'last7days',
  status: 'all'
});

// Update single filter
updateFilter('status', 'active');

// Update multiple filters
updateFilters({ status: 'active', dateRange: 'last30days' });

// Reset to initial state
resetFilters();
```

### usePagination

Manage pagination state.

```jsx
const {
  page,
  pageSize,
  setPage,
  setPageSize,
  nextPage,
  prevPage,
  reset,
  offset,
  limit
} = usePagination(1, 20);
```

### useSort

Manage sort state.

```jsx
const {
  sortBy,
  direction,
  updateSort,
  toggleDirection,
  reset,
  isAscending,
  isDescending
} = useSort('createdAt', 'desc');
```

## 🛠️ Utility Functions

### Formatters

```js
import { formatMetric, formatPercent, formatCurrency, formatDate, calculateChange } from '@/components/dashboard';

formatMetric(1234567);          // "1.2M"
formatPercent(12.5);            // "+12.5%"
formatCurrency(1234.56);        // "$1,234.56"
formatDate(new Date(), 'medium'); // "Jan 21, 2026"

const change = calculateChange(120, 100);
// { value: 20, direction: 'up' }
```

## 🎨 Customization

### Theming

The library uses CSS custom properties for colors. Override in your Tailwind config or global CSS:

```css
:root {
  --dashboard-primary: #00bfff;
  --dashboard-success: #39ff14;
  --dashboard-warning: #ff6b35;
  --dashboard-error: #ff4444;
  --dashboard-bg: #1a1a1a;
  --dashboard-border: #2a2a2a;
}
```

### Custom Styles

All components accept `className` prop for additional Tailwind classes:

```jsx
<StatsCard
  className="col-span-2 bg-gradient-to-br from-blue-500 to-purple-600"
  {...props}
/>
```

## 📱 Responsive Design

All components are mobile-first and fully responsive:

- **Mobile (< 640px)**: Single column, stacked layouts
- **Tablet (640px - 1024px)**: 2 columns, simplified charts
- **Desktop (> 1024px)**: Full column count, all features

## ♿ Accessibility

Components follow WCAG 2.1 Level AA guidelines:

- Semantic HTML (proper heading hierarchy, landmarks)
- ARIA attributes (labels, roles, states)
- Keyboard navigation (tab, enter, escape, arrows)
- Focus indicators (3px outline)
- Screen reader support (descriptive labels, live regions)

## 🧪 Testing

Components include proper test IDs and ARIA labels:

```jsx
// Playwright example
await page.getByRole('button', { name: 'Export Data' }).click();
await page.getByRole('table', { name: 'Data table' }).isVisible();
```

## 📦 Package Structure

```
dashboard/
├── index.js                     # Main exports
├── lib/
│   ├── types.js                 # Type constants
│   ├── utils/
│   │   └── formatters.js        # Utility functions
│   └── hooks/
│       └── useDashboardData.js  # Custom hooks
├── primitives/
│   ├── StatsCard.jsx
│   ├── MetricDisplay.jsx
│   └── Additional.jsx
├── charts/
│   └── ResponsiveCharts.jsx
├── layouts/
│   └── Layouts.jsx
├── data/
│   └── DataComponents.jsx
└── examples/
    └── AnalyticsDashboard.jsx
```

## 🚦 Production Checklist

Before deploying dashboards:

- [ ] Replace mock data with real API calls
- [ ] Implement error boundaries
- [ ] Add loading skeletons
- [ ] Test with slow network (3G throttling)
- [ ] Verify keyboard navigation
- [ ] Test screen reader compatibility
- [ ] Check contrast ratios (WCAG AA)
- [ ] Test on physical devices (iOS, Android)
- [ ] Implement analytics tracking
- [ ] Add performance monitoring

## 📄 License

MIT License - see LICENSE file for details

## 🤝 Contributing

1. Follow existing code style (Prettier + ESLint)
2. Add tests for new components
3. Update documentation
4. Submit PR with screenshots

## 📞 Support

For issues or questions:
- GitHub Issues: [your-repo/issues](https://github.com)
- Email: app@base44.com
