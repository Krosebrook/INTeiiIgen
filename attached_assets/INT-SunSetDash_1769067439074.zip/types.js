/**
 * Dashboard Component Library Types
 * 
 * Type definitions for all dashboard components
 */

// ========================================
// Primitive Types
// ========================================

export const StatsTrendType = {
  UP: 'up',
  DOWN: 'down',
  NEUTRAL: 'neutral'
};

export const MetricSize = {
  SM: 'sm',
  MD: 'md',
  LG: 'lg',
  XL: 'xl'
};

export const BadgeVariant = {
  DEFAULT: 'default',
  SUCCESS: 'success',
  WARNING: 'warning',
  ERROR: 'error',
  INFO: 'info'
};

// ========================================
// Chart Types
// ========================================

export const ChartType = {
  LINE: 'line',
  BAR: 'bar',
  AREA: 'area',
  PIE: 'pie',
  SPARKLINE: 'sparkline'
};

// ========================================
// Data Types
// ========================================

export const DataLoadingState = {
  IDLE: 'idle',
  LOADING: 'loading',
  SUCCESS: 'success',
  ERROR: 'error'
};

export const TableSortDirection = {
  ASC: 'asc',
  DESC: 'desc',
  NONE: 'none'
};

// ========================================
// Layout Types
// ========================================

export const DashboardLayout = {
  GRID: 'grid',
  STACK: 'stack',
  MASONRY: 'masonry'
};

export const GridColumns = {
  ONE: 1,
  TWO: 2,
  THREE: 3,
  FOUR: 4,
  SIX: 6,
  TWELVE: 12
};
