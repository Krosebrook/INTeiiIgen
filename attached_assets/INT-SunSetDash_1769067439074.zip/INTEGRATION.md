# Dashboard Library Integration Guide

Quick guide for integrating the dashboard library into your Base44 app.

## Step 1: Copy Files

Copy the entire dashboard library to your project:

```bash
cp -r dashboard-library/src/components/dashboard /path/to/your/base44-app/src/components/
```

Your project structure should now look like:

```
src/
├── components/
│   ├── dashboard/
│   │   ├── index.js
│   │   ├── dashboard.css
│   │   ├── lib/
│   │   ├── primitives/
│   │   ├── charts/
│   │   ├── layouts/
│   │   ├── data/
│   │   └── examples/
│   └── ui/                  # Your existing shadcn/ui components
└── ...
```

## Step 2: Import Dashboard Styles

Add dashboard styles to your main `src/index.css`:

```css
/* src/index.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

/* Import dashboard styles after Tailwind */
@import './components/dashboard/dashboard.css';

/* Your existing custom styles */
```

## Step 3: Verify Dependencies

Check that you have all required dependencies in `package.json`:

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "recharts": "^2.15.1",
    "framer-motion": "^12.4.7",
    "lucide-react": "^0.475.0"
  }
}
```

If missing, install them:

```bash
npm install recharts framer-motion
```

## Step 4: Create Your First Dashboard

Create a new dashboard page in `src/pages/Dashboard.jsx`:

```jsx
import React from 'react';
import { DollarSign, Users, TrendingUp } from 'lucide-react';
import {
  DashboardShell,
  DashboardHeader,
  DashboardContent,
  DashboardGrid,
  StatsCard,
  ResponsiveLineChart
} from '@/components/dashboard';

export function Dashboard() {
  // Mock data (replace with real API calls)
  const revenueData = [
    { month: 'Jan', revenue: 45000 },
    { month: 'Feb', revenue: 52000 },
    { month: 'Mar', revenue: 48000 },
    { month: 'Apr', revenue: 61000 },
    { month: 'May', revenue: 55000 },
    { month: 'Jun', revenue: 67000 }
  ];
  
  return (
    <DashboardShell
      header={
        <DashboardHeader
          title="Dashboard"
          subtitle="Welcome back!"
        />
      }
    >
      <DashboardContent>
        <DashboardGrid columns={3} gap="md">
          <StatsCard
            title="Total Revenue"
            value="$328K"
            change={23.5}
            changeLabel="vs last quarter"
            icon={<DollarSign />}
          />
          
          <StatsCard
            title="Active Users"
            value="1,842"
            change={12.3}
            changeLabel="vs last month"
            icon={<Users />}
          />
          
          <StatsCard
            title="Conversion Rate"
            value="3.47%"
            change={-2.1}
            changeLabel="vs last month"
            icon={<TrendingUp />}
          />
        </DashboardGrid>
        
        <div className="mt-8">
          <ResponsiveLineChart
            data={revenueData}
            lines={[
              { dataKey: 'revenue', name: 'Revenue', color: '#39ff14' }
            ]}
            xAxisKey="month"
            height={300}
            tooltipFormatter={(value) => `$${value.toLocaleString()}`}
          />
        </div>
      </DashboardContent>
    </DashboardShell>
  );
}
```

## Step 5: Add Route

Add the dashboard route to your router configuration:

```jsx
// src/App.jsx or your router setup
import { Dashboard } from './pages/Dashboard';

// React Router v6 example
<Route path="/dashboard" element={<Dashboard />} />
```

## Step 6: Connect to Base44 API

Replace mock data with Base44 SDK calls:

```jsx
import React from 'react';
import { useEntity } from '@base44/sdk'; // Your Base44 SDK import
import { useDashboardData } from '@/components/dashboard';

export function Dashboard() {
  // Using Base44 SDK
  const { data, loading, error } = useDashboardData(
    async () => {
      const response = await fetch('/api/stats', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      return response.json();
    },
    { refreshInterval: 30000 } // Auto-refresh every 30s
  );
  
  if (loading) return <LoadingState />;
  if (error) return <ErrorState error={error} />;
  
  return (
    <DashboardShell>
      {/* Your dashboard components using data */}
    </DashboardShell>
  );
}
```

## Step 7: Run Example Dashboard

Try the complete example dashboard:

```jsx
// src/pages/ExampleDashboard.jsx
import { AnalyticsDashboard } from '@/components/dashboard/examples/AnalyticsDashboard';

export function ExampleDashboard() {
  return <AnalyticsDashboard />;
}
```

Add route:
```jsx
<Route path="/example-dashboard" element={<ExampleDashboard />} />
```

Visit: `http://localhost:5173/example-dashboard`

## Common Integration Patterns

### Pattern 1: Real-Time Data Updates

```jsx
import { useDashboardData } from '@/components/dashboard';

function LiveMetrics() {
  const { data, loading } = useDashboardData(
    async () => {
      const res = await fetch('/api/live-metrics');
      return res.json();
    },
    { refreshInterval: 5000 } // Update every 5 seconds
  );
  
  return (
    <StatsCard
      title="Active Users"
      value={data?.activeUsers || '—'}
      loading={loading}
    />
  );
}
```

### Pattern 2: Filtered Data

```jsx
import { useDashboardFilters } from '@/components/dashboard';

function FilteredDashboard() {
  const { filters, updateFilter } = useDashboardFilters({
    dateRange: 'last7days',
    status: 'all'
  });
  
  const { data } = useDashboardData(
    async () => {
      const params = new URLSearchParams(filters);
      const res = await fetch(`/api/stats?${params}`);
      return res.json();
    },
    { fetchOnMount: true }
  );
  
  return (
    <>
      <select
        value={filters.dateRange}
        onChange={(e) => updateFilter('dateRange', e.target.value)}
      >
        <option value="last7days">Last 7 Days</option>
        <option value="last30days">Last 30 Days</option>
        <option value="last90days">Last 90 Days</option>
      </select>
      
      {/* Dashboard components using filtered data */}
    </>
  );
}
```

### Pattern 3: Multiple Data Sources

```jsx
function MultiSourceDashboard() {
  const { data: stats } = useDashboardData(() => fetch('/api/stats').then(r => r.json()));
  const { data: users } = useDashboardData(() => fetch('/api/users').then(r => r.json()));
  const { data: revenue } = useDashboardData(() => fetch('/api/revenue').then(r => r.json()));
  
  return (
    <DashboardGrid columns={3}>
      <StatsCard title="Total Users" value={stats?.totalUsers} />
      <StatsCard title="Active Now" value={users?.activeUsers} />
      <StatsCard title="Revenue" value={revenue?.total} />
    </DashboardGrid>
  );
}
```

## Troubleshooting

### Issue: Components not styling correctly

**Solution:** Ensure dashboard.css is imported after Tailwind directives:

```css
/* src/index.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

@import './components/dashboard/dashboard.css'; /* Must be after Tailwind */
```

### Issue: Charts not rendering

**Solution:** Verify recharts is installed:

```bash
npm install recharts
```

### Issue: Icons not showing

**Solution:** Ensure lucide-react is installed:

```bash
npm install lucide-react
```

### Issue: Path alias '@' not working

**Solution:** Check jsconfig.json has correct path mapping:

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

## Next Steps

1. **Replace Mock Data**: Connect components to your Base44 API
2. **Customize Styling**: Modify colors in dashboard.css or Tailwind config
3. **Add Authentication**: Protect dashboard routes with auth guards
4. **Implement Pagination**: Use usePagination hook for large datasets
5. **Add Error Boundaries**: Wrap dashboard in error boundary component
6. **Setup Analytics**: Track dashboard interactions with PostHog/Mixpanel
7. **Optimize Performance**: Implement data caching and memoization
8. **Test Responsiveness**: Verify on mobile, tablet, and desktop devices

## Performance Optimization

```jsx
import { memo, useMemo } from 'react';

// Memoize expensive components
const MemoizedChart = memo(ResponsiveLineChart);

function OptimizedDashboard({ data }) {
  // Memoize computed values
  const processedData = useMemo(() => {
    return data.map(item => ({
      ...item,
      revenue: item.revenue / 1000 // Convert to thousands
    }));
  }, [data]);
  
  return (
    <MemoizedChart data={processedData} />
  );
}
```

## Production Checklist

- [ ] Replace all mock data with real API calls
- [ ] Add loading states for all data fetches
- [ ] Implement error boundaries
- [ ] Add authentication/authorization checks
- [ ] Test on slow network (3G throttling)
- [ ] Verify keyboard navigation works
- [ ] Test with screen readers
- [ ] Check color contrast (WCAG AA minimum)
- [ ] Test on real devices (not just DevTools)
- [ ] Implement proper error logging (Sentry)
- [ ] Add performance monitoring
- [ ] Setup automated tests

## Support

For questions or issues:
- Documentation: See README.md in dashboard library
- Examples: Check `src/components/dashboard/examples/`
- Base44 Support: app@base44.com
