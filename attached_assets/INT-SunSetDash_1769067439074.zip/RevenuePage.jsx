/**
 * RevenuePage.jsx - Revenue Dashboard
 * 
 * Detailed revenue tracking with animated charts and transaction history
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  Filter,
  Search,
  ArrowUpRight,
  ArrowDownRight,
  CreditCard,
  Wallet,
  PieChart,
  BarChart3,
  ChevronRight
} from 'lucide-react';
import {
  ResponsiveLineChart,
  ResponsiveBarChart,
  ResponsivePieChart,
  ResponsiveAreaChart
} from '../components/dashboard/charts/ResponsiveCharts';

const pageVariants = {
  initial: { opacity: 0, scale: 0.98 },
  animate: { 
    opacity: 1, 
    scale: 1,
    transition: {
      duration: 0.4,
      staggerChildren: 0.08
    }
  },
  exit: { opacity: 0, scale: 1.02, transition: { duration: 0.3 } }
};

const cardVariants = {
  initial: { opacity: 0, y: 30, rotateX: -15 },
  animate: { 
    opacity: 1, 
    y: 0, 
    rotateX: 0,
    transition: {
      type: 'spring',
      stiffness: 100,
      damping: 15
    }
  }
};

export function RevenuePage() {
  const navigate = useNavigate();
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [searchTerm, setSearchTerm] = useState('');
  const [hoveredCard, setHoveredCard] = useState(null);

  // Revenue data
  const monthlyRevenue = [
    { month: 'Jan', revenue: 45000, transactions: 234, avgOrder: 192 },
    { month: 'Feb', revenue: 52000, transactions: 267, avgOrder: 195 },
    { month: 'Mar', revenue: 48000, transactions: 245, avgOrder: 196 },
    { month: 'Apr', revenue: 61000, transactions: 312, avgOrder: 195 },
    { month: 'May', revenue: 55000, transactions: 278, avgOrder: 198 },
    { month: 'Jun', revenue: 67000, transactions: 338, avgOrder: 198 }
  ];

  const revenueByCategory = [
    { category: 'Products', amount: 45200, percentage: 62 },
    { category: 'Services', amount: 18400, percentage: 25 },
    { category: 'Subscriptions', amount: 9500, percentage: 13 }
  ];

  const paymentMethods = [
    { method: 'Credit Card', value: 58 },
    { method: 'PayPal', value: 25 },
    { method: 'Bank Transfer', value: 12 },
    { method: 'Crypto', value: 5 }
  ];

  const transactions = [
    {
      id: 'TRX-2024-001',
      customer: 'Sarah Johnson',
      amount: 1234.56,
      status: 'completed',
      method: 'Credit Card',
      date: '2024-06-15 14:32',
      category: 'Products'
    },
    {
      id: 'TRX-2024-002',
      customer: 'Mike Chen',
      amount: 892.00,
      status: 'completed',
      method: 'PayPal',
      date: '2024-06-15 13:15',
      category: 'Services'
    },
    {
      id: 'TRX-2024-003',
      customer: 'Emma Wilson',
      amount: 2456.78,
      status: 'pending',
      method: 'Bank Transfer',
      date: '2024-06-15 11:42',
      category: 'Products'
    },
    {
      id: 'TRX-2024-004',
      customer: 'James Brown',
      amount: 567.34,
      status: 'completed',
      method: 'Credit Card',
      date: '2024-06-14 16:28',
      category: 'Subscriptions'
    },
    {
      id: 'TRX-2024-005',
      customer: 'Lisa Anderson',
      amount: 1890.50,
      status: 'failed',
      method: 'PayPal',
      date: '2024-06-14 10:15',
      category: 'Products'
    }
  ];

  const stats = [
    {
      id: 'total',
      label: 'Total Revenue',
      value: '$328.2K',
      change: 23.5,
      icon: <DollarSign />,
      description: 'Last 6 months',
      gradient: 'from-[#FF8C42] via-[#F4C430] to-[#FFB380]'
    },
    {
      id: 'avg',
      label: 'Average Order',
      value: '$196',
      change: 5.2,
      icon: <Wallet />,
      description: 'Per transaction',
      gradient: 'from-[#F4C430] via-[#FFB380] to-[#FF8C42]'
    },
    {
      id: 'transactions',
      label: 'Transactions',
      value: '1,674',
      change: 18.4,
      icon: <CreditCard />,
      description: 'Total count',
      gradient: 'from-[#FFB380] via-[#FF8C42] to-[#F4C430]'
    },
    {
      id: 'growth',
      label: 'Growth Rate',
      value: '+23.5%',
      change: 3.2,
      icon: <TrendingUp />,
      description: 'Month over month',
      gradient: 'from-[#2C5F6F] via-[#4A8A9F] to-[#7BC67E]'
    }
  ];

  const statusColors = {
    completed: { bg: 'bg-[#7BC67E]/15', text: 'text-[#7BC67E]' },
    pending: { bg: 'bg-[#FFB347]/15', text: 'text-[#FFB347]' },
    failed: { bg: 'bg-[#FF6B6B]/15', text: 'text-[#FF6B6B]' }
  };

  const filteredTransactions = transactions.filter(tx =>
    tx.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      className="p-6 space-y-6"
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      {/* Header */}
      <motion.div variants={cardVariants} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#F5E6D3] mb-2 flex items-center gap-3">
            <motion.div
              className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF8C42] to-[#F4C430] flex items-center justify-center shadow-xl"
              whileHover={{ rotate: 360, scale: 1.1 }}
              transition={{ duration: 0.6, type: 'spring' }}
            >
              <DollarSign className="text-[#1A2F38]" size={24} />
            </motion.div>
            Revenue Dashboard
          </h1>
          <p className="text-[#8A7F6F]">Track sales, transactions, and revenue streams</p>
        </div>

        <div className="flex items-center gap-3">
          {['day', 'week', 'month', 'year'].map((period) => (
            <motion.button
              key={period}
              onClick={() => setSelectedPeriod(period)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all
                ${selectedPeriod === period
                  ? 'bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] shadow-lg shadow-[#FF8C42]/30'
                  : 'bg-[#243947] text-[#C4B5A0] hover:text-[#F5E6D3] border border-[#F4C430]/10'
                }
              `}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              {period}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Revenue Stats Cards */}
      <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.id}
            className="relative bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-6 overflow-hidden group cursor-pointer perspective-1000"
            variants={cardVariants}
            onMouseEnter={() => setHoveredCard(stat.id)}
            onMouseLeave={() => setHoveredCard(null)}
            whileHover={{ 
              y: -12,
              rotateY: hoveredCard === stat.id ? 5 : 0,
              boxShadow: '0 20px 60px rgba(255, 140, 66, 0.3)'
            }}
          >
            {/* Animated gradient background */}
            <motion.div
              className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10`}
              initial={false}
              animate={{
                opacity: hoveredCard === stat.id ? 0.15 : 0,
                scale: hoveredCard === stat.id ? 1.1 : 1
              }}
              transition={{ duration: 0.6 }}
            />

            {/* Animated particles */}
            {hoveredCard === stat.id && (
              <motion.div
                className="absolute inset-0 overflow-hidden"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {[...Array(10)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-[#F4C430] rounded-full"
                    initial={{ 
                      x: Math.random() * 300,
                      y: Math.random() * 200,
                      scale: 0 
                    }}
                    animate={{
                      y: -100,
                      scale: [0, 1, 0],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2,
                      delay: i * 0.1,
                      repeat: Infinity
                    }}
                  />
                ))}
              </motion.div>
            )}

            <div className="relative z-10">
              {/* Icon with pulse effect */}
              <motion.div
                className={`w-14 h-14 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-xl mb-4`}
                animate={{
                  boxShadow: hoveredCard === stat.id 
                    ? ['0 0 0 0 rgba(255, 140, 66, 0.4)', '0 0 0 20px rgba(255, 140, 66, 0)']
                    : '0 10px 30px rgba(255, 140, 66, 0.2)'
                }}
                transition={{ 
                  duration: 1.5,
                  repeat: hoveredCard === stat.id ? Infinity : 0
                }}
              >
                <motion.div
                  className="text-[#1A2F38]"
                  animate={{
                    rotate: hoveredCard === stat.id ? [0, 10, -10, 0] : 0,
                    scale: hoveredCard === stat.id ? [1, 1.1, 1] : 1
                  }}
                  transition={{ duration: 0.5 }}
                >
                  {stat.icon}
                </motion.div>
              </motion.div>

              <p className="text-sm text-[#C4B5A0] font-medium mb-1">{stat.label}</p>
              
              {/* Animated value */}
              <motion.p
                className="text-3xl font-bold text-[#F5E6D3] mb-1"
                animate={{
                  scale: hoveredCard === stat.id ? [1, 1.05, 1] : 1
                }}
                transition={{ duration: 0.3 }}
              >
                {stat.value}
              </motion.p>

              <div className="flex items-center justify-between">
                <div className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                  stat.change > 0 
                    ? 'bg-[#7BC67E]/15 text-[#7BC67E]'
                    : 'bg-[#FF6B6B]/15 text-[#FF6B6B]'
                }`}>
                  {stat.change > 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {Math.abs(stat.change)}%
                </div>
                <span className="text-xs text-[#8A7F6F]">{stat.description}</span>
              </div>
            </div>

            {/* Corner decoration */}
            <motion.div
              className="absolute -bottom-6 -right-6 w-24 h-24 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-transparent blur-2xl"
              animate={{
                scale: hoveredCard === stat.id ? 1.5 : 1,
                opacity: hoveredCard === stat.id ? 0.3 : 0.1
              }}
            />
          </motion.div>
        ))}
      </motion.div>

      {/* Charts Row */}
      <motion.div className="grid grid-cols-1 lg:grid-cols-2 gap-6" variants={cardVariants}>
        {/* Revenue Trend */}
        <motion.div
          className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-6"
          whileHover={{ 
            boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)',
            borderColor: 'rgba(244, 196, 48, 0.2)'
          }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-[#F5E6D3] mb-1 flex items-center gap-2">
                <BarChart3 size={20} className="text-[#FF8C42]" />
                Revenue Trend
              </h3>
              <p className="text-sm text-[#8A7F6F]">Monthly performance</p>
            </div>
          </div>

          <ResponsiveAreaChart
            data={monthlyRevenue}
            areas={[
              { dataKey: 'revenue', name: 'Revenue', color: '#FF8C42' }
            ]}
            xAxisKey="month"
            height={300}
            showGrid={true}
            showLegend={false}
            tooltipFormatter={(value) => `$${(value / 1000).toFixed(1)}K`}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>

        {/* Payment Methods */}
        <motion.div
          className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-6"
          whileHover={{ 
            boxShadow: '0 12px 40px rgba(0, 0, 0, 0.3)',
            borderColor: 'rgba(244, 196, 48, 0.2)'
          }}
        >
          <div className="mb-6">
            <h3 className="text-xl font-bold text-[#F5E6D3] mb-1 flex items-center gap-2">
              <PieChart size={20} className="text-[#F4C430]" />
              Payment Methods
            </h3>
            <p className="text-sm text-[#8A7F6F]">Distribution by payment type</p>
          </div>

          <ResponsivePieChart
            data={paymentMethods}
            dataKey="value"
            nameKey="method"
            height={300}
            showLabels={true}
            tooltipFormatter={(value) => `${value}%`}
            className="border-0 bg-transparent p-0"
          />
        </motion.div>
      </motion.div>

      {/* Transactions Table */}
      <motion.div
        className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 overflow-hidden"
        variants={cardVariants}
      >
        {/* Table Header */}
        <div className="p-6 border-b border-[#F4C430]/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-bold text-[#F5E6D3] mb-1">Recent Transactions</h3>
              <p className="text-sm text-[#8A7F6F]">Latest revenue activity</p>
            </div>

            <div className="flex items-center gap-3">
              <motion.button
                className="p-2 rounded-lg bg-[#1A2F38] border border-[#F4C430]/10 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Filter size={18} />
              </motion.button>
              
              <motion.button
                className="p-2 rounded-lg bg-[#1A2F38] border border-[#F4C430]/10 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Download size={18} />
              </motion.button>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8A7F6F]" size={18} />
            <input
              type="text"
              placeholder="Search transactions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#1A2F38] border border-[#F4C430]/10 rounded-lg text-[#F5E6D3] placeholder-[#8A7F6F] focus:outline-none focus:border-[#FF8C42] transition-colors"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1A2F38] border-b border-[#F4C430]/10">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Transaction ID</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Customer</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Method</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Status</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Date</th>
                <th className="text-center py-4 px-6 text-sm font-semibold text-[#C4B5A0]">Actions</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {filteredTransactions.map((tx, index) => (
                  <motion.tr
                    key={tx.id}
                    className="border-b border-[#F4C430]/10 hover:bg-[#1A2F38] transition-colors cursor-pointer group"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => navigate(`/revenue/${tx.id}`)}
                    whileHover={{ x: 4, backgroundColor: 'rgba(26, 47, 56, 0.5)' }}
                  >
                    <td className="py-4 px-6">
                      <span className="text-[#F5E6D3] font-mono text-sm">{tx.id}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-[#F5E6D3] font-medium">{tx.customer}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-[#F5E6D3] font-bold">${tx.amount.toFixed(2)}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-[#C4B5A0] text-sm">{tx.method}</span>
                    </td>
                    <td className="py-4 px-6">
                      <motion.span
                        className={`inline-flex px-3 py-1 rounded-full text-xs font-semibold capitalize ${statusColors[tx.status].bg} ${statusColors[tx.status].text}`}
                        whileHover={{ scale: 1.05 }}
                      >
                        {tx.status}
                      </motion.span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-[#8A7F6F] text-sm">{tx.date}</span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center">
                        <motion.button
                          className="p-2 rounded-lg text-[#8A7F6F] group-hover:text-[#FF8C42] transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/revenue/${tx.id}`);
                          }}
                        >
                          <ChevronRight size={18} />
                        </motion.button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}
