import React from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, CreditCard, Calendar, DollarSign, CheckCircle, Clock, XCircle } from 'lucide-react';

export function RevenueDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const transaction = {
    id: id,
    customer: 'Sarah Johnson',
    email: 'sarah.j@example.com',
    amount: 1234.56,
    status: 'completed',
    method: 'Credit Card',
    date: '2024-06-15 14:32',
    category: 'Products',
    items: [
      { name: 'Product A', quantity: 2, price: 299.99 },
      { name: 'Product B', quantity: 1, price: 634.58 }
    ]
  };

  const statusConfig = {
    completed: { icon: <CheckCircle />, color: 'from-[#7BC67E] to-[#4A8A9F]', bg: 'bg-[#7BC67E]/15', text: 'text-[#7BC67E]' },
    pending: { icon: <Clock />, color: 'from-[#FFB347] to-[#F4C430]', bg: 'bg-[#FFB347]/15', text: 'text-[#FFB347]' },
    failed: { icon: <XCircle />, color: 'from-[#FF6B6B] to-[#FF8C42]', bg: 'bg-[#FF6B6B]/15', text: 'text-[#FF6B6B]' }
  };

  const config = statusConfig[transaction.status];

  return (
    <motion.div
      className="p-6 space-y-6"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.4 }}
    >
      <button
        onClick={() => navigate('/revenue')}
        className="flex items-center gap-2 text-[#C4B5A0] hover:text-[#F5E6D3] transition-colors mb-4"
      >
        <ArrowLeft size={20} />
        Back to Revenue
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <motion.div
            className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-sm text-[#8A7F6F] mb-1">Transaction ID</p>
                <h1 className="text-2xl font-bold text-[#F5E6D3] font-mono">{transaction.id}</h1>
              </div>
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${config.bg} ${config.text} font-semibold`}>
                {config.icon}
                {transaction.status}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              {[
                { icon: <User />, label: 'Customer', value: transaction.customer, color: 'from-[#FF8C42] to-[#F4C430]' },
                { icon: <Calendar />, label: 'Date', value: transaction.date, color: 'from-[#F4C430] to-[#FFB380]' },
                { icon: <CreditCard />, label: 'Payment Method', value: transaction.method, color: 'from-[#FFB380] to-[#FF8C42]' },
                { icon: <DollarSign />, label: 'Category', value: transaction.category, color: 'from-[#2C5F6F] to-[#4A8A9F]' }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  className="bg-[#1A2F38] rounded-xl p-4 flex items-center gap-3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + i * 0.05 }}
                >
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center shadow-lg flex-shrink-0`}>
                    <div className="text-[#1A2F38]">{item.icon}</div>
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-[#8A7F6F]">{item.label}</p>
                    <p className="text-sm font-medium text-[#F5E6D3] truncate">{item.value}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <h3 className="text-lg font-bold text-[#F5E6D3] mb-4">Order Items</h3>
            <div className="space-y-3">
              {transaction.items.map((item, i) => (
                <motion.div
                  key={i}
                  className="flex items-center justify-between p-4 bg-[#1A2F38] rounded-xl"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                >
                  <div>
                    <p className="font-medium text-[#F5E6D3]">{item.name}</p>
                    <p className="text-sm text-[#8A7F6F]">Quantity: {item.quantity}</p>
                  </div>
                  <p className="font-bold text-[#F5E6D3]">${item.price.toFixed(2)}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div
          className="bg-[#243947] rounded-2xl border border-[#F4C430]/10 p-8"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-xl font-bold text-[#F5E6D3] mb-6">Summary</h3>
          
          <div className="space-y-4 mb-6">
            <div className="flex justify-between">
              <span className="text-[#8A7F6F]">Subtotal</span>
              <span className="text-[#F5E6D3] font-medium">${(transaction.amount * 0.9).toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8A7F6F]">Tax (10%)</span>
              <span className="text-[#F5E6D3] font-medium">${(transaction.amount * 0.1).toFixed(2)}</span>
            </div>
            <div className="h-px bg-[#F4C430]/10" />
            <div className="flex justify-between">
              <span className="text-lg font-bold text-[#F5E6D3]">Total</span>
              <span className="text-2xl font-bold text-[#FF8C42]">${transaction.amount.toFixed(2)}</span>
            </div>
          </div>

          <motion.button
            className="w-full px-6 py-3 bg-gradient-to-r from-[#FF8C42] to-[#F4C430] text-[#1A2F38] rounded-xl font-medium shadow-lg shadow-[#FF8C42]/30"
            whileHover={{ scale: 1.02, boxShadow: '0 8px 32px rgba(255, 140, 66, 0.5)' }}
            whileTap={{ scale: 0.98 }}
          >
            Download Invoice
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
}
