/**
 * MetricDisplay Component
 * 
 * Large, prominent display for single key metrics
 * Perfect for hero stats at top of dashboards
 * 
 * @example
 * <MetricDisplay
 *   value="99.8%"
 *   label="Uptime"
 *   size="xl"
 *   color="success"
 * />
 */

import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export function MetricDisplay({
  value,
  label,
  sublabel = null,
  size = 'lg', // 'sm' | 'md' | 'lg' | 'xl'
  color = 'default', // 'default' | 'success' | 'warning' | 'error' | 'info'
  className = '',
  loading = false,
  animated = true,
  'aria-label': ariaLabel
}) {
  // Size classes
  const sizeClasses = {
    sm: 'text-2xl',
    md: 'text-4xl',
    lg: 'text-6xl',
    xl: 'text-8xl'
  };
  
  const labelSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg'
  };
  
  // Color classes
  const colorClasses = {
    default: 'text-white',
    success: 'text-[#39ff14]',
    warning: 'text-[#ff6b35]',
    error: 'text-red-500',
    info: 'text-[#00bfff]'
  };
  
  // Container classes
  const containerClasses = cn(
    'relative flex flex-col items-center justify-center',
    'p-8',
    'bg-[#1a1a1a] border-2 border-neutral-800',
    loading && 'animate-pulse',
    className
  );
  
  // Animation variants
  const counterVariants = animated ? {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
        damping: 15
      }
    }
  } : {};
  
  return (
    <div
      className={containerClasses}
      role="status"
      aria-label={ariaLabel || `${label}: ${value}`}
    >
      {/* Decorative corner brackets */}
      <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-[#00bfff]" />
      <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-[#00bfff]" />
      <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-[#00bfff]" />
      <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-[#00bfff]" />
      
      {/* Metric value */}
      <motion.div
        className={cn(
          'font-mono font-bold tabular-nums',
          sizeClasses[size],
          colorClasses[color],
          loading && 'text-neutral-700'
        )}
        variants={counterVariants}
        initial={animated ? "hidden" : undefined}
        animate={animated ? "visible" : undefined}
      >
        {loading ? '—' : value}
      </motion.div>
      
      {/* Label */}
      <div className="mt-4 text-center">
        <div className={cn(
          'font-mono uppercase tracking-widest text-neutral-400',
          labelSizeClasses[size]
        )}>
          {label}
        </div>
        
        {sublabel && (
          <div className="mt-1 text-xs text-neutral-500 font-mono">
            {sublabel}
          </div>
        )}
      </div>
      
      {/* Geometric accent line */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#00bfff] to-[#39ff14]" />
    </div>
  );
}

// Grid of metrics
export function MetricGrid({
  metrics,
  columns = 3,
  className = ''
}) {
  const gridClasses = cn(
    'grid gap-4',
    {
      'grid-cols-1': columns === 1,
      'grid-cols-2': columns === 2,
      'grid-cols-3': columns === 3,
      'grid-cols-4': columns === 4
    },
    'sm:grid-cols-1',
    `md:grid-cols-${Math.min(columns, 2)}`,
    `lg:grid-cols-${columns}`,
    className
  );
  
  return (
    <div className={gridClasses}>
      {metrics.map((metric, index) => (
        <MetricDisplay
          key={metric.id || index}
          {...metric}
        />
      ))}
    </div>
  );
}

export default MetricDisplay;
