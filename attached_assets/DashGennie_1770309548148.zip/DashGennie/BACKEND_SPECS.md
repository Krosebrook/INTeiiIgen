# INTrospective - Future Backend Implementation Specifications

**Version:** 2.0.0 (Backend-Enabled)  
**Current Version:** 1.0.0 (Client-Side Only)  
**Status:** Planning Documentation  
**Date:** January 16, 2026

---

## Executive Summary

This document outlines the specifications, architecture, and implementation roadmap for adding a **production backend** to the current client-side INTrospective dashboard generator. The backend will enable:

1. **Semantic Layer** - Centralized metric definitions and business logic
2. **Persistent Storage** - Save dashboards, share templates
3. **Team Collaboration** - Multi-user workspaces
4. **Advanced Analytics** - ML-powered insights and recommendations
5. **Enterprise Features** - SSO, audit logs, governance

---

## Current Architecture (v1.0.0 - Client-Side Only)

### What Works Without Backend

```
User Browser (PWA)
├── File Upload (drag/drop)
├── Client-Side Parsing
│   ├── CSV → Papa Parse
│   ├── Excel → SheetJS
│   └── JSON → Native
├── Data Analysis
│   ├── Automatic KPI detection
│   ├── Trend calculation
│   └── Distribution analysis
├── Visualization
│   ├── Chart.js (line/bar/pie)
│   └── Responsive HTML/CSS
└── Export
    ├── Standalone HTML
    └── Print-ready
```

### Limitations of Client-Side Approach

| Feature | Status | Why Backend Needed |
|---------|--------|-------------------|
| **Persistence** | ❌ | Data lost on refresh |
| **Sharing** | ❌ | No way to send dashboard to others |
| **Collaboration** | ❌ | Single-user only |
| **Large Files** | ⚠️ | 50MB browser limit |
| **Real-Time Data** | ❌ | No API connections |
| **Semantic Layer** | ❌ | No metric definitions |
| **Version Control** | ❌ | Can't track changes |
| **Access Control** | ❌ | Public to anyone with file |

---

## Future Backend Architecture (v2.0.0)

### System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Client (React PWA)                        │
│  ┌────────────┬────────────┬────────────┬────────────┐      │
│  │ Upload UI  │ Dashboard  │ Share UI   │ Settings   │      │
│  └────────────┴────────────┴────────────┴────────────┘      │
└───────────────────────┬─────────────────────────────────────┘
                        │ HTTPS (REST + WebSockets)
┌───────────────────────▼─────────────────────────────────────┐
│                    API Gateway (FastAPI)                      │
│  ┌────────────┬────────────┬────────────┬────────────┐      │
│  │ /uploads   │ /dashboards│ /metrics   │ /auth      │      │
│  └────────────┴────────────┴────────────┴────────────┘      │
└───────────────────────┬─────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
┌───────▼──────┐ ┌──────▼──────┐ ┌────▼─────┐
│  PostgreSQL  │ │    Redis    │ │   S3     │
│  (Metadata)  │ │   (Cache)   │ │ (Files)  │
└──────────────┘ └─────────────┘ └──────────┘
        │
┌───────▼──────────────────────────────────────────────┐
│         Semantic Layer (dbt MetricFlow)               │
│  ┌─────────┬─────────┬─────────┬─────────┐          │
│  │ Metrics │ Glossary│ Joins   │ Security│          │
│  └─────────┴─────────┴─────────┴─────────┘          │
└──────────────────────────────────────────────────────┘
```

---

## Backend Specifications

### 1. API Endpoints (RESTful)

#### Authentication
```
POST   /api/auth/login
POST   /api/auth/logout
POST   /api/auth/refresh
GET    /api/auth/me
```

#### File Uploads
```
POST   /api/uploads
  Body: multipart/form-data
  Fields:
    - files: File[] (CSV/XLSX/JSON)
    - workspace_id: UUID (optional)
  Response:
    {
      "dataset_id": "ds_abc123",
      "filename": "sales_2024.csv",
      "size_bytes": 1048576,
      "rows": 15000,
      "columns": ["date", "revenue", "region"],
      "inferred_types": {
        "date": "datetime",
        "revenue": "float64",
        "region": "category"
      },
      "preview_url": "/api/datasets/ds_abc123/preview",
      "expires_at": "2026-01-23T00:00:00Z"
    }

GET    /api/uploads/{upload_id}
DELETE /api/uploads/{upload_id}
```

#### Datasets
```
GET    /api/datasets
GET    /api/datasets/{dataset_id}
GET    /api/datasets/{dataset_id}/preview?limit=100
POST   /api/datasets/{dataset_id}/analyze
  Response:
    {
      "numeric_columns": ["revenue", "quantity"],
      "categorical_columns": ["region", "product"],
      "time_columns": ["date"],
      "suggested_metrics": [
        {
          "name": "total_revenue",
          "expression": "SUM(revenue)",
          "confidence": 0.95
        }
      ],
      "suggested_dimensions": [
        {
          "name": "region",
          "type": "categorical",
          "cardinality": 4
        }
      ]
    }
```

#### Semantic Layer (Metrics)
```
POST   /api/metrics
  Body:
    {
      "name": "total_revenue",
      "expression": "SUM(revenue)",
      "description": "Total revenue across all transactions",
      "dimensions": ["region", "product"],
      "filters": {},
      "format": "currency_usd"
    }

GET    /api/metrics
GET    /api/metrics/{metric_id}
PUT    /api/metrics/{metric_id}
DELETE /api/metrics/{metric_id}
```

#### Dashboards
```
POST   /api/dashboards/generate
  Body:
    {
      "dataset_id": "ds_abc123",
      "semantic_model_id": "sm_xyz789",
      "intent": "executive_summary",
      "options": {
        "max_charts": 6,
        "viz_engine": "chartjs"
      }
    }
  Response:
    {
      "dashboards": [
        {
          "dashboard_id": "db_opt1",
          "title": "Revenue Overview",
          "charts": [...]
        },
        {
          "dashboard_id": "db_opt2",
          "title": "Regional Performance",
          "charts": [...]
        },
        {
          "dashboard_id": "db_opt3",
          "title": "Executive Summary",
          "charts": [...]
        }
      ]
    }

POST   /api/dashboards
GET    /api/dashboards
GET    /api/dashboards/{dashboard_id}
PUT    /api/dashboards/{dashboard_id}
DELETE /api/dashboards/{dashboard_id}
POST   /api/dashboards/{dashboard_id}/share
```

#### Workspaces (Team Collaboration)
```
POST   /api/workspaces
GET    /api/workspaces
GET    /api/workspaces/{workspace_id}
POST   /api/workspaces/{workspace_id}/members
DELETE /api/workspaces/{workspace_id}/members/{user_id}
```

---

### 2. Database Schema (PostgreSQL)

#### Core Tables

```sql
-- Users
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  auth_provider VARCHAR(50), -- 'supabase', 'auth0', etc.
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Workspaces
CREATE TABLE workspaces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  owner_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Workspace Members
CREATE TABLE workspace_members (
  workspace_id UUID REFERENCES workspaces(id),
  user_id UUID REFERENCES users(id),
  role VARCHAR(50), -- 'admin', 'editor', 'viewer'
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (workspace_id, user_id)
);

-- Datasets
CREATE TABLE datasets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES workspaces(id),
  created_by UUID REFERENCES users(id),
  filename VARCHAR(255) NOT NULL,
  file_size_bytes BIGINT,
  file_type VARCHAR(50), -- 'csv', 'xlsx', 'json'
  storage_path TEXT, -- S3 path
  row_count INTEGER,
  column_count INTEGER,
  columns JSONB, -- [{name, type, nullable}]
  preview JSONB, -- First 100 rows
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS (Row-Level Security)
ALTER TABLE datasets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can only see datasets in their workspaces"
  ON datasets
  FOR SELECT
  USING (
    workspace_id IN (
      SELECT workspace_id FROM workspace_members
      WHERE user_id = auth.uid()
    )
  );

-- Semantic Models
CREATE TABLE semantic_models (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dataset_id UUID REFERENCES datasets(id),
  workspace_id UUID REFERENCES workspaces(id),
  created_by UUID REFERENCES users(id),
  version INTEGER DEFAULT 1,
  metrics JSONB, -- [{name, expression, confidence}]
  dimensions JSONB, -- [{name, type, cardinality}]
  joins JSONB,
  glossary JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dashboards
CREATE TABLE dashboards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID REFERENCES workspaces(id),
  created_by UUID REFERENCES users(id),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  dataset_id UUID REFERENCES datasets(id),
  semantic_model_id UUID REFERENCES semantic_models(id),
  config JSONB, -- Full dashboard configuration
  share_token VARCHAR(255) UNIQUE, -- For public sharing
  is_public BOOLEAN DEFAULT FALSE,
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dashboard Versions (for version control)
CREATE TABLE dashboard_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dashboard_id UUID REFERENCES dashboards(id),
  version INTEGER NOT NULL,
  config JSONB,
  changed_by UUID REFERENCES users(id),
  change_summary TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(dashboard_id, version)
);

-- Audit Log
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  workspace_id UUID REFERENCES workspaces(id),
  action VARCHAR(100), -- 'dataset.uploaded', 'dashboard.created', etc.
  resource_type VARCHAR(50),
  resource_id UUID,
  metadata JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

#### Indexes for Performance

```sql
-- Datasets
CREATE INDEX idx_datasets_workspace ON datasets(workspace_id);
CREATE INDEX idx_datasets_created_by ON datasets(created_by);
CREATE INDEX idx_datasets_created_at ON datasets(created_at DESC);

-- Dashboards
CREATE INDEX idx_dashboards_workspace ON dashboards(workspace_id);
CREATE INDEX idx_dashboards_dataset ON dashboards(dataset_id);
CREATE INDEX idx_dashboards_share_token ON dashboards(share_token);

-- Audit Logs
CREATE INDEX idx_audit_workspace ON audit_logs(workspace_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_created_at ON audit_logs(created_at DESC);
```

---

### 3. File Storage Strategy (S3 / Cloudflare R2)

#### Storage Structure
```
bucket: introspective-data
├── uploads/
│   ├── {workspace_id}/
│   │   ├── {dataset_id}/
│   │   │   ├── raw.csv
│   │   │   ├── preview.json (first 100 rows)
│   │   │   └── metadata.json
├── exports/
│   ├── {dashboard_id}/
│   │   ├── dashboard.html
│   │   ├── dashboard.pdf
│   │   └── data.csv
```

#### Lifecycle Policies
- **Raw uploads**: Delete after 90 days (configurable per workspace)
- **Previews**: Keep indefinitely (small size)
- **Exports**: Delete after 7 days (user can re-generate)

#### Security
- All files encrypted at rest (AES-256)
- Pre-signed URLs for downloads (1-hour expiry)
- No direct public access
- Access logged in audit_logs table

---

### 4. Caching Strategy (Redis)

#### Cache Keys
```
# Dataset previews (first 100 rows)
dataset:{dataset_id}:preview  → JSON (TTL: 1 hour)

# Semantic model inference results
dataset:{dataset_id}:analysis  → JSON (TTL: 24 hours)

# Dashboard generation results
dashboard:generate:{hash}  → JSON (TTL: 5 minutes)

# User sessions
session:{session_id}  → JSON (TTL: 7 days)

# Rate limiting
ratelimit:{user_id}:{endpoint}  → Counter (TTL: 1 hour)
```

#### Cache Invalidation Rules
- Dataset preview invalidated on: dataset update/delete
- Semantic model invalidated on: dataset update, manual refresh
- Dashboard cache invalidated on: dashboard update, underlying data change

---

### 5. Authentication & Authorization

#### Providers (Choose ONE)

**Option A: Supabase Auth (Recommended for Speed)**
- ✅ Built-in: Email, OAuth (Google, GitHub, etc.)
- ✅ Row-Level Security (RLS) native integration
- ✅ Real-time subscriptions
- ✅ Edge Functions for custom logic
- ⚠️ Vendor lock-in

**Option B: Auth0 (Recommended for Enterprise)**
- ✅ SSO support (SAML, OIDC)
- ✅ Multi-factor authentication
- ✅ Advanced user management
- ✅ Compliance certifications
- ⚠️ Higher cost

**Option C: Custom JWT + Supabase DB**
- ✅ Full control
- ✅ No auth vendor dependency
- ⚠️ More engineering effort
- ⚠️ Must implement MFA, SSO separately

#### Authorization Model (RBAC)

| Role | Permissions |
|------|-------------|
| **Owner** | Full workspace control, delete workspace, manage billing |
| **Admin** | Add/remove members, manage all dashboards, configure semantic layer |
| **Editor** | Upload datasets, create dashboards, edit shared dashboards |
| **Viewer** | View dashboards, export data (read-only) |

---

### 6. Semantic Layer Implementation

#### Approach: dbt MetricFlow Integration (Recommended)

**Why dbt:**
- Industry standard (80% of data teams use it)
- 80% of queries complete in <1s
- Git-native version control
- Multi-cloud support

**Implementation:**

```yaml
# metrics.yml (dbt semantic layer)
metrics:
  - name: total_revenue
    label: Total Revenue
    type: simple
    type_params:
      measure: revenue_sum
    description: Sum of all revenue
    
  - name: average_order_value
    label: Average Order Value
    type: derived
    type_params:
      expr: total_revenue / order_count
    description: Revenue divided by number of orders

semantic_models:
  - name: sales
    description: Sales transactions
    model: ref('stg_sales')
    entities:
      - name: order_id
        type: primary
      - name: customer_id
        type: foreign
    dimensions:
      - name: order_date
        type: time
        type_params:
          time_granularity: day
      - name: region
        type: categorical
    measures:
      - name: revenue_sum
        agg: sum
        expr: amount
```

**API Integration:**
```python
# Backend: Query dbt semantic layer
from metricflow import MetricFlowClient

client = MetricFlowClient()

# Query metrics
result = client.query(
    metrics=["total_revenue", "average_order_value"],
    group_by=["region", "order_date"],
    where=[
        "order_date >= '2024-01-01'",
        "region IN ('North', 'South')"
    ]
)
```

---

### 7. Real-Time Features (WebSockets)

#### Use Cases
- Live dashboard updates when underlying data changes
- Multi-user collaboration (see who's viewing/editing)
- Real-time notifications (data refresh complete, share accepted)

#### Implementation (FastAPI + WebSockets)

```python
from fastapi import WebSocket, WebSocketDisconnect

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}
    
    async def connect(self, dashboard_id: str, websocket: WebSocket):
        await websocket.accept()
        if dashboard_id not in self.active_connections:
            self.active_connections[dashboard_id] = []
        self.active_connections[dashboard_id].append(websocket)
    
    async def broadcast(self, dashboard_id: str, message: dict):
        if dashboard_id in self.active_connections:
            for connection in self.active_connections[dashboard_id]:
                await connection.send_json(message)

manager = ConnectionManager()

@app.websocket("/ws/dashboards/{dashboard_id}")
async def dashboard_websocket(dashboard_id: str, websocket: WebSocket):
    await manager.connect(dashboard_id, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            # Handle cursor position, selections, etc.
            await manager.broadcast(dashboard_id, {
                "type": "user_action",
                "data": data
            })
    except WebSocketDisconnect:
        # Handle disconnect
        pass
```

---

### 8. Security Checklist

#### Input Validation
- [ ] File upload size limits (server-side)
- [ ] MIME type validation (magic bytes, not headers)
- [ ] Extension allowlist
- [ ] SQL injection prevention (parameterized queries)
- [ ] XSS prevention (sanitize all user inputs)

#### Authentication & Sessions
- [ ] JWT tokens with refresh rotation
- [ ] Secure cookie flags (HttpOnly, Secure, SameSite)
- [ ] CSRF protection
- [ ] Rate limiting (100 req/hour per user)
- [ ] Session expiry (7 days idle, 30 days absolute)

#### Data Protection
- [ ] Encryption at rest (S3, database)
- [ ] TLS 1.3 enforced
- [ ] Row-Level Security (RLS) on all tables
- [ ] Audit logging (all data access)
- [ ] No secrets in logs or error messages

#### OWASP Top 10 Compliance
- [ ] A01: Broken Access Control → RLS + RBAC
- [ ] A02: Cryptographic Failures → TLS + encrypted storage
- [ ] A03: Injection → Parameterized queries
- [ ] A04: Insecure Design → Rate limits + timeouts
- [ ] A05: Security Misconfiguration → No defaults

---

### 9. Deployment Architecture

#### Production Stack (Recommended)

```
┌─────────────────────────────────────────────────────────┐
│  Vercel (Frontend + Edge Functions)                      │
│  ├── React PWA (Static)                                  │
│  └── Edge Functions (Auth, rate limiting)                │
└───────────────────────┬─────────────────────────────────┘
                        │ HTTPS
┌───────────────────────▼─────────────────────────────────┐
│  Railway / Render (FastAPI Backend)                      │
│  ├── API Servers (horizontal scaling)                    │
│  └── Background Workers (Celery for long tasks)          │
└───────────────────────┬─────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
┌───────▼──────┐ ┌──────▼──────┐ ┌────▼──────┐
│  Supabase    │ │ Upstash     │ │ Cloudflare│
│  (Postgres)  │ │ (Redis)     │ │ R2 (S3)   │
└──────────────┘ └─────────────┘ └───────────┘
```

#### Environment Variables

```bash
# Backend (.env)
DATABASE_URL=postgresql://user:pass@host:5432/db
REDIS_URL=redis://host:6379
S3_BUCKET=introspective-data
S3_ACCESS_KEY=xxx
S3_SECRET_KEY=xxx
JWT_SECRET=xxx
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_ANON_KEY=xxx
ALLOWED_ORIGINS=https://app.introspective.dev

# Frontend (.env)
VITE_API_URL=https://api.introspective.dev
VITE_WS_URL=wss://api.introspective.dev/ws
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=xxx
```

---

### 10. Migration Path (Client-Side → Backend)

#### Phase 1: Add Backend Without Breaking Client-Side (Weeks 1-2)
- Deploy backend APIs
- Add "Save Dashboard" button (optional)
- Backend saves to DB + S3
- Client-side still works standalone

#### Phase 2: Add Authentication (Weeks 3-4)
- Implement Supabase Auth
- Add login/signup UI
- Saved dashboards require auth
- Guest mode still available

#### Phase 3: Add Semantic Layer (Weeks 5-6)
- Deploy dbt + MetricFlow
- Migrate existing auto-metrics to semantic models
- Add "Edit Metrics" UI
- Dashboard generation uses semantic layer

#### Phase 4: Add Collaboration (Weeks 7-8)
- Workspaces + team invites
- Real-time WebSockets
- Shared dashboard editing
- Version control + rollback

#### Phase 5: Enterprise Features (Weeks 9-12)
- SSO (SAML, OIDC)
- Advanced RBAC
- Audit logs UI
- Compliance reports (SOC 2, GDPR)

---

### 11. Cost Estimates (Monthly, 1000 Users)

| Service | Tier | Cost |
|---------|------|------|
| **Vercel** | Pro | $20 |
| **Railway** | 2x instances (8GB RAM) | $40 |
| **Supabase** | Pro (10GB DB) | $25 |
| **Upstash Redis** | Pay-as-you-go | $10 |
| **Cloudflare R2** | 100GB storage + egress | $15 |
| **Sentry** | Team (errors + performance) | $26 |
| **PostHog** | Growth (analytics) | $0 (free tier) |
| **Total** | | **~$136/month** |

**At scale (10K users):**
- Railway: 4x instances → $80
- Supabase: Pro (50GB) → $75
- R2: 1TB storage → $150
- Total: **~$350/month**

---

### 12. Performance Targets (SLAs)

| Metric | Target | Measurement |
|--------|--------|-------------|
| **API Response Time (p95)** | <200ms | Sentry Performance |
| **Dashboard Load Time** | <2s | Lighthouse |
| **File Upload (10MB)** | <5s | End-to-end |
| **Chart Rendering** | <500ms | React Profiler |
| **Uptime** | 99.9% | UptimeRobot |

---

### 13. Monitoring & Observability

#### Logs (Sentry)
- All errors with stack traces
- User context (ID, workspace)
- Request breadcrumbs
- 90-day retention

#### Metrics (PostHog)
- User events: upload, dashboard_create, export
- Feature flags for gradual rollouts
- Funnels: upload → analyze → save
- Cohort analysis

#### Alerts (PagerDuty / Slack)
- Error rate >1% for 2 minutes
- API latency p95 >500ms for 5 minutes
- Database connections >80%
- Queue depth >1000 items

---

### 14. Testing Strategy

#### Unit Tests (pytest + vitest)
- Backend: 80% coverage minimum
- Frontend: 70% coverage minimum
- Run on every PR

#### Integration Tests
- API contract tests (Pact)
- Database migrations test
- S3 upload/download flow
- Auth flows (login, token refresh)

#### E2E Tests (Playwright)
- Critical user flows:
  1. Upload CSV → Generate dashboard
  2. Save dashboard → Share link
  3. Create workspace → Invite member

#### Load Tests (Locust)
- 100 concurrent users
- 1000 requests/minute sustained
- Target: <5% error rate

---

### 15. Recommended Next Steps

#### Immediate (Do First)
1. ✅ **Deploy current client-side PWA** - Get it in front of bosses ASAP
2. ✅ **Gather feedback** - What features are critical? What's missing?
3. 📋 **Prioritize backend features** - Which moat features matter most?

#### Short-Term (1-2 Months)
4. 🔧 **Set up backend infrastructure** - Railway + Supabase + R2
5. 🔐 **Add authentication** - Supabase Auth
6. 💾 **Implement save/share** - Persist dashboards to DB

#### Medium-Term (3-6 Months)
7. 📊 **Add semantic layer** - dbt MetricFlow
8. 👥 **Enable collaboration** - Workspaces + real-time
9. 🔒 **Harden security** - SOC 2 compliance

#### Long-Term (6-12 Months)
10. 🏢 **Enterprise features** - SSO, advanced RBAC
11. 🤖 **AI-powered insights** - ML recommendations
12. 📈 **Scale infrastructure** - Multi-region, CDN

---

## Conclusion

This specification provides a complete roadmap for evolving the current client-side PWA into a production-grade, backend-enabled analytics platform. The key principle is **progressive enhancement** - each phase adds value without breaking existing functionality.

**Current state:** Standalone PWA, works offline, no backend needed  
**Future state:** Collaborative analytics platform with semantic layer and enterprise features

Start with Phase 1 (save/share) and iterate based on user feedback.

---

**Document Version:** 1.0.0  
**Last Updated:** January 16, 2026  
**Maintained By:** Engineering Team
