# INTrospective REST API Contracts v1.0.0

## Security-First API Design

All endpoints enforce:
- Input validation (whitelist strategy)
- Rate limiting
- CORS configuration
- Authentication (when auth module enabled)
- Error handling (Cause → Fix → Retry format)
- No stack traces in production

---

## Contract 1: POST /api/uploads

**Purpose:** Securely ingest files with manifest-enforced limits

### Request

**Headers:**
```
Content-Type: multipart/form-data
Content-Length: <size> (enforced server-side)
Authorization: Bearer <token> (if auth enabled)
```

**Form Data:**
```
files[]: File[] (1-10 files, manifest-enforced)
dataset_name?: string (optional, max 64 chars)
```

### Runtime Enforcement Checklist

- [ ] **Content-Length validation** - Reject if > manifest.maxFileSizeMb
- [ ] **MIME sniffing** - Read first 512 bytes, validate against allowlist
- [ ] **Extension validation** - Check against manifest.allowedTypes
- [ ] **Batch size** - Reject if > manifest.maxFilesPerBatch
- [ ] **Parsing timeout** - Per-file timeout (CSV: 2s, XLSX: 5s, JSON: 2s)
- [ ] **Preview extraction** - Store only N rows (manifest.previewRows)
- [ ] **Raw file retention** - Only if manifest.storageMode = "raw_and_previews"
- [ ] **Malware scanning** - Optional ClamAV integration hook

### Response: 200 OK

```json
{
  "dataset_id": "ds_8f3c9c2a",
  "name": "Q4_sales_data",
  "files": [
    {
      "filename": "sales.csv",
      "mime": "text/csv",
      "size_bytes": 183421,
      "rows_previewed": 2000,
      "columns": [
        {
          "name": "date",
          "type": "date",
          "nullable": false,
          "sample_values": ["2024-01-15", "2024-01-16"]
        },
        {
          "name": "revenue",
          "type": "number",
          "nullable": false,
          "min": 0,
          "max": 150000,
          "sample_values": [45600, 52300]
        },
        {
          "name": "region",
          "type": "string",
          "nullable": false,
          "cardinality": 4,
          "sample_values": ["North", "South", "East", "West"]
        }
      ],
      "parsed_at": "2026-01-16T06:00:00Z"
    }
  ],
  "storage_mode": "previews_only",
  "retention_policy": {
    "raw_retained": false,
    "preview_expires_days": 90
  }
}
```

### Error Responses

**413 Payload Too Large**
```json
{
  "error": {
    "code": "PAYLOAD_TOO_LARGE",
    "cause": "File size 30MB exceeds limit of 25MB",
    "fix": "Reduce file size or contact support to increase limit",
    "retry": true,
    "retry_after_seconds": 0
  }
}
```

**415 Unsupported Media Type**
```json
{
  "error": {
    "code": "INVALID_MIME_TYPE",
    "cause": "File MIME type 'application/x-msdownload' is not allowed",
    "fix": "Upload only CSV, JSON, or XLSX files",
    "retry": false
  }
}
```

**422 Unprocessable Entity**
```json
{
  "error": {
    "code": "PARSING_TIMEOUT",
    "cause": "CSV parsing exceeded 2000ms timeout",
    "fix": "File may be malformed or too complex. Simplify structure.",
    "retry": true,
    "retry_after_seconds": 30
  }
}
```

---

## Contract 2: POST /api/schema/infer

**Purpose:** Generate semantic model from uploaded data

### Request

```json
{
  "dataset_id": "ds_8f3c9c2a",
  "options": {
    "infer_time_series": true,
    "infer_metrics": true,
    "infer_dimensions": true,
    "max_analysis_ms": 2000
  }
}
```

### Runtime Enforcement

- [ ] **Dataset exists** - Return 404 if not found
- [ ] **Timeout enforcement** - Hard limit on inference time
- [ ] **Preview-only** - Never access raw files
- [ ] **Deterministic output** - Same input → same semantic model

### Response: 200 OK

```json
{
  "semantic_model_id": "sm_42b91d",
  "version": 1,
  "dataset_id": "ds_8f3c9c2a",
  "dimensions": [
    {
      "name": "date",
      "type": "time",
      "grain": "day",
      "format": "YYYY-MM-DD",
      "range": {
        "min": "2024-01-01",
        "max": "2024-12-31"
      }
    },
    {
      "name": "region",
      "type": "categorical",
      "cardinality": 4,
      "values": ["North", "South", "East", "West"]
    }
  ],
  "metrics": [
    {
      "metric_id": "m_revenue_total",
      "name": "total_revenue",
      "expression": "SUM(revenue)",
      "type": "currency",
      "unit": "USD",
      "aggregation": "sum",
      "confidence": 0.94,
      "rationale": "Numeric column with currency-like values"
    },
    {
      "metric_id": "m_revenue_avg",
      "name": "average_revenue",
      "expression": "AVG(revenue)",
      "type": "currency",
      "unit": "USD",
      "aggregation": "avg",
      "confidence": 0.91,
      "rationale": "Derived metric for trend analysis"
    }
  ],
  "joins": [],
  "quality": {
    "completeness": 0.98,
    "warnings": [
      "Revenue column has 2% null values; confidence adjusted"
    ]
  },
  "inferred_at": "2026-01-16T06:01:30Z"
}
```

### Error Responses

**404 Not Found**
```json
{
  "error": {
    "code": "DATASET_NOT_FOUND",
    "cause": "Dataset 'ds_8f3c9c2a' does not exist",
    "fix": "Upload files first via POST /api/uploads",
    "retry": false
  }
}
```

**422 Inference Failed**
```json
{
  "error": {
    "code": "INFERENCE_TIMEOUT",
    "cause": "Schema inference exceeded 2000ms timeout",
    "fix": "Dataset may be too complex. Try with smaller preview.",
    "retry": true,
    "retry_after_seconds": 60
  }
}
```

---

## Contract 3: POST /api/dashboards/generate

**Purpose:** Generate **exactly 3** dashboard options (hard contract)

### Request

```json
{
  "dataset_id": "ds_8f3c9c2a",
  "semantic_model_id": "sm_42b91d",
  "intent": "exploratory",
  "audience": "executive",
  "constraints": {
    "max_charts": 6,
    "viz_engine": "echarts"
  }
}
```

### Deterministic Rules

- **Exactly 3 dashboards** - Generator fails if ≠ 3
- **Semantic model required** - Cannot generate without metrics
- **Explainable charts** - Each chart has "why" rationale
- **Default viz engine only** - No multi-engine mixing

### Response: 200 OK

```json
{
  "generation_id": "gen_7f2a1b",
  "dashboards": [
    {
      "dashboard_id": "db_opt_1",
      "title": "Revenue Trends",
      "description": "Time-series view of revenue performance",
      "charts": [
        {
          "chart_id": "c1",
          "type": "line",
          "metric": "total_revenue",
          "dimension": "date",
          "config": {
            "engine": "echarts",
            "smooth": true,
            "showDataZoom": true
          },
          "rationale": "Line chart best shows revenue trends over time"
        },
        {
          "chart_id": "c2",
          "type": "bar",
          "metric": "total_revenue",
          "dimension": "region",
          "config": {
            "engine": "echarts",
            "orientation": "horizontal"
          },
          "rationale": "Horizontal bar chart highlights regional comparison"
        }
      ]
    },
    {
      "dashboard_id": "db_opt_2",
      "title": "Regional Performance",
      "description": "Deep dive into regional revenue breakdown",
      "charts": [
        {
          "chart_id": "c3",
          "type": "pie",
          "metric": "total_revenue",
          "dimension": "region",
          "config": {
            "engine": "echarts",
            "labelPosition": "outside"
          },
          "rationale": "Pie chart shows revenue distribution by region"
        }
      ]
    },
    {
      "dashboard_id": "db_opt_3",
      "title": "Executive Summary",
      "description": "High-level KPI snapshot",
      "charts": [
        {
          "chart_id": "c4",
          "type": "kpi",
          "metric": "total_revenue",
          "config": {
            "engine": "echarts",
            "showTrend": true,
            "comparisonPeriod": "previous_month"
          },
          "rationale": "Single KPI emphasizes headline performance"
        }
      ]
    }
  ],
  "generated_at": "2026-01-16T06:02:00Z"
}
```

### Error Responses

**400 Bad Request**
```json
{
  "error": {
    "code": "SEMANTIC_MODEL_REQUIRED",
    "cause": "Cannot generate dashboards without semantic model",
    "fix": "Run POST /api/schema/infer first",
    "retry": false
  }
}
```

**422 Generation Failed**
```json
{
  "error": {
    "code": "CANNOT_SATISFY_THREE_OPTION_CONTRACT",
    "cause": "Insufficient data to generate 3 distinct dashboard options",
    "fix": "Dataset needs at least 2 dimensions or 2 metrics",
    "retry": false
  }
}
```

---

## Security Checklist (All Endpoints)

### Input Validation
- [ ] Schema validation (Pydantic/Zod)
- [ ] Type checking
- [ ] Length bounds
- [ ] Whitelist-only for enums
- [ ] SQL injection prevention (parameterized queries only)

### Authentication & Authorization
- [ ] Bearer token validation (if auth enabled)
- [ ] RLS enforcement (dataset_id scoped to user)
- [ ] Rate limiting (100 req/hour per user)

### Error Handling
- [ ] Cause → Fix → Retry format
- [ ] No stack traces in production
- [ ] Sanitized error messages
- [ ] Audit logging for failures

### OWASP Top 10 Coverage
- [ ] **A01 Broken Access Control** - RLS verified
- [ ] **A02 Cryptographic Failures** - TLS enforced, secrets encrypted
- [ ] **A03 Injection** - Parameterized queries, input sanitization
- [ ] **A04 Insecure Design** - Rate limits, timeouts, size caps
- [ ] **A05 Security Misconfiguration** - No defaults, explicit policies

---

## Smoke Tests

### Test 1: Upload Enforcement
```bash
# Oversized file
curl -F "files=@30mb.csv" http://localhost:8000/api/uploads
# Expected: 413

# Wrong MIME
curl -F "files=@malware.exe" http://localhost:8000/api/uploads  
# Expected: 415
```

### Test 2: Schema Inference Timeout
```bash
curl -X POST http://localhost:8000/api/schema/infer \
  -H "Content-Type: application/json" \
  -d '{"dataset_id":"ds_x","options":{"max_analysis_ms":10}}'
# Expected: 422 (timeout)
```

### Test 3: Dashboard Three-Option Contract
```bash
curl -X POST http://localhost:8000/api/dashboards/generate \
  -H "Content-Type: application/json" \
  -d '{"dataset_id":"ds_8f3c9c2a","semantic_model_id":"sm_42b91d"}'
# Expected: 200 with exactly 3 dashboards
```

---

## Determinism Guarantees

1. **Manifest hash** - SHA-256 of canonicalized JSON
2. **Lockfile** - `manifest.lock.json` with frozen config
3. **Generation report** - `GENERATION_REPORT.md` with checklist
4. **Smoke tests** - Must pass before deployment

**Generator fails if:**
- Any endpoint missing runtime enforcement
- Dashboard generation returns ≠ 3 options
- Semantic model bypassed
- Smoke tests fail
