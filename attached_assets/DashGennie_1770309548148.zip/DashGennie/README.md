# 🚀 INTrospective - AI Code Generator + Moat Builder

> **Production-ready code generation with security-first design and deterministic outputs**

[![Security: OWASP Top 10](https://img.shields.io/badge/Security-OWASP%20Top%2010-success)](./docs/SECURITY.md)
[![Tests: Passing](https://img.shields.io/badge/Tests-Passing-success)](./GENERATION_REPORT.md)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)

## 🎯 What This Is

INTrospective is a **security-first, deterministic code generator** that produces production-ready SaaS applications with:

- ✅ **OWASP Top 10 compliance** built-in
- ✅ **Manifest-driven generation** (deterministic outputs)
- ✅ **API contracts with runtime enforcement** (not just validation)
- ✅ **Moat-building features** (data lock-in, semantic layers, templates)
- ✅ **Interactive dashboard** for configuration

### What Makes This Different

Unlike template generators that output unsafe boilerplate:

1. **Security is enforced at runtime**, not just validated at build time
2. **Every generation produces a report** showing exactly what was created and why
3. **API contracts are hard requirements** (e.g., dashboard endpoint MUST return 3 options)
4. **Generator fails fast** if security gates aren't met

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Interactive Dashboard                      │
│              (Configure → Generate → Deploy)                  │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Manifest Validator                         │
│        (JSON Schema + Security Rules + Determinism)           │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Module Generator                           │
│  ┌─────────┬──────────┬──────────┬──────────┬──────────┐    │
│  │  Core   │ Uploads  │Dashboard │Semantic  │   PWA    │    │
│  └─────────┴──────────┴──────────┴──────────┴──────────┘    │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Generated Application                      │
│  ┌──────────────────┐        ┌──────────────────┐           │
│  │   FastAPI Backend │◄──────►│  React Frontend  │           │
│  │   + PostgreSQL    │        │  + Vite + PWA    │           │
│  └──────────────────┘        └──────────────────┘           │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Node.js 20+ (for dashboard)
- Python 3.11+ (for generator)
- Docker (for PostgreSQL)
- Git

### 1. Clone & Setup

```bash
git clone https://github.com/yourusername/introspective.git
cd introspective

# Install dependencies
npm install
pip install -r requirements.txt

# Start services
docker-compose up -d
```

### 2. Configure Your App

Open the interactive dashboard:

```bash
# Open dashboard
open introspective-dashboard.html
```

Or use the CLI:

```bash
# Create manifest
python generator/cli.py init \
  --name my-app \
  --use-case analytics_dashboard \
  --auth supabase

# Validate manifest
python generator/cli.py validate manifest.json

# Generate code
python generator/cli.py generate manifest.json
```

### 3. Review & Deploy

```bash
# Review generation report
cat GENERATION_REPORT.md

# Run smoke tests
make smoke

# Deploy to staging
make deploy-staging
```

## 📋 API Contracts (Core Endpoints)

### 1. POST /api/uploads

**Security guarantees:**
- MIME sniffing from first 512 bytes (not headers)
- Extension allowlist validation
- Per-file size caps (manifest-enforced)
- Parsing timeouts (CSV: 2s, XLSX: 5s)
- Preview-only storage (no raw file retention by default)

**Example:**

```bash
curl -F "files=@sales.csv" \
  -H "Authorization: Bearer $TOKEN" \
  http://localhost:8000/api/uploads
```

**Response:**

```json
{
  "dataset_id": "ds_8f3c9c2a",
  "files": [{
    "filename": "sales.csv",
    "mime": "text/csv",
    "rows_previewed": 2000,
    "columns": [
      {"name": "date", "type": "date"},
      {"name": "revenue", "type": "number"}
    ]
  }]
}
```

### 2. POST /api/schema/infer

**Determinism guarantee:** Same input → same semantic model

**Example:**

```bash
curl -X POST http://localhost:8000/api/schema/infer \
  -H "Content-Type: application/json" \
  -d '{
    "dataset_id": "ds_8f3c9c2a",
    "options": {"infer_metrics": true}
  }'
```

**Response:**

```json
{
  "semantic_model_id": "sm_42b91d",
  "metrics": [{
    "name": "total_revenue",
    "expression": "SUM(revenue)",
    "confidence": 0.94,
    "rationale": "Numeric column with currency-like values"
  }]
}
```

### 3. POST /api/dashboards/generate

**Hard contract:** MUST return exactly 3 dashboard options

**Example:**

```bash
curl -X POST http://localhost:8000/api/dashboards/generate \
  -H "Content-Type: application/json" \
  -d '{
    "dataset_id": "ds_8f3c9c2a",
    "semantic_model_id": "sm_42b91d"
  }'
```

**Response:**

```json
{
  "dashboards": [
    {"dashboard_id": "db_opt_1", "title": "Revenue Trends", "charts": [...]},
    {"dashboard_id": "db_opt_2", "title": "Regional Performance", "charts": [...]},
    {"dashboard_id": "db_opt_3", "title": "Executive Summary", "charts": [...]}
  ]
}
```

## 🔒 Security Features

### OWASP Top 10 Compliance

| Vulnerability | Mitigation | Implementation |
|---------------|------------|----------------|
| **A01: Broken Access Control** | RLS enforced on all queries | `backend/alembic/versions/001_initial.py:45` |
| **A02: Cryptographic Failures** | TLS 1.3, secrets encrypted | `backend/app/core/security.py:67` |
| **A03: Injection** | Parameterized queries only | All SQLAlchemy ORM |
| **A04: Insecure Design** | Rate limits, timeouts, caps | `backend/app/api/uploads.py:25` |
| **A05: Security Misconfiguration** | No defaults, explicit policies | `manifest.schema.json` |

### Input Validation Strategy

**Whitelist-only approach:**

```python
# GOOD: Explicit allowlist
ALLOWED_MIMES = ["text/csv", "application/json", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"]

# BAD: Blacklist (bypassed easily)
BLOCKED_MIMES = ["application/x-msdownload", "text/html"]
```

**Multi-layer validation:**

1. **Schema validation** (Pydantic/Zod)
2. **MIME sniffing** (magic bytes, not headers)
3. **Extension check** (allowlist)
4. **Content scanning** (optional ClamAV hook)
5. **Parsing timeout** (per file type)

### Error Handling (Cause → Fix → Retry)

All errors follow this format:

```json
{
  "error": {
    "code": "PAYLOAD_TOO_LARGE",
    "cause": "File size 30MB exceeds limit of 25MB",
    "fix": "Reduce file size or contact support to increase limit",
    "retry": true,
    "retry_after_seconds": 0
  }
}
```

**Never expose:**
- Stack traces in production
- Database connection strings
- Internal file paths
- User IDs of other users

## 🏰 Moat-Building Features

### 1. Data Moat (Proprietary Semantic Layer)

```python
# Users build on YOUR metric definitions
semantic_model = {
    "metrics": [
        {
            "name": "total_revenue",
            "expression": "SUM(revenue)",
            "confidence": 0.94
        }
    ],
    "joins": [...],
    "glossary": [...]
}
```

**Switching cost:** Competitors can't replicate your metric definitions, joins, and business logic.

### 2. Network Effects (Template Marketplace)

```python
# Users share dashboard templates
POST /api/templates/publish
{
    "template_id": "t_revenue_analysis",
    "dashboard_config": {...},
    "popularity_score": 0.87
}
```

**Moat strengthens:** More templates → more value → more users → more templates.

### 3. Workflow Embedding (API Dependencies)

```javascript
// Customers build on your API
const revenue = await introspective.metrics.getTotalRevenue({
    timeRange: 'last_30_days',
    dimensions: ['region']
});
```

**Switching cost:** Migration = rewriting all integrations.

## 📊 Performance & Scalability

### Current Limits (Single Node)

| Metric | Limit | Scaling Strategy |
|--------|-------|------------------|
| Concurrent users | 500 | Horizontal scaling (load balancer) |
| File uploads/min | 1000 | Rate limiting prevents abuse |
| Dataset size | 10GB preview | Archive to S3 after 90 days |
| Inference latency | <2s (p95) | Redis caching + GPU acceleration |

### Bottlenecks (Known)

1. **PostgreSQL connection pool** - 50 connections (tune based on load)
2. **CSV parsing** - CPU-bound (consider Rust/Go parser)
3. **Semantic inference** - RAM-intensive (4GB per worker)

### Optimization Roadmap

- [ ] **Week 1:** Add Redis caching for semantic models (80% latency reduction)
- [ ] **Week 2:** Implement database read replicas
- [ ] **Week 3:** Move CSV parsing to worker queue (Celery)
- [ ] **Week 4:** Add CDN for static assets

## 🧪 Testing

### Smoke Tests (Mandatory)

```bash
# Run all smoke tests
make smoke

# Individual tests
pytest tests/smoke/test_uploads.py -v
pytest tests/smoke/test_schema.py -v
pytest tests/smoke/test_dashboards.py -v
```

**Pass criteria:**
- All 3 API contracts verified
- Upload limits enforced server-side
- Dashboard generation returns exactly 3 options

### Unit Tests

```bash
# Run all unit tests
pytest tests/unit/ -v --cov

# Coverage report
pytest --cov=backend --cov-report=html
open htmlcov/index.html
```

**Target:** >80% code coverage

### Load Testing

```bash
# Simulate 100 concurrent users
locust -f tests/load/upload_test.py \
  --users 100 \
  --spawn-rate 10 \
  --host http://localhost:8000
```

## 📚 Documentation

- **[API Contracts](./API_CONTRACTS.md)** - REST endpoints with security guarantees
- **[Generation Report](./GENERATION_REPORT.md)** - What was generated and why
- **[Architecture](./docs/ARCHITECTURE.md)** - System design and data flow
- **[Security](./docs/SECURITY.md)** - Threat model and mitigations
- **[Deployment](./docs/DEPLOYMENT.md)** - Production setup guide

## 🚨 Known Limitations

### What We DON'T Support Yet

1. **Multi-region deployment** - Single region only
2. **Real-time collaboration** - Dashboards are single-user
3. **Custom viz engines** - ECharts only (adapters pending)
4. **Mobile offline mode** - Desktop PWA only

### What May Break

1. **Large XLSX files** - Parsing timeout if >10K rows
2. **Complex semantic inference** - May timeout on high-cardinality data
3. **Concurrent dashboard edits** - Last-write-wins (no CRDT)

## 🛠️ Development

### Project Structure

```
introspective/
├── backend/              # FastAPI application
│   ├── app/
│   │   ├── api/         # Route handlers
│   │   ├── core/        # Config, security, errors
│   │   ├── db/          # Database models & sessions
│   │   ├── models/      # Domain models
│   │   └── services/    # Business logic
│   ├── alembic/         # Database migrations
│   └── tests/           # Unit & smoke tests
├── frontend/            # React + Vite application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Route pages
│   │   └── utils/       # API client, helpers
│   └── public/          # Static assets + PWA files
├── docs/                # Documentation
├── manifest.schema.json # JSON Schema for validation
└── GENERATION_REPORT.md # Latest generation report
```

### Code Quality Gates

**Pre-commit:**
```bash
# Install pre-commit hooks
pre-commit install

# Run manually
pre-commit run --all-files
```

**CI Pipeline:**
```bash
# Runs on every PR
- Linting (flake8, eslint)
- Type checking (mypy, tsc)
- Unit tests (pytest, vitest)
- Smoke tests
- Security scan (bandit, npm audit)
```

## 🤝 Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md)

## 📄 License

MIT - See [LICENSE](./LICENSE)

## 🙏 Acknowledgments

Built with:
- [FastAPI](https://fastapi.tiangolo.com/) - Modern Python web framework
- [React](https://react.dev/) - UI library
- [PostgreSQL](https://www.postgresql.org/) - Database
- [ECharts](https://echarts.apache.org/) - Visualization library
- [Supabase](https://supabase.com/) - Auth & database

## 📞 Support

- **Documentation:** [docs/](./docs/)
- **Issues:** [GitHub Issues](https://github.com/yourusername/introspective/issues)
- **Security:** [security@yourcompany.com](mailto:security@yourcompany.com)

---

**Generated with ❤️ by INTrospective v1.0.0**
