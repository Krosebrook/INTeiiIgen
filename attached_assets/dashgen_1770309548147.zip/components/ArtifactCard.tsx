
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useEffect, useRef, useState } from 'react';
import { Artifact } from '../types';
import { DesktopIcon, TabletIcon, MobileIcon } from './Icons';

interface ArtifactCardProps {
    artifact: Artifact;
    isFocused: boolean;
    onClick: () => void;
}

type DeviceMode = 'desktop' | 'tablet' | 'mobile';

const ArtifactCard = React.memo(({ 
    artifact, 
    isFocused, 
    onClick 
}: ArtifactCardProps) => {
    const codeRef = useRef<HTMLPreElement>(null);
    const [deviceMode, setDeviceMode] = useState<DeviceMode>('desktop');

    // Auto-scroll logic for this specific card
    useEffect(() => {
        if (codeRef.current) {
            codeRef.current.scrollTop = codeRef.current.scrollHeight;
        }
    }, [artifact.html]);

    // Reset to desktop when focus is lost or artifact changes
    useEffect(() => {
        if (!isFocused) setDeviceMode('desktop');
    }, [isFocused]);

    const isBlurring = artifact.status === 'streaming';

    return (
        <div 
            className={`artifact-card ${isFocused ? 'focused' : ''} ${isBlurring ? 'generating' : ''}`}
            onClick={onClick}
        >
            <div className="artifact-header">
                <span className="artifact-style-tag">{artifact.styleName}</span>
                {isFocused && (
                    <div className="device-toggles" onClick={(e) => e.stopPropagation()}>
                        <button 
                            className={`device-btn ${deviceMode === 'mobile' ? 'active' : ''}`} 
                            onClick={() => setDeviceMode('mobile')}
                            title="Mobile View (375px)"
                        >
                            <MobileIcon />
                        </button>
                        <button 
                            className={`device-btn ${deviceMode === 'tablet' ? 'active' : ''}`} 
                            onClick={() => setDeviceMode('tablet')}
                            title="Tablet View (768px)"
                        >
                            <TabletIcon />
                        </button>
                        <button 
                            className={`device-btn ${deviceMode === 'desktop' ? 'active' : ''}`} 
                            onClick={() => setDeviceMode('desktop')}
                            title="Desktop View (Full)"
                        >
                            <DesktopIcon />
                        </button>
                    </div>
                )}
            </div>
            <div className={`artifact-card-inner mode-${deviceMode}`}>
                {isBlurring && (
                    <div className="generating-overlay">
                        <pre ref={codeRef} className="code-stream-preview">
                            {artifact.html}
                        </pre>
                    </div>
                )}
                <div className="iframe-wrapper">
                    <iframe 
                        srcDoc={artifact.html} 
                        title={artifact.id} 
                        sandbox="allow-scripts allow-forms allow-modals allow-popups allow-presentation allow-same-origin"
                        className="artifact-iframe"
                    />
                </div>
            </div>
        </div>
    );
});

export default ArtifactCard;
