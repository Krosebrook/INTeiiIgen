// DEPRECATED: use src/features/dashboard/components/LiveSimulator.tsx instead.
export { default } from '../../features/dashboard/components/LiveSimulator';
export * from '../../features/dashboard/components/LiveSimulator';
