// DEPRECATED: use src/features/dashboard/components/KPISection.tsx instead.
export { default } from '../../features/dashboard/components/KPISection';
export * from '../../features/dashboard/components/KPISection';
