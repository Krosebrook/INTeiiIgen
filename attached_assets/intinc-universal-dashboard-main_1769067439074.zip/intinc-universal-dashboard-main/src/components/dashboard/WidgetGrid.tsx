// DEPRECATED: use src/features/dashboard/components/WidgetGrid.tsx instead.
export { default } from '../../features/dashboard/components/WidgetGrid';
export * from '../../features/dashboard/components/WidgetGrid';
