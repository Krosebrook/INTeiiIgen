// DEPRECATED: use src/features/dashboard/components/GlobalFilters.tsx instead.
export { default } from '../../features/dashboard/components/GlobalFilters';
export * from '../../features/dashboard/components/GlobalFilters';
