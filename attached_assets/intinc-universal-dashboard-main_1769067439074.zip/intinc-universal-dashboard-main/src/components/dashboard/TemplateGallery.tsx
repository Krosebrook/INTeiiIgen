// DEPRECATED: use src/features/dashboard/components/TemplateGallery.tsx instead.
export { default } from '../../features/dashboard/components/TemplateGallery';
export * from '../../features/dashboard/components/TemplateGallery';
