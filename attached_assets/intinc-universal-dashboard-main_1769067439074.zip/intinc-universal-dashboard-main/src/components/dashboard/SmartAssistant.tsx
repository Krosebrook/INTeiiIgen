// DEPRECATED: use src/features/dashboard/components/SmartAssistant.tsx instead.
export { default } from '../../features/dashboard/components/SmartAssistant';
export * from '../../features/dashboard/components/SmartAssistant';
