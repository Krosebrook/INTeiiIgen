// DEPRECATED: use src/features/dashboard/components/VisualWidgetBuilder.tsx instead.
export { default } from '../../features/dashboard/components/VisualWidgetBuilder';
export * from '../../features/dashboard/components/VisualWidgetBuilder';
