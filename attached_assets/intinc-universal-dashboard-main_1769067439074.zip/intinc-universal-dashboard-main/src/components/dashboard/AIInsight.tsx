// DEPRECATED: use src/features/dashboard/components/AIInsight.tsx instead.
export { default } from '../../features/dashboard/components/AIInsight';
export * from '../../features/dashboard/components/AIInsight';
