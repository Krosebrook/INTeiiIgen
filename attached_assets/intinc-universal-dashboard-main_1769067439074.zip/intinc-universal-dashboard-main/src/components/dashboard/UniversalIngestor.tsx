// DEPRECATED: use src/features/dashboard/components/UniversalIngestor.tsx instead.
export { default } from '../../features/dashboard/components/UniversalIngestor';
export * from '../../features/dashboard/components/UniversalIngestor';
