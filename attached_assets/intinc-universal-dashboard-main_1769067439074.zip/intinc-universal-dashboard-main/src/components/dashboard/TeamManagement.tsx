// DEPRECATED: use src/features/dashboard/components/TeamManagement.tsx instead.
export { default } from '../../features/dashboard/components/TeamManagement';
export * from '../../features/dashboard/components/TeamManagement';
