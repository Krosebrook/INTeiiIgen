// DEPRECATED: use src/features/dashboard/components/EnterpriseSettings.tsx instead.
export { default } from '../../features/dashboard/components/EnterpriseSettings';
export * from '../../features/dashboard/components/EnterpriseSettings';
