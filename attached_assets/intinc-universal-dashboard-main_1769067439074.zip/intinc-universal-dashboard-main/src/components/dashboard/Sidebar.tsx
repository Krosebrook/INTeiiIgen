// DEPRECATED: use src/features/dashboard/components/Sidebar.tsx instead.
export { default } from '../../features/dashboard/components/Sidebar';
export * from '../../features/dashboard/components/Sidebar';
